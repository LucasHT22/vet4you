import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class ExameDialog extends JDialog {
    private Exame exame;
    private JTextField tipoField;
    private JTextArea resultadoArea;
    private JSpinner dataSpinner;
    private JTextField idConsultaField;
    private boolean confirmed = false;

    public ExameDialog(JFrame parent, Exame exame) {
        super(parent, exame == null ? "Adicionar Exame" : "Editar Exame", true);
        this.exame = exame;
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(DesignUtils.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Tipo
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Tipo:"), gbc);
        gbc.gridx = 1;
        tipoField = new JTextField(20);
        panel.add(tipoField, gbc);

        // Resultado
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Resultado:"), gbc);
        gbc.gridx = 1;
        resultadoArea = new JTextArea(3, 20);
        JScrollPane resultadoScrollPane = new JScrollPane(resultadoArea);
        panel.add(resultadoScrollPane, gbc);

        // Data
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Data:"), gbc);
        gbc.gridx = 1;
        SpinnerDateModel dateModel = new SpinnerDateModel();
        dataSpinner = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dataSpinner, "dd/MM/yyyy");
        dataSpinner.setEditor(dateEditor);
        panel.add(dataSpinner, gbc);

        // ID Consulta
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("ID Consulta:"), gbc);
        gbc.gridx = 1;
        idConsultaField = new JTextField(20);
        panel.add(idConsultaField, gbc);

        // Botões de Ação
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        JButton saveButton = createStyledButton("Salvar");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    saveExame();
                    confirmed = true;
                    dispose();
                }
            }
        });
        buttonPanel.add(saveButton);

        JButton cancelButton = createStyledButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        buttonPanel.add(cancelButton);

        if (exame != null) {
            loadExameData();
        }

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(parent);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void loadExameData() {
        tipoField.setText(exame.getTipo());
        resultadoArea.setText(exame.getResultado());
        if (exame.getData() != null) {
            Date date = Date.from(exame.getData().atStartOfDay(ZoneId.systemDefault()).toInstant());
            dataSpinner.setValue(date);
        }
        idConsultaField.setText(String.valueOf(exame.getIdConsulta()));
    }

    private void saveExame() {
        if (exame == null) {
            exame = new Exame();
        }
        
        exame.setTipo(tipoField.getText());
        exame.setResultado(resultadoArea.getText());
        
        Date date = (Date) dataSpinner.getValue();
        LocalDate ld = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        exame.setData(ld);
        
        try {
            exame.setIdConsulta(Integer.parseInt(idConsultaField.getText()));
        } catch (NumberFormatException e) {
            exame.setIdConsulta(0);
        }
    }

    private boolean validateFields() {
        if (tipoField.getText().trim().isEmpty() ||
            idConsultaField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Os campos Tipo e ID Consulta são obrigatórios.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            Integer.parseInt(idConsultaField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID Consulta deve ser um número inteiro válido.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }

    public Exame getExame() {
        return exame;
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
