import java.util.List;

public class UsuarioService {
    private UsuarioDAO usuarioDAO;

    public UsuarioService() {
        this.usuarioDAO = new UsuarioDAO();
    }

    public boolean validarLogin(String username, String password) {
        List<Usuario> usuarios = usuarioDAO.listarTodos();
        for (Usuario usuario : usuarios) {
            if (usuario.getUsername().equals(username) && usuario.getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }

    public Usuario buscarUsuarioPorId(int id) {
        return usuarioDAO.buscarPorId(id);
    }

    public void cadastrarUsuario(Usuario usuario) {
        // Adicionar validações de negócio antes de inserir
        if (usuario.getNome() == null || usuario.getNome().isEmpty()) {
            throw new IllegalArgumentException("Nome do usuário não pode ser vazio.");
        }
        if (usuario.getEmail() == null || usuario.getEmail().isEmpty() || !usuario.getEmail().contains("@")) {
            throw new IllegalArgumentException("Email inválido.");
        }
        if (usuario.getUsername() == null || usuario.getUsername().isEmpty()) {
            throw new IllegalArgumentException("Username não pode ser vazio.");
        }
        if (usuario.getPassword() == null || usuario.getPassword().isEmpty()) {
            throw new IllegalArgumentException("Senha não pode ser vazia.");
        }
        // Verificar se username ou email já existem (exemplo simplificado)
        List<Usuario> todosUsuarios = usuarioDAO.listarTodos();
        for (Usuario u : todosUsuarios) {
            if (u.getUsername().equals(usuario.getUsername())) {
                throw new IllegalArgumentException("Username já existe.");
            }
            if (u.getEmail().equals(usuario.getEmail())) {
                throw new IllegalArgumentException("Email já existe.");
            }
        }

        usuarioDAO.inserir(usuario);
    }

    public Usuario buscarUsuarioPorUsername(String username) {
        List<Usuario> usuarios = usuarioDAO.listarTodos();
        for (Usuario usuario : usuarios) {
            if (usuario.getUsername().equals(username)) {
                return usuario;
            }
        }
        return null;
    }

    public void atualizarUsuario(Usuario usuario) {
        // Adicionar validações de negócio antes de atualizar
        if (usuario.getIdUsuario() == 0) {
            throw new IllegalArgumentException("ID do usuário não pode ser zero para atualização.");
        }
        usuarioDAO.atualizar(usuario);
    }

    public void deletarUsuario(int id) {
        usuarioDAO.deletar(id);
    }

    public List<Usuario> listarTodosUsuarios() {
        return usuarioDAO.listarTodos();
    }
}

