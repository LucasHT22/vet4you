import java.util.Objects;

public class Paciente {
    private int idPaciente;
    private String nome;
    private String raca;
    private String animal;
    private int idade;
    private String sexo;
    private int idUsuario;
    private String plano;

    public Paciente() {
    }

    public Paciente(int idPaciente, String nome, String raca, String animal, int idade, String sexo, int idUsuario, String plano) {
        this.idPaciente = idPaciente;
        this.nome = nome;
        this.raca = raca;
        this.animal = animal;
        this.idade = idade;
        this.sexo = sexo;
        this.idUsuario = idUsuario;
        this.plano = plano;
    }

    // Getters e Setters
    public int getIdPaciente() {
        return this.idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRaca() {
        return this.raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public String getAnimal() {
        return this.animal;
    }

    public void setAnimal(String animal) {
        this.animal = animal;
    }

    public int getIdade() {
        return this.idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getSexo() {
        return this.sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public int getIdUsuario() {
        return this.idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getPlano() {
        return this.plano;
    }

    public void setPlano(String plano) {
        this.plano = plano;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Paciente))
            return false;
        Paciente paciente = (Paciente) o;
        return idPaciente == paciente.idPaciente && Objects.equals(nome, paciente.nome) && Objects.equals(raca, paciente.raca) && Objects.equals(animal, paciente.animal) && idade == paciente.idade && Objects.equals(sexo, paciente.sexo) && idUsuario == paciente.idUsuario && Objects.equals(plano, paciente.plano);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPaciente, nome, raca, animal, idade, sexo, idUsuario, plano);
    }

    @Override
    public String toString() {
        return "{" +
            " idPaciente=\'" + getIdPaciente() + "\'" +
            ", nome=\'" + getNome() + "\'" +
            ", raca=\'" + getRaca() + "\'" +
            ", animal=\'" + getAnimal() + "\'" +
            ", idade=\'" + getIdade() + "\'" +
            ", sexo=\'" + getSexo() + "\'" +
            ", idUsuario=\'" + getIdUsuario() + "\'" +
            ", plano=\'" + getPlano() + "\'" +
            "}";
    }
}
