import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PacienteDialog extends JDialog {
    private Paciente paciente;
    private JTextField nomeField;
    private JTextField racaField;
    private JTextField animalField;
    private JTextField idadeField;
    private JComboBox<String> sexoComboBox;
    private JTextField idUsuarioField; // Simplificado, idealmente seria um JComboBox com usuários
    private JTextField planoField;
    private boolean confirmed = false;

    public PacienteDialog(JFrame parent, Paciente paciente) {
        super(parent, paciente == null ? "Adicionar Paciente" : "Editar Paciente", true);
        this.paciente = paciente;
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(DesignUtils.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Nome
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Nome:"), gbc);
        gbc.gridx = 1;
        nomeField = new JTextField(20);
        panel.add(nomeField, gbc);

        // Raça
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Raça:"), gbc);
        gbc.gridx = 1;
        racaField = new JTextField(20);
        panel.add(racaField, gbc);

        // Animal
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Animal:"), gbc);
        gbc.gridx = 1;
        animalField = new JTextField(20);
        panel.add(animalField, gbc);

        // Idade
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Idade:"), gbc);
        gbc.gridx = 1;
        idadeField = new JTextField(20);
        panel.add(idadeField, gbc);

        // Sexo
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("Sexo:"), gbc);
        gbc.gridx = 1;
        sexoComboBox = new JComboBox<>(new String[]{"Macho", "Fêmea"});
        panel.add(sexoComboBox, gbc);

        // ID do Usuário (Dono)
        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(new JLabel("ID do Dono:"), gbc);
        gbc.gridx = 1;
        idUsuarioField = new JTextField(20);
        panel.add(idUsuarioField, gbc);

        // Plano
        gbc.gridx = 0;
        gbc.gridy = 6;
        panel.add(new JLabel("Plano:"), gbc);
        gbc.gridx = 1;
        planoField = new JTextField(20);
        panel.add(planoField, gbc);

        // Botões de Ação
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        JButton saveButton = createStyledButton("Salvar");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    savePaciente();
                    confirmed = true;
                    dispose();
                }
            }
        });
        buttonPanel.add(saveButton);

        JButton cancelButton = createStyledButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        buttonPanel.add(cancelButton);

        if (paciente != null) {
            loadPacienteData();
        }

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(parent);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void loadPacienteData() {
        nomeField.setText(paciente.getNome());
        racaField.setText(paciente.getRaca());
        animalField.setText(paciente.getAnimal());
        idadeField.setText(String.valueOf(paciente.getIdade()));
        sexoComboBox.setSelectedItem(paciente.getSexo());
        idUsuarioField.setText(String.valueOf(paciente.getIdUsuario()));
        planoField.setText(paciente.getPlano());
    }

    private void savePaciente() {
        if (paciente == null) {
            paciente = new Paciente();
        }
        paciente.setNome(nomeField.getText());
        paciente.setRaca(racaField.getText());
        paciente.setAnimal(animalField.getText());
        try {
            paciente.setIdade(Integer.parseInt(idadeField.getText()));
        } catch (NumberFormatException e) {
            paciente.setIdade(0); // Valor padrão em caso de erro
        }
        paciente.setSexo((String) sexoComboBox.getSelectedItem());
        try {
            paciente.setIdUsuario(Integer.parseInt(idUsuarioField.getText()));
        } catch (NumberFormatException e) {
            paciente.setIdUsuario(0); // Valor padrão em caso de erro
        }
        paciente.setPlano(planoField.getText());
    }

    private boolean validateFields() {
        if (nomeField.getText().trim().isEmpty() ||
            racaField.getText().trim().isEmpty() ||
            animalField.getText().trim().isEmpty() ||
            idadeField.getText().trim().isEmpty() ||
            idUsuarioField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Os campos Nome, Raça, Animal, Idade e ID do Dono são obrigatórios.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            Integer.parseInt(idadeField.getText());
            Integer.parseInt(idUsuarioField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Idade e ID do Dono devem ser números inteiros válidos.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
