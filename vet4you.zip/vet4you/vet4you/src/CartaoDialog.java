import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class CartaoDialog extends JDialog {
    private Cartao cartao;
    private JTextField planoField;
    private JSpinner validadeSpinner;
    private JTextField titularField;
    private boolean confirmed = false;

    public CartaoDialog(JFrame parent, Cartao cartao) {
        super(parent, cartao == null ? "Adicionar Cartão" : "Editar Cartão", true);
        this.cartao = cartao;
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(DesignUtils.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Plano
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Plano:"), gbc);
        gbc.gridx = 1;
        planoField = new JTextField(20);
        panel.add(planoField, gbc);

        // Validade
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Validade (MM/yyyy):"), gbc);
        gbc.gridx = 1;
        SpinnerDateModel dateModel = new SpinnerDateModel();
        validadeSpinner = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(validadeSpinner, "MM/yyyy");
        validadeSpinner.setEditor(dateEditor);
        panel.add(validadeSpinner, gbc);

        // Titular
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Titular:"), gbc);
        gbc.gridx = 1;
        titularField = new JTextField(20);
        panel.add(titularField, gbc);

        // Botões de Ação
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        JButton saveButton = createStyledButton("Salvar");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    saveCartao();
                    confirmed = true;
                    dispose();
                }
            }
        });
        buttonPanel.add(saveButton);

        JButton cancelButton = createStyledButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        buttonPanel.add(cancelButton);

        if (cartao != null) {
            loadCartaoData();
        } else {
            validadeSpinner.setValue(new Date());
        }

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(parent);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void loadCartaoData() {
        planoField.setText(cartao.getPlano());
        if (cartao.getValidade() != null) {
            // Converte LocalDate para Date para o JSpinner
            Date date = Date.from(cartao.getValidade().atStartOfDay(ZoneId.systemDefault()).toInstant());
            validadeSpinner.setValue(date);
        }
        titularField.setText(cartao.getTitular());
    }

    private void saveCartao() {
        if (cartao == null) {
            cartao = new Cartao();
        }
        
        cartao.setPlano(planoField.getText());
        cartao.setTitular(titularField.getText());
        
        Date date = (Date) validadeSpinner.getValue();
        // Converte Date para LocalDate
        LocalDate ld = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        cartao.setValidade(ld);
    }

    private boolean validateFields() {
        if (planoField.getText().trim().isEmpty() ||
            titularField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Os campos Plano e Titular são obrigatórios.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Validação básica de validade (apenas para garantir que não está no passado)
        Date date = (Date) validadeSpinner.getValue();
        LocalDate ld = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        if (ld.isBefore(LocalDate.now().withDayOfMonth(1))) {
            JOptionPane.showMessageDialog(this, "A validade do cartão não pode ser no passado.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }

    public Cartao getCartao() {
        return cartao;
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
