import java.util.List;

public class VeterinarioService {
    private VeterinarioDAO veterinarioDAO;

    public VeterinarioService() {
        this.veterinarioDAO = new VeterinarioDAO();
    }

    public void cadastrarVeterinario(Veterinario veterinario) {
        if (veterinario.getNome() == null || veterinario.getNome().isEmpty()) {
            throw new IllegalArgumentException("Nome do veterinário não pode ser vazio.");
        }
        if (veterinario.getCrmvet() == null || veterinario.getCrmvet().isEmpty()) {
            throw new IllegalArgumentException("CRMVET do veterinário não pode ser vazio.");
        }

        veterinarioDAO.inserir(veterinario);
    }

    public Veterinario buscarVeterinarioPorId(int id) {
        return veterinarioDAO.buscarPorId(id);
    }

    public void atualizarVeterinario(Veterinario veterinario) {
        if (veterinario.getIdVeterinario() == 0) {
            throw new IllegalArgumentException("ID do veterinário não pode ser zero para atualização.");
        }
        veterinarioDAO.atualizar(veterinario);
    }

    public void deletarVeterinario(int id) {
        veterinarioDAO.deletar(id);
    }

    public List<Veterinario> listarTodosVeterinarios() {
        return veterinarioDAO.listarTodos();
    }
}
