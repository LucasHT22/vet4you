import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class DatabaseInitializer {

    public static void initialize(String sqlFilePath) {
    try (Connection connection = ConnectionFactory.getConnection();
         Statement statement = connection.createStatement()) {

        StringBuilder sql = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(sqlFilePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sql.append(line).append("\n");
            }
        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo SQL: " + e.getMessage());
            return;
        }

        statement.executeUpdate(sql.toString());

        System.out.println("Banco de dados inicializado com sucesso!");

    } catch (SQLException e) {
        System.err.println("Erro ao inicializar o banco de dados: " + e.getMessage());
        e.printStackTrace();
    }
}


    public static void main(String[] args) {
        initialize("vet4you.sql");
    }
}
