import java.time.LocalDateTime;
import java.util.Objects;

public class Cirurgia {
    private int idCirurgia;
    private String tipo;
    private LocalDateTime data;
    private String observacoes;
    private int idPaciente;
    private int idVeterinario;

    public Cirurgia() {
    }

    public Cirurgia(int idCirurgia, String tipo, LocalDateTime data, String observacoes, int idPaciente, int idVeterinario) {
        this.idCirurgia = idCirurgia;
        this.tipo = tipo;
        this.data = data;
        this.observacoes = observacoes;
        this.idPaciente = idPaciente;
        this.idVeterinario = idVeterinario;
    }

    // Getters e Setters
    public int getIdCirurgia() {
        return this.idCirurgia;
    }

    public void setIdCirurgia(int idCirurgia) {
        this.idCirurgia = idCirurgia;
    }

    public String getTipo() {
        return this.tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public LocalDateTime getData() {
        return this.data;
    }

    public void setData(LocalDateTime data) {
        this.data = data;
    }

    public String getObservacoes() {
        return this.observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public int getIdPaciente() {
        return this.idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public int getIdVeterinario() {
        return this.idVeterinario;
    }

    public void setIdVeterinario(int idVeterinario) {
        this.idVeterinario = idVeterinario;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Cirurgia))
            return false;
        Cirurgia cirurgia = (Cirurgia) o;
        return idCirurgia == cirurgia.idCirurgia && Objects.equals(tipo, cirurgia.tipo) && Objects.equals(data, cirurgia.data) && Objects.equals(observacoes, cirurgia.observacoes) && idPaciente == cirurgia.idPaciente && idVeterinario == cirurgia.idVeterinario;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCirurgia, tipo, data, observacoes, idPaciente, idVeterinario);
    }

    @Override
    public String toString() {
        return "{" +
            " idCirurgia=\'" + getIdCirurgia() + "\'" +
            ", tipo=\'" + getTipo() + "\'" +
            ", data=\'" + getData() + "\'" +
            ", observacoes=\'" + getObservacoes() + "\'" +
            ", idPaciente=\'" + getIdPaciente() + "\'" +
            ", idVeterinario=\'" + getIdVeterinario() + "\'" +
            "}";
    }
}

