import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class ConsultaDialog extends JDialog {
    private Consulta consulta;
    private JSpinner timestampSpinner;
    private JTextArea motivoArea;
    private JTextArea diagnosticoArea;
    private JTextField idPacienteField;
    private JTextField idVeterinarioField;
    private boolean confirmed = false;

    public ConsultaDialog(JFrame parent, Consulta consulta) {
        super(parent, consulta == null ? "Agendar Consulta" : "Editar Consulta", true);
        this.consulta = consulta;
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(DesignUtils.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Timestamp
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Data/Hora:"), gbc);
        gbc.gridx = 1;
        SpinnerDateModel dateModel = new SpinnerDateModel();
        timestampSpinner = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(timestampSpinner, "dd/MM/yyyy HH:mm");
        timestampSpinner.setEditor(dateEditor);
        panel.add(timestampSpinner, gbc);

        // Motivo
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Motivo:"), gbc);
        gbc.gridx = 1;
        motivoArea = new JTextArea(3, 20);
        JScrollPane motivoScrollPane = new JScrollPane(motivoArea);
        panel.add(motivoScrollPane, gbc);

        // Diagnóstico
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Diagnóstico:"), gbc);
        gbc.gridx = 1;
        diagnosticoArea = new JTextArea(3, 20);
        JScrollPane diagnosticoScrollPane = new JScrollPane(diagnosticoArea);
        panel.add(diagnosticoScrollPane, gbc);

        // ID Paciente
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("ID Paciente:"), gbc);
        gbc.gridx = 1;
        idPacienteField = new JTextField(20);
        panel.add(idPacienteField, gbc);

        // ID Veterinário
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("ID Veterinário:"), gbc);
        gbc.gridx = 1;
        idVeterinarioField = new JTextField(20);
        panel.add(idVeterinarioField, gbc);

        // Botões de Ação
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        JButton saveButton = createStyledButton("Salvar");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    saveConsulta();
                    confirmed = true;
                    dispose();
                }
            }
        });
        buttonPanel.add(saveButton);

        JButton cancelButton = createStyledButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        buttonPanel.add(cancelButton);

        if (consulta != null) {
            loadConsultaData();
        }

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(parent);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void loadConsultaData() {
        Date date = Date.from(consulta.getTimestamp().atZone(ZoneId.systemDefault()).toInstant());
        timestampSpinner.setValue(date);
        motivoArea.setText(consulta.getMotivo());
        diagnosticoArea.setText(consulta.getDiagnostico());
        idPacienteField.setText(String.valueOf(consulta.getIdPaciente()));
        idVeterinarioField.setText(String.valueOf(consulta.getIdVeterinario()));
    }

    private void saveConsulta() {
        if (consulta == null) {
            consulta = new Consulta();
        }
        
        Date date = (Date) timestampSpinner.getValue();
        LocalDateTime ldt = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        consulta.setTimestamp(ldt);
        
        consulta.setMotivo(motivoArea.getText());
        consulta.setDiagnostico(diagnosticoArea.getText());
        
        try {
            consulta.setIdPaciente(Integer.parseInt(idPacienteField.getText()));
        } catch (NumberFormatException e) {
            consulta.setIdPaciente(0);
        }
        
        try {
            consulta.setIdVeterinario(Integer.parseInt(idVeterinarioField.getText()));
        } catch (NumberFormatException e) {
            consulta.setIdVeterinario(0);
        }
    }

    private boolean validateFields() {
        if (motivoArea.getText().trim().isEmpty() ||
            idPacienteField.getText().trim().isEmpty() ||
            idVeterinarioField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Os campos Data/Hora, Motivo, ID Paciente e ID Veterinário são obrigatórios.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            Integer.parseInt(idPacienteField.getText());
            Integer.parseInt(idVeterinarioField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID Paciente e ID Veterinário devem ser números inteiros válidos.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }

    public Consulta getConsulta() {
        return consulta;
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
