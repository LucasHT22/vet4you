import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;

public class ProdutoDAO extends BaseDAOImpl<Produto> {

    @Override
    public void inserir(Produto produto) {
        String sql = "INSERT INTO Produto (nome, tipo, preco, estoque, idConsulta) VALUES (?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForInsert(stmt, produto);
            stmt.executeUpdate();
            System.out.println("Produto inserido com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao inserir produto: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void atualizar(Produto produto) {
        String sql = "UPDATE Produto SET nome = ?, tipo = ?, preco = ?, estoque = ?, idConsulta = ? WHERE idProduto = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForUpdate(stmt, produto);
            stmt.executeUpdate();
            System.out.println("Produto atualizado com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar produto: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void deletar(int id) {
        String sql = "DELETE FROM Produto WHERE idProduto = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Produto deletado com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao deletar produto: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Produto buscarPorId(int id) {
        String sql = "SELECT * FROM Produto WHERE idProduto = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Produto produto = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                produto = buildEntity(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar produto por ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return produto;
    }

    @Override
    public List<Produto> listarTodos() {
        String sql = "SELECT * FROM Produto";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Produto> produtos = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                produtos.add(buildEntity(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar todos os produtos: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return produtos;
    }

    @Override
    protected Produto buildEntity(ResultSet rs) throws SQLException {
        Produto produto = new Produto();
        produto.setIdProduto(rs.getInt("idProduto"));
        produto.setNome(rs.getString("nome"));
        produto.setTipo(rs.getString("tipo"));
        produto.setPreco(rs.getBigDecimal("preco"));
        produto.setEstoque(rs.getInt("estoque"));
        
        // idConsulta pode ser null
        int idConsulta = rs.getInt("idConsulta");
        if (rs.wasNull()) {
            produto.setIdConsulta(null);
        } else {
            produto.setIdConsulta(idConsulta);
        }
        return produto;
    }

    @Override
    protected void prepareStatementForInsert(PreparedStatement stmt, Produto produto) throws SQLException {
        stmt.setString(1, produto.getNome());
        stmt.setString(2, produto.getTipo());
        stmt.setBigDecimal(3, produto.getPreco());
        stmt.setInt(4, produto.getEstoque());
        if (produto.getIdConsulta() != null) {
            stmt.setInt(5, produto.getIdConsulta());
        } else {
            stmt.setNull(5, java.sql.Types.INTEGER);
        }
    }

    @Override
    protected void prepareStatementForUpdate(PreparedStatement stmt, Produto produto) throws SQLException {
        prepareStatementForInsert(stmt, produto); // Reutiliza os mesmos parâmetros para update
        stmt.setInt(6, produto.getIdProduto());
    }
}
