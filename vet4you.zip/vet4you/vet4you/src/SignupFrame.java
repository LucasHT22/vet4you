import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SignupFrame extends JFrame {
    private JTextField nomeField;
    private JTextField emailField;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JTextField telefoneField;
    private JTextField cpfField;
    private JButton cadastroButton;
    private JButton voltarButton;
    private UsuarioService usuarioService;

    public SignupFrame() {
        setTitle("Vet4You - Cadastro");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 600);
        setLocationRelativeTo(null);
        setResizable(false);

        usuarioService = new UsuarioService();

        // Painel com scroll
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Título
        JLabel titleLabel = new JLabel("Cadastro de Usuário");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createVerticalStrut(20));

        // Nome
        addField(mainPanel, "Nome:", nomeField = new JTextField());
        mainPanel.add(Box.createVerticalStrut(10));

        // Email
        addField(mainPanel, "Email:", emailField = new JTextField());
        mainPanel.add(Box.createVerticalStrut(10));

        // Username
        addField(mainPanel, "Usuário:", usernameField = new JTextField());
        mainPanel.add(Box.createVerticalStrut(10));

        // Password
        addField(mainPanel, "Senha:", passwordField = new JPasswordField());
        mainPanel.add(Box.createVerticalStrut(10));

        // Confirm Password
        addField(mainPanel, "Confirmar Senha:", confirmPasswordField = new JPasswordField());
        mainPanel.add(Box.createVerticalStrut(10));

        // Telefone
        addField(mainPanel, "Telefone:", telefoneField = new JTextField());
        mainPanel.add(Box.createVerticalStrut(10));

        // CPF
        addField(mainPanel, "CPF:", cpfField = new JTextField());
        mainPanel.add(Box.createVerticalStrut(20));

        // Botões
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 0));

        cadastroButton = new JButton("Cadastrar");
        cadastroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleSignup();
            }
        });
        buttonPanel.add(cadastroButton);

        voltarButton = new JButton("Voltar");
        voltarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new LoginFrame();
                dispose();
            }
        });
        buttonPanel.add(voltarButton);

        mainPanel.add(buttonPanel);

        JScrollPane scrollPane = new JScrollPane(mainPanel);
        add(scrollPane);
        setVisible(true);
    }

    private void addField(JPanel panel, String label, JTextField field) {
        JLabel jLabel = new JLabel(label);
        jLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        panel.add(jLabel);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        panel.add(field);
    }

    private void handleSignup() {
        String nome = nomeField.getText();
        String email = emailField.getText();
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        String telefone = telefoneField.getText();
        String cpf = cpfField.getText();

        if (nome.isEmpty() || email.isEmpty() || username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha todos os campos obrigatórios!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "As senhas não coincidem!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Usuario novoUsuario = new Usuario();
            novoUsuario.setNome(nome);
            novoUsuario.setEmail(email);
            novoUsuario.setUsername(username);
            novoUsuario.setPassword(password);
            novoUsuario.setTelefone(telefone);
            novoUsuario.setCpf(cpf);
            novoUsuario.setIsAdmin(false);
            novoUsuario.setIsActive(true);

            usuarioService.cadastrarUsuario(novoUsuario);
            JOptionPane.showMessageDialog(this, "Cadastro realizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            new LoginFrame();
            dispose();
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Erro de Validação", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao cadastrar: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
