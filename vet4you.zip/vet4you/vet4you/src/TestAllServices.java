import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class TestAllServices {

    public static void main(String[] args) {
        // Inicializa serviços
        UsuarioService usuarioService = new UsuarioService();
        EnderecoService enderecoService = new EnderecoService();
        PacienteService pacienteService = new PacienteService();
        VeterinarioService veterinarioService = new VeterinarioService();
        ConsultaService consultaService = new ConsultaService();
        ExameService exameService = new ExameService();
        ProdutoService produtoService = new ProdutoService();
        PrescricaoService prescricaoService = new PrescricaoService();
        InternacaoService internacaoService = new InternacaoService();
        CirurgiaService cirurgiaService = new CirurgiaService();
        PagamentoService pagamentoService = new PagamentoService();
        CartaoService cartaoService = new CartaoService();

        // Limpa o banco de dados para testes limpos (opcional, para ambiente de desenvolvimento)
        // Cuidado: Isso deleta todos os dados!
        // new DatabaseInitializer().resetDatabase(); // Seria necessário implementar um método para resetar

        System.out.println("--- Iniciando Testes de Serviços ---");

        // 1. Teste UsuarioService
        System.out.println("\n--- Testando UsuarioService ---");
        Usuario user1 = new Usuario(0, "UserA", "11911112222", "usera@example.com", "usera", "pass123", false, "111.111.111-11", true);
        Usuario user2 = new Usuario(0, "admin", "11933334444", "admin@example.com", "admin", "pass456", true, "222.222.222-22", true);
        try {
            usuarioService.cadastrarUsuario(user1);
            usuarioService.cadastrarUsuario(user2);
            System.out.println("Usuários cadastrados.");
        } catch (IllegalArgumentException e) {
            System.err.println("Erro ao cadastrar usuário: " + e.getMessage());
        }
        List<Usuario> usuarios = usuarioService.listarTodosUsuarios();
        System.out.println("Usuários no sistema: " + usuarios.size());
        Usuario fetchedUser = usuarioService.buscarUsuarioPorUsername("usera");
        if (fetchedUser != null) {
            fetchedUser.setNome("UserA");
            usuarioService.atualizarUsuario(fetchedUser);
            System.out.println("Usuário atualizado: " + usuarioService.buscarUsuarioPorUsername("usera").getNome());
        }

        // 2. Teste EnderecoService
        System.out.println("\n--- Testando EnderecoService ---");
        Endereco end1 = new Endereco(0, "Rua A", "100", "Ap 1", "Centro", "CidadeX", "SP", "00000-000", fetchedUser.getIdUsuario());
        enderecoService.cadastrarEndereco(end1);
        List<Endereco> enderecos = enderecoService.listarTodosEnderecos();
        System.out.println("Endereços no sistema: " + enderecos.size());

        // 3. Teste PacienteService
        System.out.println("\n--- Testando PacienteService ---");
        Paciente pet1 = new Paciente(0, "Rex", "Labrador", "Cachorro", 5, "Macho", fetchedUser.getIdUsuario(), "Premium");
        pacienteService.cadastrarPaciente(pet1);
        List<Paciente> pacientes = pacienteService.listarTodosPacientes();
        System.out.println("Pacientes no sistema: " + pacientes.size());
        Paciente fetchedPet = pacienteService.buscarPacientePorId(pacientes.get(0).getIdPaciente());
        System.out.println("Paciente buscado: " + fetchedPet.getNome());

        // 4. Teste VeterinarioService
        System.out.println("\n--- Testando VeterinarioService ---");
        Veterinario vet1 = new Veterinario(0, "Dr. Carlos", "Clínico Geral", "CRMVET-SP-1234");
        veterinarioService.cadastrarVeterinario(vet1);
        List<Veterinario> veterinarios = veterinarioService.listarTodosVeterinarios();
        System.out.println("Veterinários no sistema: " + veterinarios.size());
        Veterinario fetchedVet = veterinarioService.buscarVeterinarioPorId(veterinarios.get(0).getIdVeterinario());
        System.out.println("Veterinário buscado: " + fetchedVet.getNome());

        // 5. Teste ConsultaService
        System.out.println("\n--- Testando ConsultaService ---");
        Consulta cons1 = new Consulta(0, LocalDateTime.now().plusDays(1), "Rotina", null, fetchedPet.getIdPaciente(), fetchedVet.getIdVeterinario());
        consultaService.agendarConsulta(cons1);
        List<Consulta> consultas = consultaService.listarTodasConsultas();
        System.out.println("Consultas no sistema: " + consultas.size());
        Consulta fetchedCons = consultaService.buscarConsultaPorId(consultas.get(0).getIdConsulta());
        System.out.println("Consulta buscada: " + fetchedCons.getMotivo());

        // 6. Teste ExameService
        System.out.println("\n--- Testando ExameService ---");
        Exame exam1 = new Exame(0, "Hemograma", "Normal", LocalDate.now(), fetchedCons.getIdConsulta());
        exameService.cadastrarExame(exam1);
        List<Exame> exames = exameService.listarTodosExames();
        System.out.println("Exames no sistema: " + exames.size());

        // 7. Teste ProdutoService
        System.out.println("\n--- Testando ProdutoService ---");
        Produto prod1 = new Produto(0, "Ração Premium", "Alimento", new BigDecimal("150.00"), 50, null);
        produtoService.cadastrarProduto(prod1);
        List<Produto> produtos = produtoService.listarTodosProdutos();
        System.out.println("Produtos no sistema: " + produtos.size());
        Produto fetchedProd = produtoService.buscarProdutoPorId(produtos.get(0).getIdProduto());
        System.out.println("Produto buscado: " + fetchedProd.getNome());

        // 8. Teste PrescricaoService
        System.out.println("\n--- Testando PrescricaoService ---");
        Prescricao pres1 = new Prescricao(0, 1, "Administrar 1x ao dia", fetchedCons.getIdConsulta(), fetchedVet.getIdVeterinario(), fetchedProd.getIdProduto());
        prescricaoService.cadastrarPrescricao(pres1);
        List<Prescricao> prescricoes = prescricaoService.listarTodasPrescricoes();
        System.out.println("Prescrições no sistema: " + prescricoes.size());

        // 9. Teste InternacaoService
        System.out.println("\n--- Testando InternacaoService ---");
        Internacao intern1 = new Internacao(0, LocalDateTime.now(), null, "Observação inicial", fetchedVet.getIdVeterinario(), fetchedPet.getIdPaciente());
        internacaoService.cadastrarInternacao(intern1);
        List<Internacao> internacoes = internacaoService.listarTodasInternacoes();
        System.out.println("Internações no sistema: " + internacoes.size());

        // 10. Teste CirurgiaService
        System.out.println("\n--- Testando CirurgiaService ---");
        Cirurgia cir1 = new Cirurgia(0, "Castração", LocalDateTime.now().plusDays(7), "Preparar para anestesia", fetchedPet.getIdPaciente(), fetchedVet.getIdVeterinario());
        cirurgiaService.agendarCirurgia(cir1);
        List<Cirurgia> cirurgias = cirurgiaService.listarTodasCirurgias();
        System.out.println("Cirurgias no sistema: " + cirurgias.size());

        // 11. Teste PagamentoService
        System.out.println("\n--- Testando PagamentoService ---");
        Pagamento pag1 = new Pagamento(0, "Consulta", "Cartão", new BigDecimal("100.00"), "Concluído", LocalDateTime.now(), fetchedPet.getIdPaciente());
        pagamentoService.registrarPagamento(pag1);
        List<Pagamento> pagamentos = pagamentoService.listarTodosPagamentos();
        System.out.println("Pagamentos no sistema: " + pagamentos.size());

        // 12. Teste CartaoService
        System.out.println("\n--- Testando CartaoService ---");
        Cartao card1 = new Cartao(0, "Visa", LocalDate.now().plusYears(2), "UserA");
        cartaoService.cadastrarCartao(card1);
        List<Cartao> cartoes = cartaoService.listarTodosCartoes();
        System.out.println("Cartões no sistema: " + cartoes.size());

        System.out.println("\n--- Testes de Serviços Concluídos ---");
    }
}
