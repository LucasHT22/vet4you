import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class CartaoManagementFrame extends JFrame {
    private Usuario usuarioLogado;
    private CartaoService cartaoService;
    private JTable cartoesTable;
    private DefaultTableModel tableModel;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("MM/yyyy");

    public CartaoManagementFrame(Usuario usuario) {
        this.usuarioLogado = usuario;
        this.cartaoService = new CartaoService();

        DesignUtils.setupFrame(this, "Gerenciar Cartões");

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(DesignUtils.BACKGROUND_COLOR);

        // Painel de botões
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        buttonPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton addButton = createStyledButton("Adicionar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CartaoDialog dialog = new CartaoDialog(CartaoManagementFrame.this, null);
                dialog.setVisible(true);
                if (dialog.isConfirmed()) {
                    try {
                        cartaoService.cadastrarCartao(dialog.getCartao());
                        carregarCartoes();
                        JOptionPane.showMessageDialog(CartaoManagementFrame.this, "Cartão adicionado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(CartaoManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        buttonPanel.add(addButton);

        JButton editButton = createStyledButton("Editar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = cartoesTable.getSelectedRow();
                if (selectedRow != -1) {
                    int idCartao = (int) tableModel.getValueAt(selectedRow, 0);
                    Cartao cartaoToEdit = cartaoService.buscarCartaoPorId(idCartao);
                    
                    CartaoDialog dialog = new CartaoDialog(CartaoManagementFrame.this, cartaoToEdit);
                    dialog.setVisible(true);
                    
                    if (dialog.isConfirmed()) {
                        try {
                            cartaoService.atualizarCartao(dialog.getCartao());
                            carregarCartoes();
                            JOptionPane.showMessageDialog(CartaoManagementFrame.this, "Cartão atualizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                        } catch (IllegalArgumentException ex) {
                            JOptionPane.showMessageDialog(CartaoManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(CartaoManagementFrame.this, "Selecione um cartão para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(editButton);

        JButton deleteButton = createStyledButton("Deletar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = cartoesTable.getSelectedRow();
                if (selectedRow != -1) {
                    int confirm = JOptionPane.showConfirmDialog(CartaoManagementFrame.this, 
                        "Tem certeza que deseja deletar o cartão selecionado?", "Confirmar Deleção", 
                        JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        int idCartao = (int) tableModel.getValueAt(selectedRow, 0);
                        cartaoService.deletarCartao(idCartao);
                        carregarCartoes();
                        JOptionPane.showMessageDialog(CartaoManagementFrame.this, "Cartão deletado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(CartaoManagementFrame.this, "Selecione um cartão para deletar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(deleteButton);

        JButton refreshButton = createStyledButton("Atualizar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carregarCartoes();
            }
        });
        buttonPanel.add(refreshButton);

        mainPanel.add(buttonPanel, BorderLayout.NORTH);

        // Tabela de cartões
        String[] columnNames = {"ID", "Plano", "Validade", "Titular"};
        tableModel = new DefaultTableModel(columnNames, 0);
        cartoesTable = new JTable(tableModel);
        cartoesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        cartoesTable.setRowHeight(25);
        cartoesTable.getTableHeader().setBackground(DesignUtils.HEADER_COLOR);
        cartoesTable.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(cartoesTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
        carregarCartoes();
        setVisible(true);
    }

    // Método auxiliar para criar botões com estilo
    private JButton createStyledButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.addActionListener(listener);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void carregarCartoes() {
        tableModel.setRowCount(0);
        List<Cartao> cartoes = cartaoService.listarTodosCartoes();
        for (Cartao cartao : cartoes) {
            Object[] row = {
                cartao.getIdCartao(),
                cartao.getPlano(),
                cartao.getValidade() != null ? cartao.getValidade().format(DATE_FORMATTER) : "N/A",
                cartao.getTitular()
            };
            tableModel.addRow(row);
        }
    }
}
