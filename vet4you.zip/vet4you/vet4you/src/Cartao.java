import java.time.LocalDate;
import java.util.Objects;

public class Cartao {
    private int idCartao;
    private String plano;
    private LocalDate validade;
    private String titular;

    public Cartao() {
    }

    public Cartao(int idCartao, String plano, LocalDate validade, String titular) {
        this.idCartao = idCartao;
        this.plano = plano;
        this.validade = validade;
        this.titular = titular;
    }

    // Getters e Setters
    public int getIdCartao() {
        return this.idCartao;
    }

    public void setIdCartao(int idCartao) {
        this.idCartao = idCartao;
    }

    public String getPlano() {
        return this.plano;
    }

    public void setPlano(String plano) {
        this.plano = plano;
    }

    public LocalDate getValidade() {
        return this.validade;
    }

    public void setValidade(LocalDate validade) {
        this.validade = validade;
    }

    public String getTitular() {
        return this.titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Cartao))
            return false;
        Cartao cartao = (Cartao) o;
        return idCartao == cartao.idCartao && Objects.equals(plano, cartao.plano) && Objects.equals(validade, cartao.validade) && Objects.equals(titular, cartao.titular);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCartao, plano, validade, titular);
    }

    @Override
    public String toString() {
        return "{" +
            " idCartao=\'" + getIdCartao() + "\\'" +
            ", plano=\'" + getPlano() + "\\'" +
            ", validade=\'" + getValidade() + "\\'" +
            ", titular=\'" + getTitular() + "\\'" +
            "}";
    }
}

