import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class EnderecoManagementFrame extends JFrame {
    private Usuario usuarioLogado;
    private EnderecoService enderecoService;
    private JTable enderecosTable;
    private DefaultTableModel tableModel;

    public EnderecoManagementFrame(Usuario usuario) {
        this.usuarioLogado = usuario;
        this.enderecoService = new EnderecoService();

        setTitle("Vet4You - Gerenciar Endereços");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1200, 600);
        setLocationRelativeTo(null);
        setResizable(true);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        // Painel de botões
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));

        JButton addButton = new JButton("Adicionar");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EnderecoDialog dialog = new EnderecoDialog(EnderecoManagementFrame.this, null);
                dialog.setVisible(true);
                if (dialog.isConfirmed()) {
                    try {
                        enderecoService.cadastrarEndereco(dialog.getEndereco());
                        carregarEnderecos();
                        JOptionPane.showMessageDialog(EnderecoManagementFrame.this, "Endereço adicionado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(EnderecoManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        buttonPanel.add(addButton);

        JButton editButton = new JButton("Editar");
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = enderecosTable.getSelectedRow();
                if (selectedRow != -1) {
                    int idEndereco = (int) tableModel.getValueAt(selectedRow, 0);
                    Endereco enderecoToEdit = enderecoService.buscarEnderecoPorId(idEndereco);
                    
                    EnderecoDialog dialog = new EnderecoDialog(EnderecoManagementFrame.this, enderecoToEdit);
                    dialog.setVisible(true);
                    
                    if (dialog.isConfirmed()) {
                        try {
                            enderecoService.atualizarEndereco(dialog.getEndereco());
                            carregarEnderecos();
                            JOptionPane.showMessageDialog(EnderecoManagementFrame.this, "Endereço atualizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                        } catch (IllegalArgumentException ex) {
                            JOptionPane.showMessageDialog(EnderecoManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(EnderecoManagementFrame.this, "Selecione um endereço para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(editButton);

        JButton deleteButton = new JButton("Deletar");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = enderecosTable.getSelectedRow();
                if (selectedRow != -1) {
                    int confirm = JOptionPane.showConfirmDialog(EnderecoManagementFrame.this, 
                        "Tem certeza que deseja deletar o endereço selecionado?", "Confirmar Deleção", 
                        JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        int idEndereco = (int) tableModel.getValueAt(selectedRow, 0);
                        enderecoService.deletarEndereco(idEndereco);
                        carregarEnderecos();
                        JOptionPane.showMessageDialog(EnderecoManagementFrame.this, "Endereço deletado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(EnderecoManagementFrame.this, "Selecione um endereço para deletar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(deleteButton);

        JButton refreshButton = new JButton("Atualizar");
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carregarEnderecos();
            }
        });
        buttonPanel.add(refreshButton);

        mainPanel.add(buttonPanel, BorderLayout.NORTH);

        // Tabela de endereços
        String[] columnNames = {"ID", "Logradouro", "Número", "Complemento", "Bairro", "Cidade", "Estado", "CEP", "ID Usuário"};
        tableModel = new DefaultTableModel(columnNames, 0);
        enderecosTable = new JTable(tableModel);
        enderecosTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(enderecosTable);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
        carregarEnderecos();
        setVisible(true);
    }

    private void carregarEnderecos() {
        tableModel.setRowCount(0);
        List<Endereco> enderecos = enderecoService.listarTodosEnderecos();
        for (Endereco endereco : enderecos) {
            Object[] row = {
                endereco.getIdEndereco(),
                endereco.getLogradouro(),
                endereco.getNumero(),
                endereco.getComplemento(),
                endereco.getBairro(),
                endereco.getCidade(),
                endereco.getEstado(),
                endereco.getCep(),
                endereco.getIdUsuario()
            };
            tableModel.addRow(row);
        }
    }
}
