import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAO extends BaseDAOImpl<Paciente> {

    @Override
    public void inserir(Paciente paciente) {
        String sql = "INSERT INTO Paciente (nome, raca, animal, idade, sexo, idUsuario, plano) VALUES (?, ?, ?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForInsert(stmt, paciente);
            stmt.executeUpdate();
            System.out.println("Paciente inserido com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao inserir paciente: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void atualizar(Paciente paciente) {
        String sql = "UPDATE Paciente SET nome = ?, raca = ?, animal = ?, idade = ?, sexo = ?, idUsuario = ?, plano = ? WHERE idPaciente = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForUpdate(stmt, paciente);
            stmt.executeUpdate();
            System.out.println("Paciente atualizado com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar paciente: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void deletar(int id) {
        String sql = "DELETE FROM Paciente WHERE idPaciente = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Paciente deletado com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao deletar paciente: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Paciente buscarPorId(int id) {
        String sql = "SELECT * FROM Paciente WHERE idPaciente = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Paciente paciente = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                paciente = buildEntity(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar paciente por ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return paciente;
    }

    @Override
    public List<Paciente> listarTodos() {
        String sql = "SELECT * FROM Paciente";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Paciente> pacientes = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                pacientes.add(buildEntity(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar todos os pacientes: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return pacientes;
    }

    @Override
    protected Paciente buildEntity(ResultSet rs) throws SQLException {
        Paciente paciente = new Paciente();
        paciente.setIdPaciente(rs.getInt("idPaciente"));
        paciente.setNome(rs.getString("nome"));
        paciente.setRaca(rs.getString("raca"));
        paciente.setAnimal(rs.getString("animal"));
        paciente.setIdade(rs.getInt("idade"));
        paciente.setSexo(rs.getString("sexo"));
        paciente.setIdUsuario(rs.getInt("idUsuario"));
        paciente.setPlano(rs.getString("plano"));
        return paciente;
    }

    @Override
    protected void prepareStatementForInsert(PreparedStatement stmt, Paciente paciente) throws SQLException {
        stmt.setString(1, paciente.getNome());
        stmt.setString(2, paciente.getRaca());
        stmt.setString(3, paciente.getAnimal());
        stmt.setInt(4, paciente.getIdade());
        stmt.setString(5, paciente.getSexo());
        stmt.setInt(6, paciente.getIdUsuario());
        stmt.setString(7, paciente.getPlano());
    }

    @Override
    protected void prepareStatementForUpdate(PreparedStatement stmt, Paciente paciente) throws SQLException {
        prepareStatementForInsert(stmt, paciente); // Reutiliza os mesmos parâmetros para update
        stmt.setInt(8, paciente.getIdPaciente());
    }
}
