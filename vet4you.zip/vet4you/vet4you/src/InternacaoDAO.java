import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class InternacaoDAO extends BaseDAOImpl<Internacao> {

    @Override
    public void inserir(Internacao internacao) {
        String sql = "INSERT INTO Internacao (dataEntrada, dataSaida, observacoes, idVeterinario, idPaciente) VALUES (?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForInsert(stmt, internacao);
            stmt.executeUpdate();
            System.out.println("Internação inserida com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao inserir internação: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void atualizar(Internacao internacao) {
        String sql = "UPDATE Internacao SET dataEntrada = ?, dataSaida = ?, observacoes = ?, idVeterinario = ?, idPaciente = ? WHERE idInternacao = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForUpdate(stmt, internacao);
            stmt.executeUpdate();
            System.out.println("Internação atualizada com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar internação: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void deletar(int id) {
        String sql = "DELETE FROM Internacao WHERE idInternacao = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Internação deletada com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao deletar internação: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Internacao buscarPorId(int id) {
        String sql = "SELECT * FROM Internacao WHERE idInternacao = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Internacao internacao = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                internacao = buildEntity(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar internação por ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return internacao;
    }

    @Override
    public List<Internacao> listarTodos() {
        String sql = "SELECT * FROM Internacao";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Internacao> internacoes = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                internacoes.add(buildEntity(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar todas as internações: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return internacoes;
    }

    @Override
    protected Internacao buildEntity(ResultSet rs) throws SQLException {
        Internacao internacao = new Internacao();
        internacao.setIdInternacao(rs.getInt("idInternacao"));
        internacao.setDataEntrada(rs.getTimestamp("dataEntrada").toLocalDateTime());
        Timestamp dataSaidaTimestamp = rs.getTimestamp("dataSaida");
        if (dataSaidaTimestamp != null) {
            internacao.setDataSaida(dataSaidaTimestamp.toLocalDateTime());
        }
        internacao.setObservacoes(rs.getString("observacoes"));
        internacao.setIdVeterinario(rs.getInt("idVeterinario"));
        internacao.setIdPaciente(rs.getInt("idPaciente"));
        return internacao;
    }

    @Override
    protected void prepareStatementForInsert(PreparedStatement stmt, Internacao internacao) throws SQLException {
        stmt.setTimestamp(1, Timestamp.valueOf(internacao.getDataEntrada()));
        if (internacao.getDataSaida() != null) {
            stmt.setTimestamp(2, Timestamp.valueOf(internacao.getDataSaida()));
        } else {
            stmt.setNull(2, java.sql.Types.TIMESTAMP);
        }
        stmt.setString(3, internacao.getObservacoes());
        stmt.setInt(4, internacao.getIdVeterinario());
        stmt.setInt(5, internacao.getIdPaciente());
    }

    @Override
    protected void prepareStatementForUpdate(PreparedStatement stmt, Internacao internacao) throws SQLException {
        stmt.setTimestamp(1, Timestamp.valueOf(internacao.getDataEntrada()));
        if (internacao.getDataSaida() != null) {
            stmt.setTimestamp(2, Timestamp.valueOf(internacao.getDataSaida()));
        } else {
            stmt.setNull(2, java.sql.Types.TIMESTAMP);
        }
        stmt.setString(3, internacao.getObservacoes());
        stmt.setInt(4, internacao.getIdVeterinario());
        stmt.setInt(5, internacao.getIdPaciente());
        stmt.setInt(6, internacao.getIdInternacao());
    }
}
