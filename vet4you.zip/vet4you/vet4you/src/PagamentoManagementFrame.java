import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class PagamentoManagementFrame extends JFrame {
    private Usuario usuarioLogado;
    private PagamentoService pagamentoService;
    private JTable pagamentosTable;
    private DefaultTableModel tableModel;
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public PagamentoManagementFrame(Usuario usuario) {
        this.usuarioLogado = usuario;
        this.pagamentoService = new PagamentoService();

        DesignUtils.setupFrame(this, "Gerenciar Pagamentos");

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(DesignUtils.BACKGROUND_COLOR);

        // Painel de botões
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        buttonPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton addButton = createStyledButton("Adicionar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PagamentoDialog dialog = new PagamentoDialog(PagamentoManagementFrame.this, null);
                dialog.setVisible(true);
                if (dialog.isConfirmed()) {
                    try {
                        pagamentoService.registrarPagamento(dialog.getPagamento());
                        carregarPagamentos();
                        JOptionPane.showMessageDialog(PagamentoManagementFrame.this, "Pagamento registrado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(PagamentoManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        buttonPanel.add(addButton);

        JButton editButton = createStyledButton("Editar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = pagamentosTable.getSelectedRow();
                if (selectedRow != -1) {
                    int idPagamento = (int) tableModel.getValueAt(selectedRow, 0);
                    Pagamento pagamentoToEdit = pagamentoService.buscarPagamentoPorId(idPagamento);
                    
                    PagamentoDialog dialog = new PagamentoDialog(PagamentoManagementFrame.this, pagamentoToEdit);
                    dialog.setVisible(true);
                    
                    if (dialog.isConfirmed()) {
                        try {
                            pagamentoService.atualizarPagamento(dialog.getPagamento());
                            carregarPagamentos();
                            JOptionPane.showMessageDialog(PagamentoManagementFrame.this, "Pagamento atualizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                        } catch (IllegalArgumentException ex) {
                            JOptionPane.showMessageDialog(PagamentoManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(PagamentoManagementFrame.this, "Selecione um pagamento para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(editButton);

        JButton deleteButton = createStyledButton("Deletar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = pagamentosTable.getSelectedRow();
                if (selectedRow != -1) {
                    int confirm = JOptionPane.showConfirmDialog(PagamentoManagementFrame.this, 
                        "Tem certeza que deseja deletar o pagamento selecionado?", "Confirmar Deleção", 
                        JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        int idPagamento = (int) tableModel.getValueAt(selectedRow, 0);
                        pagamentoService.deletarPagamento(idPagamento);
                        carregarPagamentos();
                        JOptionPane.showMessageDialog(PagamentoManagementFrame.this, "Pagamento deletado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(PagamentoManagementFrame.this, "Selecione um pagamento para deletar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(deleteButton);

        JButton refreshButton = createStyledButton("Atualizar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carregarPagamentos();
            }
        });
        buttonPanel.add(refreshButton);

        mainPanel.add(buttonPanel, BorderLayout.NORTH);

        // Tabela de pagamentos
        String[] columnNames = {"ID", "Serviço", "Forma", "Valor", "Status", "Data", "ID Paciente"};
        tableModel = new DefaultTableModel(columnNames, 0);
        pagamentosTable = new JTable(tableModel);
        pagamentosTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        pagamentosTable.setRowHeight(25);
        pagamentosTable.getTableHeader().setBackground(DesignUtils.HEADER_COLOR);
        pagamentosTable.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(pagamentosTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
        carregarPagamentos();
        setVisible(true);
    }

    private JButton createStyledButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.addActionListener(listener);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void carregarPagamentos() {
        tableModel.setRowCount(0);
        List<Pagamento> pagamentos = pagamentoService.listarTodosPagamentos();
        for (Pagamento pagamento : pagamentos) {
            Object[] row = {
                pagamento.getIdPagamento(),
                pagamento.getServico(),
                pagamento.getFormaPagamento(),
                pagamento.getValor(),
                pagamento.getStatus(),
                pagamento.getDataPagamento().format(DATE_TIME_FORMATTER),
                pagamento.getIdPaciente()
            };
            tableModel.addRow(row);
        }
    }
}
