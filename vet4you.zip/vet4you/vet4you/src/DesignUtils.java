import javax.swing.*;
import java.awt.*;

public class DesignUtils {

    // Cores
    public static final Color PRIMARY_COLOR = new Color(30, 144, 255); // Azul moderno (Dodger Blue)
    public static final Color SECONDARY_COLOR = new Color(46, 204, 113); // Verde (Emerald)
    public static final Color BACKGROUND_COLOR = new Color(245, 245, 245); // Cinza claro
    public static final Color TEXT_COLOR = new Color(44, 62, 80); // Azul escuro para texto
    public static final Color HEADER_COLOR = new Color(52, 73, 94); // Azul escuro para cabeçalhos

    // Fontes
    public static final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 18);
    public static final Font LABEL_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font BUTTON_FONT = new Font("Segoe UI", Font.BOLD, 14);

    public static void applyLookAndFeel() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ex) {
                // Ignora se não conseguir
            }
        }
    }

    public static void applyGlobalStyles() {
        // Configurações globais de cores e fontes
        UIManager.put("Label.font", LABEL_FONT);
        UIManager.put("TextField.font", LABEL_FONT);
        UIManager.put("TextArea.font", LABEL_FONT);
        UIManager.put("Button.font", BUTTON_FONT);
        UIManager.put("Table.font", LABEL_FONT);
        UIManager.put("TableHeader.font", BUTTON_FONT);
        UIManager.put("ComboBox.font", LABEL_FONT);
        UIManager.put("Spinner.font", LABEL_FONT);
        
        UIManager.put("Panel.background", BACKGROUND_COLOR);
        UIManager.put("Frame.background", BACKGROUND_COLOR);
        UIManager.put("Button.background", PRIMARY_COLOR);
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("Button.border", BorderFactory.createEmptyBorder(5, 15, 5, 15));
        UIManager.put("Button.focusPainted", false);
        
        UIManager.put("TitledBorder.font", HEADER_FONT);
        UIManager.put("TitledBorder.titleColor", TEXT_COLOR);
    }
    
    public static void setupFrame(JFrame frame, String title) {
        frame.setTitle("Vet4You - " + title);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1000, 700);
        frame.setLocationRelativeTo(null);
        frame.setResizable(true);
        frame.getContentPane().setBackground(BACKGROUND_COLOR);
    }
}
