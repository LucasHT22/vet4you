import java.util.List;

public class EnderecoService {
    private EnderecoDAO enderecoDAO;

    public EnderecoService() {
        this.enderecoDAO = new EnderecoDAO();
    }

    public void cadastrarEndereco(Endereco endereco) {
        if (endereco.getLogradouro() == null || endereco.getLogradouro().isEmpty()) {
            throw new IllegalArgumentException("Logradouro não pode ser vazio.");
        }
        if (endereco.getCep() == null || endereco.getCep().isEmpty()) {
            throw new IllegalArgumentException("CEP não pode ser vazio.");
        }

        enderecoDAO.inserir(endereco);
    }

    public Endereco buscarEnderecoPorId(int id) {
        return enderecoDAO.buscarPorId(id);
    }

    public void atualizarEndereco(Endereco endereco) {
        if (endereco.getIdEndereco() == 0) {
            throw new IllegalArgumentException("ID do endereço não pode ser zero para atualização.");
        }
        enderecoDAO.atualizar(endereco);
    }

    public void deletarEndereco(int id) {
        enderecoDAO.deletar(id);
    }

    public List<Endereco> listarTodosEnderecos() {
        return enderecoDAO.listarTodos();
    }
}
