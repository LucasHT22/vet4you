import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EnderecoDialog extends JDialog {
    private Endereco endereco;
    private JTextField logradouroField;
    private JTextField numeroField;
    private JTextField complementoField;
    private JTextField bairroField;
    private JTextField cidadeField;
    private JTextField estadoField;
    private JTextField cepField;
    private JTextField idUsuarioField;
    private boolean confirmed = false;

    public EnderecoDialog(JFrame parent, Endereco endereco) {
        super(parent, endereco == null ? "Adicionar Endereço" : "Editar Endereço", true);
        this.endereco = endereco;
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Logradouro
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Logradouro:"), gbc);
        gbc.gridx = 1;
        logradouroField = new JTextField(20);
        panel.add(logradouroField, gbc);

        // Número
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Número:"), gbc);
        gbc.gridx = 1;
        numeroField = new JTextField(20);
        panel.add(numeroField, gbc);

        // Complemento
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Complemento:"), gbc);
        gbc.gridx = 1;
        complementoField = new JTextField(20);
        panel.add(complementoField, gbc);

        // Bairro
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Bairro:"), gbc);
        gbc.gridx = 1;
        bairroField = new JTextField(20);
        panel.add(bairroField, gbc);

        // Cidade
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("Cidade:"), gbc);
        gbc.gridx = 1;
        cidadeField = new JTextField(20);
        panel.add(cidadeField, gbc);

        // Estado
        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(new JLabel("Estado (UF):"), gbc);
        gbc.gridx = 1;
        estadoField = new JTextField(20);
        panel.add(estadoField, gbc);

        // CEP
        gbc.gridx = 0;
        gbc.gridy = 6;
        panel.add(new JLabel("CEP:"), gbc);
        gbc.gridx = 1;
        cepField = new JTextField(20);
        panel.add(cepField, gbc);

        // ID Usuário
        gbc.gridx = 0;
        gbc.gridy = 7;
        panel.add(new JLabel("ID Usuário:"), gbc);
        gbc.gridx = 1;
        idUsuarioField = new JTextField(20);
        panel.add(idUsuarioField, gbc);

        // Botões de Ação
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = new JButton("Salvar");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    saveEndereco();
                    confirmed = true;
                    dispose();
                }
            }
        });
        buttonPanel.add(saveButton);

        JButton cancelButton = new JButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        buttonPanel.add(cancelButton);

        if (endereco != null) {
            loadEnderecoData();
        }

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(parent);
    }

    private void loadEnderecoData() {
        logradouroField.setText(endereco.getLogradouro());
        numeroField.setText(endereco.getNumero());
        complementoField.setText(endereco.getComplemento());
        bairroField.setText(endereco.getBairro());
        cidadeField.setText(endereco.getCidade());
        estadoField.setText(endereco.getEstado());
        cepField.setText(endereco.getCep());
        idUsuarioField.setText(String.valueOf(endereco.getIdUsuario()));
    }

    private void saveEndereco() {
        if (endereco == null) {
            endereco = new Endereco();
        }
        
        endereco.setLogradouro(logradouroField.getText());
        endereco.setNumero(numeroField.getText());
        endereco.setComplemento(complementoField.getText());
        endereco.setBairro(bairroField.getText());
        endereco.setCidade(cidadeField.getText());
        endereco.setEstado(estadoField.getText());
        endereco.setCep(cepField.getText());
        
        try {
            endereco.setIdUsuario(Integer.parseInt(idUsuarioField.getText()));
        } catch (NumberFormatException e) {
            endereco.setIdUsuario(0);
        }
    }

    private boolean validateFields() {
        if (logradouroField.getText().trim().isEmpty() ||
            numeroField.getText().trim().isEmpty() ||
            bairroField.getText().trim().isEmpty() ||
            cidadeField.getText().trim().isEmpty() ||
            estadoField.getText().trim().isEmpty() ||
            cepField.getText().trim().isEmpty() ||
            idUsuarioField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Os campos Logradouro, Número, Bairro, Cidade, Estado, CEP e ID Usuário são obrigatórios.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            Integer.parseInt(idUsuarioField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID Usuário deve ser um número inteiro válido.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
