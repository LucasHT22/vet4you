import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;

public class Pagamento {
    private int idPagamento;
    private String servico;
    private String formaPagamento;
    private BigDecimal valor;
    private String status;
    private LocalDateTime dataPagamento;
    private int idPaciente;

    public Pagamento() {
    }

    public Pagamento(int idPagamento, String servico, String formaPagamento, BigDecimal valor, String status, LocalDateTime dataPagamento, int idPaciente) {
        this.idPagamento = idPagamento;
        this.servico = servico;
        this.formaPagamento = formaPagamento;
        this.valor = valor;
        this.status = status;
        this.dataPagamento = dataPagamento;
        this.idPaciente = idPaciente;
    }

    // Getters e Setters
    public int getIdPagamento() {
        return this.idPagamento;
    }

    public void setIdPagamento(int idPagamento) {
        this.idPagamento = idPagamento;
    }

    public String getServico() {
        return this.servico;
    }

    public void setServico(String servico) {
        this.servico = servico;
    }

    public String getFormaPagamento() {
        return this.formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public BigDecimal getValor() {
        return this.valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getDataPagamento() {
        return this.dataPagamento;
    }

    public void setDataPagamento(LocalDateTime dataPagamento) {
        this.dataPagamento = dataPagamento;
    }

    public int getIdPaciente() {
        return this.idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Pagamento))
            return false;
        Pagamento pagamento = (Pagamento) o;
        return idPagamento == pagamento.idPagamento && Objects.equals(servico, pagamento.servico) && Objects.equals(formaPagamento, pagamento.formaPagamento) && Objects.equals(valor, pagamento.valor) && Objects.equals(status, pagamento.status) && Objects.equals(dataPagamento, pagamento.dataPagamento) && idPaciente == pagamento.idPaciente;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPagamento, servico, formaPagamento, valor, status, dataPagamento, idPaciente);
    }

    @Override
    public String toString() {
        return "{" +
            " idPagamento=\'" + getIdPagamento() + "\'" +
            ", servico=\'" + getServico() + "\'" +
            ", formaPagamento=\'" + getFormaPagamento() + "\'" +
            ", valor=\'" + getValor() + "\'" +
            ", status=\'" + getStatus() + "\'" +
            ", dataPagamento=\'" + getDataPagamento() + "\'" +
            ", idPaciente=\'" + getIdPaciente() + "\'" +
            "}";
    }
}
