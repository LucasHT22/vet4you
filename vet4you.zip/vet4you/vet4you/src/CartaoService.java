import java.time.LocalDate;
import java.util.List;

public class CartaoService {
    private CartaoDAO cartaoDAO;

    public CartaoService() {
        this.cartaoDAO = new CartaoDAO();
    }

    public void cadastrarCartao(Cartao cartao) {
        if (cartao.getPlano() == null || cartao.getPlano().isEmpty()) {
            throw new IllegalArgumentException("Plano do cartão não pode ser vazio.");
        }
        if (cartao.getValidade() == null) {
            throw new IllegalArgumentException("Validade do cartão não pode ser vazia.");
        }
        if (cartao.getValidade().isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Cartão expirado.");
        }
        if (cartao.getTitular() == null || cartao.getTitular().isEmpty()) {
            throw new IllegalArgumentException("Titular do cartão não pode ser vazio.");
        }
        cartaoDAO.inserir(cartao);
    }

    public Cartao buscarCartaoPorId(int id) {
        return cartaoDAO.buscarPorId(id);
    }

    public void atualizarCartao(Cartao cartao) {
        if (cartao.getIdCartao() == 0) {
            throw new IllegalArgumentException("ID do cartão não pode ser zero para atualização.");
        }
        if (cartao.getPlano() == null || cartao.getPlano().isEmpty()) {
            throw new IllegalArgumentException("Plano do cartão não pode ser vazio.");
        }
        if (cartao.getValidade() == null) {
            throw new IllegalArgumentException("Validade do cartão não pode ser vazia.");
        }
        if (cartao.getValidade().isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Cartão expirado.");
        }
        cartaoDAO.atualizar(cartao);
    }

    public void deletarCartao(int id) {
        cartaoDAO.deletar(id);
    }

    public List<Cartao> listarTodosCartoes() {
        return cartaoDAO.listarTodos();
    }
}
