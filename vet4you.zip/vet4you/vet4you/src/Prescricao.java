import java.util.Objects;

public class Prescricao {
    private int idPrescricao;
    private int quantidade;
    private String instrucoes;
    private int idConsulta;
    private int idVeterinario;
    private int idProduto;

    public Prescricao() {
    }

    public Prescricao(int idPrescricao, int quantidade, String instrucoes, int idConsulta, int idVeterinario, int idProduto) {
        this.idPrescricao = idPrescricao;
        this.quantidade = quantidade;
        this.instrucoes = instrucoes;
        this.idConsulta = idConsulta;
        this.idVeterinario = idVeterinario;
        this.idProduto = idProduto;
    }

    // Getters e Setters
    public int getIdPrescricao() {
        return this.idPrescricao;
    }

    public void setIdPrescricao(int idPrescricao) {
        this.idPrescricao = idPrescricao;
    }

    public int getQuantidade() {
        return this.quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getInstrucoes() {
        return this.instrucoes;
    }

    public void setInstrucoes(String instrucoes) {
        this.instrucoes = instrucoes;
    }

    public int getIdConsulta() {
        return this.idConsulta;
    }

    public void setIdConsulta(int idConsulta) {
        this.idConsulta = idConsulta;
    }

    public int getIdVeterinario() {
        return this.idVeterinario;
    }

    public void setIdVeterinario(int idVeterinario) {
        this.idVeterinario = idVeterinario;
    }

    public int getIdProduto() {
        return this.idProduto;
    }

    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Prescricao))
            return false;
        Prescricao prescricao = (Prescricao) o;
        return idPrescricao == prescricao.idPrescricao && quantidade == prescricao.quantidade && Objects.equals(instrucoes, prescricao.instrucoes) && idConsulta == prescricao.idConsulta && idVeterinario == prescricao.idVeterinario && idProduto == prescricao.idProduto;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPrescricao, quantidade, instrucoes, idConsulta, idVeterinario, idProduto);
    }

    @Override
    public String toString() {
        return "{" +
            " idPrescricao=\'" + getIdPrescricao() + "\'" +
            ", quantidade=\'" + getQuantidade() + "\'" +
            ", instrucoes=\'" + getInstrucoes() + "\'" +
            ", idConsulta=\'" + getIdConsulta() + "\'" +
            ", idVeterinario=\'" + getIdVeterinario() + "\'" +
            ", idProduto=\'" + getIdProduto() + "\'" +
            "}";
    }
}

