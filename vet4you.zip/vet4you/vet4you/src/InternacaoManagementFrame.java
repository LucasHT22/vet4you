import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class InternacaoManagementFrame extends JFrame {
    private Usuario usuarioLogado;
    private InternacaoService internacaoService;
    private JTable internacoesTable;
    private DefaultTableModel tableModel;
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public InternacaoManagementFrame(Usuario usuario) {
        this.usuarioLogado = usuario;
        this.internacaoService = new InternacaoService();

        DesignUtils.setupFrame(this, "Gerenciar Internações");

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(DesignUtils.BACKGROUND_COLOR);

        // Painel de botões
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        buttonPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton addButton = createStyledButton("Adicionar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InternacaoDialog dialog = new InternacaoDialog(InternacaoManagementFrame.this, null);
                dialog.setVisible(true);
                if (dialog.isConfirmed()) {
                    try {
                        internacaoService.cadastrarInternacao(dialog.getInternacao());
                        carregarInternacoes();
                        JOptionPane.showMessageDialog(InternacaoManagementFrame.this, "Internação adicionada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(InternacaoManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        buttonPanel.add(addButton);

        JButton editButton = createStyledButton("Editar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = internacoesTable.getSelectedRow();
                if (selectedRow != -1) {
                    int idInternacao = (int) tableModel.getValueAt(selectedRow, 0);
                    Internacao internacaoToEdit = internacaoService.buscarInternacaoPorId(idInternacao);
                    
                    InternacaoDialog dialog = new InternacaoDialog(InternacaoManagementFrame.this, internacaoToEdit);
                    dialog.setVisible(true);
                    
                    if (dialog.isConfirmed()) {
                        try {
                            internacaoService.atualizarInternacao(dialog.getInternacao());
                            carregarInternacoes();
                            JOptionPane.showMessageDialog(InternacaoManagementFrame.this, "Internação atualizada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                        } catch (IllegalArgumentException ex) {
                            JOptionPane.showMessageDialog(InternacaoManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(InternacaoManagementFrame.this, "Selecione uma internação para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(editButton);

        JButton deleteButton = createStyledButton("Deletar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = internacoesTable.getSelectedRow();
                if (selectedRow != -1) {
                    int confirm = JOptionPane.showConfirmDialog(InternacaoManagementFrame.this, 
                        "Tem certeza que deseja deletar a internação selecionada?", "Confirmar Deleção", 
                        JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        int idInternacao = (int) tableModel.getValueAt(selectedRow, 0);
                        internacaoService.deletarInternacao(idInternacao);
                        carregarInternacoes();
                        JOptionPane.showMessageDialog(InternacaoManagementFrame.this, "Internação deletada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(InternacaoManagementFrame.this, "Selecione uma internação para deletar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(deleteButton);

        JButton refreshButton = createStyledButton("Atualizar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carregarInternacoes();
            }
        });
        buttonPanel.add(refreshButton);

        mainPanel.add(buttonPanel, BorderLayout.NORTH);

        // Tabela de internações
        String[] columnNames = {"ID", "Entrada", "Saída", "Observações", "ID Veterinário", "ID Paciente"};
        tableModel = new DefaultTableModel(columnNames, 0);
        internacoesTable = new JTable(tableModel);
        internacoesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        internacoesTable.setRowHeight(25);
        internacoesTable.getTableHeader().setBackground(DesignUtils.HEADER_COLOR);
        internacoesTable.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(internacoesTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
        carregarInternacoes();
        setVisible(true);
    }

    private JButton createStyledButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.addActionListener(listener);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void carregarInternacoes() {
        tableModel.setRowCount(0);
        List<Internacao> internacoes = internacaoService.listarTodasInternacoes();
        for (Internacao internacao : internacoes) {
            Object[] row = {
                internacao.getIdInternacao(),
                internacao.getDataEntrada().format(DATE_TIME_FORMATTER),
                internacao.getDataSaida() != null ? internacao.getDataSaida().format(DATE_TIME_FORMATTER) : "Em Andamento",
                internacao.getObservacoes(),
                internacao.getIdVeterinario(),
                internacao.getIdPaciente()
            };
            tableModel.addRow(row);
        }
    }
}
