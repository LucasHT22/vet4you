import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public abstract class BaseDAOImpl<T> implements BaseDAO<T> {

    protected Connection getConnection() {
        return ConnectionFactory.getConnection();
    }

    protected void closeResources(Connection conn, PreparedStatement stmt, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            System.err.println("Erro ao fechar recursos do banco de dados: " + e.getMessage());
            e.printStackTrace();
        }
    }

    protected abstract T buildEntity(ResultSet rs) throws SQLException;
    protected abstract void prepareStatementForInsert(PreparedStatement stmt, T entity) throws SQLException;
    protected abstract void prepareStatementForUpdate(PreparedStatement stmt, T entity) throws SQLException;
}
