import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VeterinarioDialog extends JDialog {
    private Veterinario veterinario;
    private JTextField nomeField;
    private JTextField especialidadeField;
    private JTextField crmvetField;
    private boolean confirmed = false;

    public VeterinarioDialog(JFrame parent, Veterinario veterinario) {
        super(parent, veterinario == null ? "Adicionar Veterinário" : "Editar Veterinário", true);
        this.veterinario = veterinario;
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(DesignUtils.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Nome
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Nome:"), gbc);
        gbc.gridx = 1;
        nomeField = new JTextField(20);
        panel.add(nomeField, gbc);

        // Especialidade
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Especialidade:"), gbc);
        gbc.gridx = 1;
        especialidadeField = new JTextField(20);
        panel.add(especialidadeField, gbc);

        // CRMVET
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("CRMVET:"), gbc);
        gbc.gridx = 1;
        crmvetField = new JTextField(20);
        panel.add(crmvetField, gbc);

        // Botões de Ação
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        JButton saveButton = createStyledButton("Salvar");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    saveVeterinario();
                    confirmed = true;
                    dispose();
                }
            }
        });
        buttonPanel.add(saveButton);

        JButton cancelButton = createStyledButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        buttonPanel.add(cancelButton);

        if (veterinario != null) {
            loadVeterinarioData();
        }

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(parent);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void loadVeterinarioData() {
        nomeField.setText(veterinario.getNome());
        especialidadeField.setText(veterinario.getEspecialidade());
        crmvetField.setText(veterinario.getCrmvet());
    }

    private void saveVeterinario() {
        if (veterinario == null) {
            veterinario = new Veterinario();
        }
        veterinario.setNome(nomeField.getText());
        veterinario.setEspecialidade(especialidadeField.getText());
        veterinario.setCrmvet(crmvetField.getText());
    }

    private boolean validateFields() {
        if (nomeField.getText().trim().isEmpty() ||
            especialidadeField.getText().trim().isEmpty() ||
            crmvetField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos os campos são obrigatórios.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }

    public Veterinario getVeterinario() {
        return veterinario;
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
