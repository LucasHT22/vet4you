import java.time.LocalDateTime;
import java.util.List;

public class ConsultaService {
    private ConsultaDAO consultaDAO;

    public ConsultaService() {
        this.consultaDAO = new ConsultaDAO();
    }

    public void agendarConsulta(Consulta consulta) {
        if (consulta.getTimestamp() == null) {
            throw new IllegalArgumentException("Data e hora da consulta não podem ser vazias.");
        }
        if (consulta.getIdPaciente() == 0) {
            throw new IllegalArgumentException("Consulta deve estar associada a um paciente.");
        }
        if (consulta.getIdVeterinario() == 0) {
            throw new IllegalArgumentException("Consulta deve estar associada a um veterinário.");
        }
        // Adicionar validações de agendamento (ex: verificar disponibilidade do veterinário)
        consultaDAO.inserir(consulta);
    }

    public Consulta buscarConsultaPorId(int id) {
        return consultaDAO.buscarPorId(id);
    }

    public void atualizarConsulta(Consulta consulta) {
        if (consulta.getIdConsulta() == 0) {
            throw new IllegalArgumentException("ID da consulta não pode ser zero para atualização.");
        }
        consultaDAO.atualizar(consulta);
    }

    public void cancelarConsulta(int id) {
        consultaDAO.deletar(id);
    }

    public List<Consulta> listarTodasConsultas() {
        return consultaDAO.listarTodos();
    }

    public List<Consulta> listarConsultasPorPaciente(int idPaciente) {
        // Implementar no DAO ou filtrar aqui, dependendo da complexidade
        return consultaDAO.listarTodos().stream()
                .filter(c -> c.getIdPaciente() == idPaciente)
                .collect(java.util.stream.Collectors.toList());
    }
}
