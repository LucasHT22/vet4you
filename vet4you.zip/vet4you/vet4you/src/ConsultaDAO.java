import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ConsultaDAO extends BaseDAOImpl<Consulta> {

    @Override
    public void inserir(Consulta consulta) {
        String sql = "INSERT INTO Consulta (timestamp, motivo, diagnostico, idPaciente, idVeterinario) VALUES (?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForInsert(stmt, consulta);
            stmt.executeUpdate();
            System.out.println("Consulta inserida com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao inserir consulta: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void atualizar(Consulta consulta) {
        String sql = "UPDATE Consulta SET timestamp = ?, motivo = ?, diagnostico = ?, idPaciente = ?, idVeterinario = ? WHERE idConsulta = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForUpdate(stmt, consulta);
            stmt.executeUpdate();
            System.out.println("Consulta atualizada com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar consulta: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void deletar(int id) {
        String sql = "DELETE FROM Consulta WHERE idConsulta = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Consulta deletada com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao deletar consulta: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Consulta buscarPorId(int id) {
        String sql = "SELECT * FROM Consulta WHERE idConsulta = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Consulta consulta = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                consulta = buildEntity(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar consulta por ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return consulta;
    }

    @Override
    public List<Consulta> listarTodos() {
        String sql = "SELECT * FROM Consulta";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Consulta> consultas = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                consultas.add(buildEntity(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar todas as consultas: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return consultas;
    }

    @Override
    protected Consulta buildEntity(ResultSet rs) throws SQLException {
        Consulta consulta = new Consulta();
        consulta.setIdConsulta(rs.getInt("idConsulta"));
        consulta.setTimestamp(rs.getTimestamp("timestamp").toLocalDateTime());
        consulta.setMotivo(rs.getString("motivo"));
        consulta.setDiagnostico(rs.getString("diagnostico"));
        consulta.setIdPaciente(rs.getInt("idPaciente"));
        consulta.setIdVeterinario(rs.getInt("idVeterinario"));
        return consulta;
    }

    @Override
    protected void prepareStatementForInsert(PreparedStatement stmt, Consulta consulta) throws SQLException {
        stmt.setTimestamp(1, Timestamp.valueOf(consulta.getTimestamp()));
        stmt.setString(2, consulta.getMotivo());
        stmt.setString(3, consulta.getDiagnostico());
        stmt.setInt(4, consulta.getIdPaciente());
        stmt.setInt(5, consulta.getIdVeterinario());
    }

    @Override
    protected void prepareStatementForUpdate(PreparedStatement stmt, Consulta consulta) throws SQLException {
        prepareStatementForInsert(stmt, consulta); // Reutiliza os mesmos parâmetros para update
        stmt.setInt(6, consulta.getIdConsulta());
    }
}
