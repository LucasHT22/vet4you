import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class UsuarioManagementFrame extends JFrame {
    private Usuario usuarioLogado;
    private UsuarioService usuarioService;
    private JTable usuariosTable;
    private DefaultTableModel tableModel;

    public UsuarioManagementFrame(Usuario usuario) {
        this.usuarioLogado = usuario;
        this.usuarioService = new UsuarioService();

        DesignUtils.setupFrame(this, "Gerenciar Usuários");

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(DesignUtils.BACKGROUND_COLOR);

        // Painel de botões
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        buttonPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton addButton = createStyledButton("Adicionar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UsuarioDialog dialog = new UsuarioDialog(UsuarioManagementFrame.this, null);
                dialog.setVisible(true);
                if (dialog.isConfirmed()) {
                    try {
                        usuarioService.cadastrarUsuario(dialog.getUsuario());
                        carregarUsuarios();
                        JOptionPane.showMessageDialog(UsuarioManagementFrame.this, "Usuário adicionado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(UsuarioManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        buttonPanel.add(addButton);

        JButton editButton = createStyledButton("Editar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = usuariosTable.getSelectedRow();
                if (selectedRow != -1) {
                    int idUsuario = (int) tableModel.getValueAt(selectedRow, 0);
                    Usuario usuarioToEdit = usuarioService.buscarUsuarioPorId(idUsuario);
                    
                    UsuarioDialog dialog = new UsuarioDialog(UsuarioManagementFrame.this, usuarioToEdit);
                    dialog.setVisible(true);
                    
                    if (dialog.isConfirmed()) {
                        try {
                            usuarioService.atualizarUsuario(dialog.getUsuario());
                            carregarUsuarios();
                            JOptionPane.showMessageDialog(UsuarioManagementFrame.this, "Usuário atualizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                        } catch (IllegalArgumentException ex) {
                            JOptionPane.showMessageDialog(UsuarioManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(UsuarioManagementFrame.this, "Selecione um usuário para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(editButton);

        JButton deleteButton = createStyledButton("Deletar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = usuariosTable.getSelectedRow();
                if (selectedRow != -1) {
                    int confirm = JOptionPane.showConfirmDialog(UsuarioManagementFrame.this, 
                        "Tem certeza que deseja deletar o usuário selecionado?", "Confirmar Deleção", 
                        JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        int idUsuario = (int) tableModel.getValueAt(selectedRow, 0);
                        usuarioService.deletarUsuario(idUsuario);
                        carregarUsuarios();
                        JOptionPane.showMessageDialog(UsuarioManagementFrame.this, "Usuário deletado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(UsuarioManagementFrame.this, "Selecione um usuário para deletar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(deleteButton);

        JButton refreshButton = createStyledButton("Atualizar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carregarUsuarios();
            }
        });
        buttonPanel.add(refreshButton);

        mainPanel.add(buttonPanel, BorderLayout.NORTH);

        // Tabela de usuários
        String[] columnNames = {"ID", "Nome", "Email", "Username", "Admin", "Ativo"};
        tableModel = new DefaultTableModel(columnNames, 0);
        usuariosTable = new JTable(tableModel);
        usuariosTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        usuariosTable.setRowHeight(25);
        usuariosTable.getTableHeader().setBackground(DesignUtils.HEADER_COLOR);
        usuariosTable.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(usuariosTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
        carregarUsuarios();
        setVisible(true);
    }

    private JButton createStyledButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.addActionListener(listener);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void carregarUsuarios() {
        tableModel.setRowCount(0);
        List<Usuario> usuarios = usuarioService.listarTodosUsuarios();
        for (Usuario usuario : usuarios) {
            Object[] row = {
                usuario.getIdUsuario(),
                usuario.getNome(),
                usuario.getEmail(),
                usuario.getUsername(),
                usuario.getIsAdmin() ? "Sim" : "Não",
                usuario.getIsActive() ? "Sim" : "Não"
            };
            tableModel.addRow(row);
        }
    }
}
