import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginFrame extends JFrame {
    static {
        DesignUtils.applyLookAndFeel();
        DesignUtils.applyGlobalStyles();
    }
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton signupButton;
    private UsuarioService usuarioService;

    public LoginFrame() {
        setTitle("Vet4You - Login");
        getContentPane().setBackground(DesignUtils.BACKGROUND_COLOR);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setResizable(false);

        usuarioService = new UsuarioService();

        // Painel principal
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Título
        JLabel titleLabel = new JLabel("Bem-vindo ao Vet4You");
        titleLabel.setFont(DesignUtils.HEADER_FONT);
        titleLabel.setForeground(DesignUtils.HEADER_COLOR);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createVerticalStrut(20));

        // Username
        JLabel usernameLabel = new JLabel("Usuário:");
        usernameLabel.setForeground(DesignUtils.TEXT_COLOR);
        mainPanel.add(usernameLabel);
        usernameField = new JTextField();
        usernameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        mainPanel.add(usernameField);
        mainPanel.add(Box.createVerticalStrut(10));

        // Password
        JLabel passwordLabel = new JLabel("Senha:");
        passwordLabel.setForeground(DesignUtils.TEXT_COLOR);
        mainPanel.add(passwordLabel);
        passwordField = new JPasswordField();
        passwordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        mainPanel.add(passwordField);
        mainPanel.add(Box.createVerticalStrut(20));

        // Botões
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 0));

        loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleLogin();
            }
        });
        buttonPanel.add(loginButton);

        signupButton = new JButton("Cadastrar");
        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleSignup();
            }
        });
        buttonPanel.add(signupButton);

        mainPanel.add(buttonPanel);

        add(mainPanel);
        setVisible(true);
    }

    private void handleLogin() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha todos os campos!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (usuarioService.validarLogin(username, password)) {
            JOptionPane.showMessageDialog(this, "Login realizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            Usuario usuario = usuarioService.buscarUsuarioPorUsername(username);
            new DashboardFrame(usuario);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Usuário ou senha inválidos!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleSignup() {
        new SignupFrame();
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginFrame());
    }
}
