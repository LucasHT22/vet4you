import java.util.List;

public class PacienteService {
    private PacienteDAO pacienteDAO;

    public PacienteService() {
        this.pacienteDAO = new PacienteDAO();
    }

    public void cadastrarPaciente(Paciente paciente) {
        if (paciente.getNome() == null || paciente.getNome().isEmpty()) {
            throw new IllegalArgumentException("Nome do paciente não pode ser vazio.");
        }
        if (paciente.getAnimal() == null || paciente.getAnimal().isEmpty()) {
            throw new IllegalArgumentException("Animal não pode ser vazio.");
        }
        if (paciente.getIdUsuario() == 0) {
            throw new IllegalArgumentException("Paciente deve estar associado a um usuário.");
        }
        pacienteDAO.inserir(paciente);
    }

    public Paciente buscarPacientePorId(int id) {
        return pacienteDAO.buscarPorId(id);
    }

    public void atualizarPaciente(Paciente paciente) {
        if (paciente.getIdPaciente() == 0) {
            throw new IllegalArgumentException("ID do paciente não pode ser zero para atualização.");
        }
        pacienteDAO.atualizar(paciente);
    }

    public void deletarPaciente(int id) {
        pacienteDAO.deletar(id);
    }

    public List<Paciente> listarTodosPacientes() {
        return pacienteDAO.listarTodos();
    }
}
