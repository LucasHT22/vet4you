import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class PagamentoDAO extends BaseDAOImpl<Pagamento> {

    @Override
    public void inserir(Pagamento pagamento) {
        String sql = "INSERT INTO Pagamento (servico, formaPagamento, valor, status, dataPagamento, idPaciente) VALUES (?, ?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForInsert(stmt, pagamento);
            stmt.executeUpdate();
            System.out.println("Pagamento inserido com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao inserir pagamento: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void atualizar(Pagamento pagamento) {
        String sql = "UPDATE Pagamento SET servico = ?, formaPagamento = ?, valor = ?, status = ?, dataPagamento = ?, idPaciente = ? WHERE idPagamento = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForUpdate(stmt, pagamento);
            stmt.executeUpdate();
            System.out.println("Pagamento atualizado com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar pagamento: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void deletar(int id) {
        String sql = "DELETE FROM Pagamento WHERE idPagamento = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Pagamento deletado com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao deletar pagamento: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Pagamento buscarPorId(int id) {
        String sql = "SELECT * FROM Pagamento WHERE idPagamento = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Pagamento pagamento = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                pagamento = buildEntity(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar pagamento por ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return pagamento;
    }

    @Override
    public List<Pagamento> listarTodos() {
        String sql = "SELECT * FROM Pagamento";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Pagamento> pagamentos = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                pagamentos.add(buildEntity(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar todos os pagamentos: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return pagamentos;
    }

    @Override
    protected Pagamento buildEntity(ResultSet rs) throws SQLException {
        Pagamento pagamento = new Pagamento();
        pagamento.setIdPagamento(rs.getInt("idPagamento"));
        pagamento.setServico(rs.getString("servico"));
        pagamento.setFormaPagamento(rs.getString("formaPagamento"));
        pagamento.setValor(rs.getBigDecimal("valor"));
        pagamento.setStatus(rs.getString("status"));
        pagamento.setDataPagamento(rs.getTimestamp("dataPagamento").toLocalDateTime());
        pagamento.setIdPaciente(rs.getInt("idPaciente"));
        return pagamento;
    }

    @Override
    protected void prepareStatementForInsert(PreparedStatement stmt, Pagamento pagamento) throws SQLException {
        stmt.setString(1, pagamento.getServico());
        stmt.setString(2, pagamento.getFormaPagamento());
        stmt.setBigDecimal(3, pagamento.getValor());
        stmt.setString(4, pagamento.getStatus());
        stmt.setTimestamp(5, Timestamp.valueOf(pagamento.getDataPagamento()));
        stmt.setInt(6, pagamento.getIdPaciente());
    }

    @Override
    protected void prepareStatementForUpdate(PreparedStatement stmt, Pagamento pagamento) throws SQLException {
        prepareStatementForInsert(stmt, pagamento); // Reutiliza os mesmos parâmetros para update
        stmt.setInt(7, pagamento.getIdPagamento());
    }
}
