import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class PagamentoDialog extends JDialog {
    private Pagamento pagamento;
    private JTextField servicoField;
    private JComboBox<String> formaPagamentoComboBox;
    private JTextField valorField;
    private JComboBox<String> statusComboBox;
    private JSpinner dataPagamentoSpinner;
    private JTextField idPacienteField;
    private boolean confirmed = false;

    public PagamentoDialog(JFrame parent, Pagamento pagamento) {
        super(parent, pagamento == null ? "Registrar Pagamento" : "Editar Pagamento", true);
        this.pagamento = pagamento;
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(DesignUtils.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Serviço
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Serviço:"), gbc);
        gbc.gridx = 1;
        servicoField = new JTextField(20);
        panel.add(servicoField, gbc);

        // Forma de Pagamento
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Forma de Pagamento:"), gbc);
        gbc.gridx = 1;
        formaPagamentoComboBox = new JComboBox<>(new String[]{"Dinheiro", "Cartão", "Transferência", "Pix"});
        panel.add(formaPagamentoComboBox, gbc);

        // Valor
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Valor:"), gbc);
        gbc.gridx = 1;
        valorField = new JTextField(20);
        panel.add(valorField, gbc);

        // Status
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Status:"), gbc);
        gbc.gridx = 1;
        statusComboBox = new JComboBox<>(new String[]{"Pendente", "Pago", "Cancelado"});
        panel.add(statusComboBox, gbc);

        // Data Pagamento
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("Data Pagamento:"), gbc);
        gbc.gridx = 1;
        SpinnerDateModel dateModel = new SpinnerDateModel();
        dataPagamentoSpinner = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dataPagamentoSpinner, "dd/MM/yyyy HH:mm");
        dataPagamentoSpinner.setEditor(dateEditor);
        panel.add(dataPagamentoSpinner, gbc);

        // ID Paciente
        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(new JLabel("ID Paciente:"), gbc);
        gbc.gridx = 1;
        idPacienteField = new JTextField(20);
        panel.add(idPacienteField, gbc);

        // Botões de Ação
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        JButton saveButton = createStyledButton("Salvar");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    savePagamento();
                    confirmed = true;
                    dispose();
                }
            }
        });
        buttonPanel.add(saveButton);

        JButton cancelButton = createStyledButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        buttonPanel.add(cancelButton);

        if (pagamento != null) {
            loadPagamentoData();
        } else {
            dataPagamentoSpinner.setValue(new Date());
            statusComboBox.setSelectedItem("Pendente");
        }

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(parent);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void loadPagamentoData() {
        servicoField.setText(pagamento.getServico());
        formaPagamentoComboBox.setSelectedItem(pagamento.getFormaPagamento());
        valorField.setText(pagamento.getValor().toString());
        statusComboBox.setSelectedItem(pagamento.getStatus());
        Date date = Date.from(pagamento.getDataPagamento().atZone(ZoneId.systemDefault()).toInstant());
        dataPagamentoSpinner.setValue(date);
        idPacienteField.setText(String.valueOf(pagamento.getIdPaciente()));
    }

    private void savePagamento() {
        if (pagamento == null) {
            pagamento = new Pagamento();
        }
        
        pagamento.setServico(servicoField.getText());
        pagamento.setFormaPagamento((String) formaPagamentoComboBox.getSelectedItem());
        pagamento.setStatus((String) statusComboBox.getSelectedItem());
        
        try {
            pagamento.setValor(new BigDecimal(valorField.getText()));
        } catch (NumberFormatException e) {
            pagamento.setValor(BigDecimal.ZERO);
        }
        
        Date date = (Date) dataPagamentoSpinner.getValue();
        LocalDateTime ldt = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        pagamento.setDataPagamento(ldt);
        
        try {
            pagamento.setIdPaciente(Integer.parseInt(idPacienteField.getText()));
        } catch (NumberFormatException e) {
            pagamento.setIdPaciente(0);
        }
    }

    private boolean validateFields() {
        if (servicoField.getText().trim().isEmpty() ||
            valorField.getText().trim().isEmpty() ||
            idPacienteField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Os campos Serviço, Valor e ID Paciente são obrigatórios.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            BigDecimal valor = new BigDecimal(valorField.getText());
            if (valor.compareTo(BigDecimal.ZERO) <= 0) {
                JOptionPane.showMessageDialog(this, "Valor deve ser um número positivo.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Valor deve ser um número decimal válido.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            Integer.parseInt(idPacienteField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID Paciente deve ser um número inteiro válido.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }

    public Pagamento getPagamento() {
        return pagamento;
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
