import java.util.List;

public class PrescricaoService {
    private PrescricaoDAO prescricaoDAO;

    public PrescricaoService() {
        this.prescricaoDAO = new PrescricaoDAO();
    }

    public void cadastrarPrescricao(Prescricao prescricao) {
        if (prescricao.getQuantidade() <= 0) {
            throw new IllegalArgumentException("Quantidade da prescrição deve ser maior que zero.");
        }
        if (prescricao.getInstrucoes() == null || prescricao.getInstrucoes().isEmpty()) {
            throw new IllegalArgumentException("Instruções da prescrição não podem ser vazias.");
        }
        if (prescricao.getIdConsulta() == 0) {
            throw new IllegalArgumentException("Prescrição deve estar associada a uma consulta.");
        }
        if (prescricao.getIdVeterinario() == 0) {
            throw new IllegalArgumentException("Prescrição deve estar associada a um veterinário.");
        }
        if (prescricao.getIdProduto() == 0) {
            throw new IllegalArgumentException("Prescrição deve estar associada a um produto.");
        }
        prescricaoDAO.inserir(prescricao);
    }

    public Prescricao buscarPrescricaoPorId(int id) {
        return prescricaoDAO.buscarPorId(id);
    }

    public void atualizarPrescricao(Prescricao prescricao) {
        if (prescricao.getIdPrescricao() == 0) {
            throw new IllegalArgumentException("ID da prescrição não pode ser zero para atualização.");
        }
        if (prescricao.getQuantidade() <= 0) {
            throw new IllegalArgumentException("Quantidade da prescrição deve ser maior que zero.");
        }
        prescricaoDAO.atualizar(prescricao);
    }

    public void deletarPrescricao(int id) {
        prescricaoDAO.deletar(id);
    }

    public List<Prescricao> listarTodasPrescricoes() {
        return prescricaoDAO.listarTodos();
    }

    public List<Prescricao> listarPrescricoesPorConsulta(int idConsulta) {
        return prescricaoDAO.listarTodos().stream()
                .filter(p -> p.getIdConsulta() == idConsulta)
                .collect(java.util.stream.Collectors.toList());
    }
}
