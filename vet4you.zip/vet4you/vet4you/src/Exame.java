import java.time.LocalDate;
import java.util.Objects;

public class Exame {
    private int idExame;
    private String tipo;
    private String resultado;
    private LocalDate data;
    private int idConsulta;

    public Exame() {
    }

    public Exame(int idExame, String tipo, String resultado, LocalDate data, int idConsulta) {
        this.idExame = idExame;
        this.tipo = tipo;
        this.resultado = resultado;
        this.data = data;
        this.idConsulta = idConsulta;
    }

    // Getters e Setters
    public int getIdExame() {
        return this.idExame;
    }

    public void setIdExame(int idExame) {
        this.idExame = idExame;
    }

    public String getTipo() {
        return this.tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getResultado() {
        return this.resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public LocalDate getData() {
        return this.data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public int getIdConsulta() {
        return this.idConsulta;
    }

    public void setIdConsulta(int idConsulta) {
        this.idConsulta = idConsulta;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Exame))
            return false;
        Exame exame = (Exame) o;
        return idExame == exame.idExame && Objects.equals(tipo, exame.tipo) && Objects.equals(resultado, exame.resultado) && Objects.equals(data, exame.data) && idConsulta == exame.idConsulta;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idExame, tipo, resultado, data, idConsulta);
    }

    @Override
    public String toString() {
        return "{" +
            " idExame=\'" + getIdExame() + "\'" +
            ", tipo=\'" + getTipo() + "\'" +
            ", resultado=\'" + getResultado() + "\'" +
            ", data=\'" + getData() + "\'" +
            ", idConsulta=\'" + getIdConsulta() + "\'" +
            "}";
    }
}
