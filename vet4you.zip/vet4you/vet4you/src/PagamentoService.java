import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class PagamentoService {
    private PagamentoDAO pagamentoDAO;

    public PagamentoService() {
        this.pagamentoDAO = new PagamentoDAO();
    }

    public void registrarPagamento(Pagamento pagamento) {
        if (pagamento.getServico() == null || pagamento.getServico().isEmpty()) {
            throw new IllegalArgumentException("Serviço do pagamento não pode ser vazio.");
        }
        if (pagamento.getValor() == null || pagamento.getValor().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Valor do pagamento inválido.");
        }
        if (pagamento.getDataPagamento() == null) {
            throw new IllegalArgumentException("Data do pagamento não pode ser vazia.");
        }
        if (pagamento.getIdPaciente() == 0) {
            throw new IllegalArgumentException("Pagamento deve estar associado a um paciente.");
        }
        pagamentoDAO.inserir(pagamento);
    }

    public Pagamento buscarPagamentoPorId(int id) {
        return pagamentoDAO.buscarPorId(id);
    }

    public void atualizarPagamento(Pagamento pagamento) {
        if (pagamento.getIdPagamento() == 0) {
            throw new IllegalArgumentException("ID do pagamento não pode ser zero para atualização.");
        }
        if (pagamento.getServico() == null || pagamento.getServico().isEmpty()) {
            throw new IllegalArgumentException("Serviço do pagamento não pode ser vazio.");
        }
        if (pagamento.getValor() == null || pagamento.getValor().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Valor do pagamento inválido.");
        }
        pagamentoDAO.atualizar(pagamento);
    }

    public void deletarPagamento(int id) {
        pagamentoDAO.deletar(id);
    }

    public List<Pagamento> listarTodosPagamentos() {
        return pagamentoDAO.listarTodos();
    }

    public List<Pagamento> listarPagamentosPorPaciente(int idPaciente) {
        return pagamentoDAO.listarTodos().stream()
                .filter(p -> p.getIdPaciente() == idPaciente)
                .collect(java.util.stream.Collectors.toList());
    }
}
