import java.math.BigDecimal;
import java.util.Objects;

public class Produto {
    private int idProduto;
    private String nome;
    private String tipo;
    private BigDecimal preco;
    private int estoque;
    private Integer idConsulta; // Pode ser null se o produto não estiver associado a uma consulta específica

    public Produto() {
    }

    public Produto(int idProduto, String nome, String tipo, BigDecimal preco, int estoque, Integer idConsulta) {
        this.idProduto = idProduto;
        this.nome = nome;
        this.tipo = tipo;
        this.preco = preco;
        this.estoque = estoque;
        this.idConsulta = idConsulta;
    }

    // Getters e Setters
    public int getIdProduto() {
        return this.idProduto;
    }

    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return this.tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public BigDecimal getPreco() {
        return this.preco;
    }

    public void setPreco(BigDecimal preco) {
        this.preco = preco;
    }

    public int getEstoque() {
        return this.estoque;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

    public Integer getIdConsulta() {
        return this.idConsulta;
    }

    public void setIdConsulta(Integer idConsulta) {
        this.idConsulta = idConsulta;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Produto))
            return false;
        Produto produto = (Produto) o;
        return idProduto == produto.idProduto && Objects.equals(nome, produto.nome) && Objects.equals(tipo, produto.tipo) && Objects.equals(preco, produto.preco) && estoque == produto.estoque && Objects.equals(idConsulta, produto.idConsulta);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduto, nome, tipo, preco, estoque, idConsulta);
    }

    @Override
    public String toString() {
        return "{" +
            " idProduto=\'" + getIdProduto() + "\'" +
            ", nome=\'" + getNome() + "\'" +
            ", tipo=\'" + getTipo() + "\'" +
            ", preco=\'" + getPreco() + "\'" +
            ", estoque=\'" + getEstoque() + "\'" +
            ", idConsulta=\'" + getIdConsulta() + "\'" +
            "}";
    }
}
