import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;

public class ProdutoDialog extends JDialog {
    private Produto produto;
    private JTextField nomeField;
    private JTextField tipoField;
    private JTextField precoField;
    private JTextField estoqueField;
    private JTextField idConsultaField;
    private boolean confirmed = false;

    public ProdutoDialog(JFrame parent, Produto produto) {
        super(parent, produto == null ? "Adicionar Produto" : "Editar Produto", true);
        this.produto = produto;
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(DesignUtils.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Nome
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Nome:"), gbc);
        gbc.gridx = 1;
        nomeField = new JTextField(20);
        panel.add(nomeField, gbc);

        // Tipo
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Tipo:"), gbc);
        gbc.gridx = 1;
        tipoField = new JTextField(20);
        panel.add(tipoField, gbc);

        // Preço
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Preço:"), gbc);
        gbc.gridx = 1;
        precoField = new JTextField(20);
        panel.add(precoField, gbc);

        // Estoque
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Estoque:"), gbc);
        gbc.gridx = 1;
        estoqueField = new JTextField(20);
        panel.add(estoqueField, gbc);

        // ID Consulta (Opcional)
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("ID Consulta (Opcional):"), gbc);
        gbc.gridx = 1;
        idConsultaField = new JTextField(20);
        panel.add(idConsultaField, gbc);

        // Botões de Ação
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        JButton saveButton = createStyledButton("Salvar");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    saveProduto();
                    confirmed = true;
                    dispose();
                }
            }
        });
        buttonPanel.add(saveButton);

        JButton cancelButton = createStyledButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        buttonPanel.add(cancelButton);

        if (produto != null) {
            loadProdutoData();
        }

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(parent);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void loadProdutoData() {
        nomeField.setText(produto.getNome());
        tipoField.setText(produto.getTipo());
        precoField.setText(produto.getPreco().toString());
        estoqueField.setText(String.valueOf(produto.getEstoque()));
        idConsultaField.setText(produto.getIdConsulta() != null ? String.valueOf(produto.getIdConsulta()) : "");
    }

    private void saveProduto() {
        if (produto == null) {
            produto = new Produto();
        }
        
        produto.setNome(nomeField.getText());
        produto.setTipo(tipoField.getText());
        
        try {
            produto.setPreco(new BigDecimal(precoField.getText()));
        } catch (NumberFormatException e) {
            produto.setPreco(BigDecimal.ZERO);
        }
        
        try {
            produto.setEstoque(Integer.parseInt(estoqueField.getText()));
        } catch (NumberFormatException e) {
            produto.setEstoque(0);
        }
        
        String idConsultaText = idConsultaField.getText().trim();
        if (idConsultaText.isEmpty()) {
            produto.setIdConsulta(null);
        } else {
            try {
                produto.setIdConsulta(Integer.parseInt(idConsultaText));
            } catch (NumberFormatException e) {
                produto.setIdConsulta(null);
            }
        }	}

    private boolean validateFields() {   if (nomeField.getText().trim().isEmpty() ||
            tipoField.getText().trim().isEmpty() ||
            precoField.getText().trim().isEmpty() ||
            estoqueField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Os campos Nome, Tipo, Preço e Estoque são obrigatórios.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            new BigDecimal(precoField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Preço deve ser um número decimal válido.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            int estoque = Integer.parseInt(estoqueField.getText());
            if (estoque < 0) {
                JOptionPane.showMessageDialog(this, "Estoque não pode ser negativo.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Estoque deve ser um número inteiro válido.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        String idConsultaText = idConsultaField.getText().trim();
        if (!idConsultaText.isEmpty()) {
            try {
                Integer.parseInt(idConsultaText);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "ID Consulta deve ser um número inteiro válido ou vazio.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        
        return true;
    }

    public Produto getProduto() {
        return produto;
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
