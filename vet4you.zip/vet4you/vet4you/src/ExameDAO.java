import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ExameDAO extends BaseDAOImpl<Exame> {

    @Override
    public void inserir(Exame exame) {
        String sql = "INSERT INTO Exame (tipo, resultado, data, idConsulta) VALUES (?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForInsert(stmt, exame);
            stmt.executeUpdate();
            System.out.println("Exame inserido com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao inserir exame: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void atualizar(Exame exame) {
        String sql = "UPDATE Exame SET tipo = ?, resultado = ?, data = ?, idConsulta = ? WHERE idExame = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForUpdate(stmt, exame);
            stmt.executeUpdate();
            System.out.println("Exame atualizado com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar exame: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void deletar(int id) {
        String sql = "DELETE FROM Exame WHERE idExame = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Exame deletado com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao deletar exame: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Exame buscarPorId(int id) {
        String sql = "SELECT * FROM Exame WHERE idExame = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Exame exame = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                exame = buildEntity(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar exame por ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return exame;
    }

    @Override
    public List<Exame> listarTodos() {
        String sql = "SELECT * FROM Exame";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Exame> exames = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                exames.add(buildEntity(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar todos os exames: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return exames;
    }

    @Override
    protected Exame buildEntity(ResultSet rs) throws SQLException {
        Exame exame = new Exame();
        exame.setIdExame(rs.getInt("idExame"));
        exame.setTipo(rs.getString("tipo"));
        exame.setResultado(rs.getString("resultado"));
        Date sqlDate = rs.getDate("data");
        if (sqlDate != null) {
            exame.setData(sqlDate.toLocalDate());
        }
        exame.setIdConsulta(rs.getInt("idConsulta"));
        return exame;
    }

    @Override
    protected void prepareStatementForInsert(PreparedStatement stmt, Exame exame) throws SQLException {
        stmt.setString(1, exame.getTipo());
        stmt.setString(2, exame.getResultado());
        stmt.setDate(3, exame.getData() != null ? Date.valueOf(exame.getData()) : null);
        stmt.setInt(4, exame.getIdConsulta());
    }

    @Override
    protected void prepareStatementForUpdate(PreparedStatement stmt, Exame exame) throws SQLException {
        prepareStatementForInsert(stmt, exame); // Reutiliza os mesmos parâmetros para update
        stmt.setInt(5, exame.getIdExame());
    }
}
