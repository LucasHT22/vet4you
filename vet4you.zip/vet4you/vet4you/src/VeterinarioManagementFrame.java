import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class VeterinarioManagementFrame extends JFrame {
    private Usuario usuarioLogado;
    private VeterinarioService veterinarioService;
    private JTable veterinariosTable;
    private DefaultTableModel tableModel;

    public VeterinarioManagementFrame(Usuario usuario) {
        this.usuarioLogado = usuario;
        this.veterinarioService = new VeterinarioService();

        DesignUtils.setupFrame(this, "Gerenciar Veterinários");

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(DesignUtils.BACKGROUND_COLOR);

        // Painel de botões
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        buttonPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton addButton = createStyledButton("Adicionar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VeterinarioDialog dialog = new VeterinarioDialog(VeterinarioManagementFrame.this, null);
                dialog.setVisible(true);
                if (dialog.isConfirmed()) {
                    try {
                        veterinarioService.cadastrarVeterinario(dialog.getVeterinario());
                        carregarVeterinarios();
                        JOptionPane.showMessageDialog(VeterinarioManagementFrame.this, "Veterinário adicionado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(VeterinarioManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        buttonPanel.add(addButton);

        JButton editButton = createStyledButton("Editar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = veterinariosTable.getSelectedRow();
                if (selectedRow != -1) {
                    int idVeterinario = (int) tableModel.getValueAt(selectedRow, 0);
                    Veterinario veterinarioToEdit = veterinarioService.buscarVeterinarioPorId(idVeterinario);
                    
                    VeterinarioDialog dialog = new VeterinarioDialog(VeterinarioManagementFrame.this, veterinarioToEdit);
                    dialog.setVisible(true);
                    
                    if (dialog.isConfirmed()) {
                        try {
                            veterinarioService.atualizarVeterinario(dialog.getVeterinario());
                            carregarVeterinarios();
                            JOptionPane.showMessageDialog(VeterinarioManagementFrame.this, "Veterinário atualizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                        } catch (IllegalArgumentException ex) {
                            JOptionPane.showMessageDialog(VeterinarioManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(VeterinarioManagementFrame.this, "Selecione um veterinário para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(editButton);

        JButton deleteButton = createStyledButton("Deletar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = veterinariosTable.getSelectedRow();
                if (selectedRow != -1) {
                    int confirm = JOptionPane.showConfirmDialog(VeterinarioManagementFrame.this, 
                        "Tem certeza que deseja deletar o veterinário selecionado?", "Confirmar Deleção", 
                        JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        int idVeterinario = (int) tableModel.getValueAt(selectedRow, 0);
                        veterinarioService.deletarVeterinario(idVeterinario);
                        carregarVeterinarios();
                        JOptionPane.showMessageDialog(VeterinarioManagementFrame.this, "Veterinário deletado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(VeterinarioManagementFrame.this, "Selecione um veterinário para deletar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(deleteButton);

        JButton refreshButton = createStyledButton("Atualizar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carregarVeterinarios();
            }
        });
        buttonPanel.add(refreshButton);

        mainPanel.add(buttonPanel, BorderLayout.NORTH);

        // Tabela de veterinários
        String[] columnNames = {"ID", "Nome", "Especialidade", "CRMVET"};
        tableModel = new DefaultTableModel(columnNames, 0);
        veterinariosTable = new JTable(tableModel);
        veterinariosTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        veterinariosTable.setRowHeight(25);
        veterinariosTable.getTableHeader().setBackground(DesignUtils.HEADER_COLOR);
        veterinariosTable.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(veterinariosTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
        carregarVeterinarios();
        setVisible(true);
    }

    private JButton createStyledButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.addActionListener(listener);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void carregarVeterinarios() {
        tableModel.setRowCount(0);
        List<Veterinario> veterinarios = veterinarioService.listarTodosVeterinarios();
        for (Veterinario veterinario : veterinarios) {
            Object[] row = {
                veterinario.getIdVeterinario(),
                veterinario.getNome(),
                veterinario.getEspecialidade(),
                veterinario.getCrmvet()
            };
            tableModel.addRow(row);
        }
    }
}
