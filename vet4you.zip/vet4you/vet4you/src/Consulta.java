import java.time.LocalDateTime;
import java.util.Objects;

public class Consulta {
    private int idConsulta;
    private LocalDateTime timestamp;
    private String motivo;
    private String diagnostico;
    private int idPaciente;
    private int idVeterinario;

    public Consulta() {
    }

    public Consulta(int idConsulta, LocalDateTime timestamp, String motivo, String diagnostico, int idPaciente, int idVeterinario) {
        this.idConsulta = idConsulta;
        this.timestamp = timestamp;
        this.motivo = motivo;
        this.diagnostico = diagnostico;
        this.idPaciente = idPaciente;
        this.idVeterinario = idVeterinario;
    }

    // Getters e Setters
    public int getIdConsulta() {
        return this.idConsulta;
    }

    public void setIdConsulta(int idConsulta) {
        this.idConsulta = idConsulta;
    }

    public LocalDateTime getTimestamp() {
        return this.timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getMotivo() {
        return this.motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getDiagnostico() {
        return this.diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    public int getIdPaciente() {
        return this.idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public int getIdVeterinario() {
        return this.idVeterinario;
    }

    public void setIdVeterinario(int idVeterinario) {
        this.idVeterinario = idVeterinario;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Consulta))
            return false;
        Consulta consulta = (Consulta) o;
        return idConsulta == consulta.idConsulta && Objects.equals(timestamp, consulta.timestamp) && Objects.equals(motivo, consulta.motivo) && Objects.equals(diagnostico, consulta.diagnostico) && idPaciente == consulta.idPaciente && idVeterinario == consulta.idVeterinario;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idConsulta, timestamp, motivo, diagnostico, idPaciente, idVeterinario);
    }

    @Override
    public String toString() {
        return "{" +
            " idConsulta=\'" + getIdConsulta() + "\'" +
            ", timestamp=\'" + getTimestamp() + "\'" +
            ", motivo=\'" + getMotivo() + "\'" +
            ", diagnostico=\'" + getDiagnostico() + "\'" +
            ", idPaciente=\'" + getIdPaciente() + "\'" +
            ", idVeterinario=\'" + getIdVeterinario() + "\'" +
            "}";
    }
}
