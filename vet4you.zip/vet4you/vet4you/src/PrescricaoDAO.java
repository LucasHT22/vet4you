import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PrescricaoDAO extends BaseDAOImpl<Prescricao> {

    @Override
    public void inserir(Prescricao prescricao) {
        String sql = "INSERT INTO Prescricao (quantidade, instrucoes, idConsulta, idVeterinario, idProduto) VALUES (?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForInsert(stmt, prescricao);
            stmt.executeUpdate();
            System.out.println("Prescrição inserida com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao inserir prescrição: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void atualizar(Prescricao prescricao) {
        String sql = "UPDATE Prescricao SET quantidade = ?, instrucoes = ?, idConsulta = ?, idVeterinario = ?, idProduto = ? WHERE idPrescricao = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForUpdate(stmt, prescricao);
            stmt.executeUpdate();
            System.out.println("Prescrição atualizada com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar prescrição: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void deletar(int id) {
        String sql = "DELETE FROM Prescricao WHERE idPrescricao = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Prescrição deletada com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao deletar prescrição: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Prescricao buscarPorId(int id) {
        String sql = "SELECT * FROM Prescricao WHERE idPrescricao = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Prescricao prescricao = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                prescricao = buildEntity(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar prescrição por ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return prescricao;
    }

    @Override
    public List<Prescricao> listarTodos() {
        String sql = "SELECT * FROM Prescricao";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Prescricao> prescricoes = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                prescricoes.add(buildEntity(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar todas as prescrições: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return prescricoes;
    }

    @Override
    protected Prescricao buildEntity(ResultSet rs) throws SQLException {
        Prescricao prescricao = new Prescricao();
        prescricao.setIdPrescricao(rs.getInt("idPrescricao"));
        prescricao.setQuantidade(rs.getInt("quantidade"));
        prescricao.setInstrucoes(rs.getString("instrucoes"));
        prescricao.setIdConsulta(rs.getInt("idConsulta"));
        prescricao.setIdVeterinario(rs.getInt("idVeterinario"));
        prescricao.setIdProduto(rs.getInt("idProduto"));
        return prescricao;
    }

    @Override
    protected void prepareStatementForInsert(PreparedStatement stmt, Prescricao prescricao) throws SQLException {
        stmt.setInt(1, prescricao.getQuantidade());
        stmt.setString(2, prescricao.getInstrucoes());
        stmt.setInt(3, prescricao.getIdConsulta());
        stmt.setInt(4, prescricao.getIdVeterinario());
        stmt.setInt(5, prescricao.getIdProduto());
    }

    @Override
    protected void prepareStatementForUpdate(PreparedStatement stmt, Prescricao prescricao) throws SQLException {
        prepareStatementForInsert(stmt, prescricao); // Reutiliza os mesmos parâmetros para update
        stmt.setInt(6, prescricao.getIdPrescricao());
    }
}
