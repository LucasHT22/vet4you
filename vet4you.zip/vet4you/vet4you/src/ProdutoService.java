import java.math.BigDecimal;
import java.util.List;

public class ProdutoService {
    private ProdutoDAO produtoDAO;

    public ProdutoService() {
        this.produtoDAO = new ProdutoDAO();
    }

    public void cadastrarProduto(Produto produto) {
        if (produto.getNome() == null || produto.getNome().isEmpty()) {
            throw new IllegalArgumentException("Nome do produto não pode ser vazio.");
        }
        if (produto.getPreco() == null || produto.getPreco().compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Preço do produto inválido.");
        }
        if (produto.getEstoque() < 0) {
            throw new IllegalArgumentException("Estoque do produto não pode ser negativo.");
        }
        produtoDAO.inserir(produto);
    }

    public Produto buscarProdutoPorId(int id) {
        return produtoDAO.buscarPorId(id);
    }

    public void atualizarProduto(Produto produto) {
        if (produto.getIdProduto() == 0) {
            throw new IllegalArgumentException("ID do produto não pode ser zero para atualização.");
        }
        if (produto.getNome() == null || produto.getNome().isEmpty()) {
            throw new IllegalArgumentException("Nome do produto não pode ser vazio.");
        }
        if (produto.getPreco() == null || produto.getPreco().compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Preço do produto inválido.");
        }
        if (produto.getEstoque() < 0) {
            throw new IllegalArgumentException("Estoque do produto não pode ser negativo.");
        }
        produtoDAO.atualizar(produto);
    }

    public void deletarProduto(int id) {
        produtoDAO.deletar(id);
    }

    public List<Produto> listarTodosProdutos() {
        return produtoDAO.listarTodos();
    }

    public List<Produto> listarProdutosPorConsulta(int idConsulta) {
        return produtoDAO.listarTodos().stream()
                .filter(p -> p.getIdConsulta() != null && p.getIdConsulta() == idConsulta)
                .collect(java.util.stream.Collectors.toList());
    }
}
