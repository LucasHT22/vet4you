import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ProdutoManagementFrame extends JFrame {
    private Usuario usuarioLogado;
    private ProdutoService produtoService;
    private JTable produtosTable;
    private DefaultTableModel tableModel;

    public ProdutoManagementFrame(Usuario usuario) {
        this.usuarioLogado = usuario;
        this.produtoService = new ProdutoService();

        DesignUtils.setupFrame(this, "Gerenciar Produtos");

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(DesignUtils.BACKGROUND_COLOR);

        // Painel de botões
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        buttonPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton addButton = createStyledButton("Adicionar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ProdutoDialog dialog = new ProdutoDialog(ProdutoManagementFrame.this, null);
                dialog.setVisible(true);
                if (dialog.isConfirmed()) {
                    try {
                        produtoService.cadastrarProduto(dialog.getProduto());
                        carregarProdutos();
                        JOptionPane.showMessageDialog(ProdutoManagementFrame.this, "Produto adicionado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(ProdutoManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        buttonPanel.add(addButton);

        JButton editButton = createStyledButton("Editar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = produtosTable.getSelectedRow();
                if (selectedRow != -1) {
                    int idProduto = (int) tableModel.getValueAt(selectedRow, 0);
                    Produto produtoToEdit = produtoService.buscarProdutoPorId(idProduto);
                    
                    ProdutoDialog dialog = new ProdutoDialog(ProdutoManagementFrame.this, produtoToEdit);
                    dialog.setVisible(true);
                    
                    if (dialog.isConfirmed()) {
                        try {
                            produtoService.atualizarProduto(dialog.getProduto());
                            carregarProdutos();
                            JOptionPane.showMessageDialog(ProdutoManagementFrame.this, "Produto atualizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                        } catch (IllegalArgumentException ex) {
                            JOptionPane.showMessageDialog(ProdutoManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(ProdutoManagementFrame.this, "Selecione um produto para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(editButton);

        JButton deleteButton = createStyledButton("Deletar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = produtosTable.getSelectedRow();
                if (selectedRow != -1) {
                    int confirm = JOptionPane.showConfirmDialog(ProdutoManagementFrame.this, 
                        "Tem certeza que deseja deletar o produto selecionado?", "Confirmar Deleção", 
                        JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        int idProduto = (int) tableModel.getValueAt(selectedRow, 0);
                        produtoService.deletarProduto(idProduto);
                        carregarProdutos();
                        JOptionPane.showMessageDialog(ProdutoManagementFrame.this, "Produto deletado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(ProdutoManagementFrame.this, "Selecione um produto para deletar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(deleteButton);

        JButton refreshButton = createStyledButton("Atualizar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carregarProdutos();
            }
        });
        buttonPanel.add(refreshButton);

        mainPanel.add(buttonPanel, BorderLayout.NORTH);

        // Tabela de produtos
        String[] columnNames = {"ID", "Nome", "Tipo", "Preço", "Estoque", "ID Consulta"};
        tableModel = new DefaultTableModel(columnNames, 0);
        produtosTable = new JTable(tableModel);
        produtosTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        produtosTable.setRowHeight(25);
        produtosTable.getTableHeader().setBackground(DesignUtils.HEADER_COLOR);
        produtosTable.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(produtosTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
        carregarProdutos();
        setVisible(true);
    }

    private JButton createStyledButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.addActionListener(listener);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void carregarProdutos() {
        tableModel.setRowCount(0);
        List<Produto> produtos = produtoService.listarTodosProdutos();
        for (Produto produto : produtos) {
            Object[] row = {
                produto.getIdProduto(),
                produto.getNome(),
                produto.getTipo(),
                produto.getPreco(),
                produto.getEstoque(),
                produto.getIdConsulta() != null ? produto.getIdConsulta() : "N/A"
            };
            tableModel.addRow(row);
        }
    }
}
