import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PrescricaoDialog extends JDialog {
    private Prescricao prescricao;
    private JTextField quantidadeField;
    private JTextArea instrucoesArea;
    private JTextField idConsultaField;
    private JTextField idVeterinarioField;
    private JTextField idProdutoField;
    private boolean confirmed = false;

    public PrescricaoDialog(JFrame parent, Prescricao prescricao) {
        super(parent, prescricao == null ? "Adicionar Prescrição" : "Editar Prescrição", true);
        this.prescricao = prescricao;
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(DesignUtils.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Quantidade
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Quantidade:"), gbc);
        gbc.gridx = 1;
        quantidadeField = new JTextField(20);
        panel.add(quantidadeField, gbc);

        // Instruções
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Instruções:"), gbc);
        gbc.gridx = 1;
        instrucoesArea = new JTextArea(3, 20);
        JScrollPane instrucoesScrollPane = new JScrollPane(instrucoesArea);
        panel.add(instrucoesScrollPane, gbc);

        // ID Consulta
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("ID Consulta:"), gbc);
        gbc.gridx = 1;
        idConsultaField = new JTextField(20);
        panel.add(idConsultaField, gbc);

        // ID Veterinário
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("ID Veterinário:"), gbc);
        gbc.gridx = 1;
        idVeterinarioField = new JTextField(20);
        panel.add(idVeterinarioField, gbc);

        // ID Produto
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("ID Produto:"), gbc);
        gbc.gridx = 1;
        idProdutoField = new JTextField(20);
        panel.add(idProdutoField, gbc);

        // Botões de Ação
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        JButton saveButton = createStyledButton("Salvar");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    savePrescricao();
                    confirmed = true;
                    dispose();
                }
            }
        });
        buttonPanel.add(saveButton);

        JButton cancelButton = createStyledButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        buttonPanel.add(cancelButton);

        if (prescricao != null) {
            loadPrescricaoData();
        }

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(parent);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void loadPrescricaoData() {
        quantidadeField.setText(String.valueOf(prescricao.getQuantidade()));
        instrucoesArea.setText(prescricao.getInstrucoes());
        idConsultaField.setText(String.valueOf(prescricao.getIdConsulta()));
        idVeterinarioField.setText(String.valueOf(prescricao.getIdVeterinario()));
        idProdutoField.setText(String.valueOf(prescricao.getIdProduto()));
    }

    private void savePrescricao() {
        if (prescricao == null) {
            prescricao = new Prescricao();
        }
        
        try {
            prescricao.setQuantidade(Integer.parseInt(quantidadeField.getText()));
        } catch (NumberFormatException e) {
            prescricao.setQuantidade(0);
        }
        
        prescricao.setInstrucoes(instrucoesArea.getText());
        
        try {
            prescricao.setIdConsulta(Integer.parseInt(idConsultaField.getText()));
        } catch (NumberFormatException e) {
            prescricao.setIdConsulta(0);
        }
        
        try {
            prescricao.setIdVeterinario(Integer.parseInt(idVeterinarioField.getText()));
        } catch (NumberFormatException e) {
            prescricao.setIdVeterinario(0);
        }
        
        try {
            prescricao.setIdProduto(Integer.parseInt(idProdutoField.getText()));
        } catch (NumberFormatException e) {
            prescricao.setIdProduto(0);
        }
    }

    private boolean validateFields() {
        if (quantidadeField.getText().trim().isEmpty() ||
            instrucoesArea.getText().trim().isEmpty() ||
            idConsultaField.getText().trim().isEmpty() ||
            idVeterinarioField.getText().trim().isEmpty() ||
            idProdutoField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos os campos são obrigatórios.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            int quantidade = Integer.parseInt(quantidadeField.getText());
            if (quantidade <= 0) {
                JOptionPane.showMessageDialog(this, "Quantidade deve ser um número inteiro positivo.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
                return false;
            }
            Integer.parseInt(idConsultaField.getText());
            Integer.parseInt(idVeterinarioField.getText());
            Integer.parseInt(idProdutoField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Quantidade, ID Consulta, ID Veterinário e ID Produto devem ser números inteiros válidos.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }

    public Prescricao getPrescricao() {
        return prescricao;
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
