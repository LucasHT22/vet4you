import java.time.LocalDateTime;
import java.util.List;

public class InternacaoService {
    private InternacaoDAO internacaoDAO;

    public InternacaoService() {
        this.internacaoDAO = new InternacaoDAO();
    }

    public void cadastrarInternacao(Internacao internacao) {
        if (internacao.getDataEntrada() == null) {
            throw new IllegalArgumentException("Data de entrada da internação não pode ser vazia.");
        }
        if (internacao.getIdPaciente() == 0) {
            throw new IllegalArgumentException("Internação deve estar associada a um paciente.");
        }
        if (internacao.getIdVeterinario() == 0) {
            throw new IllegalArgumentException("Internação deve estar associada a um veterinário.");
        }
        if (internacao.getDataSaida() != null && internacao.getDataSaida().isBefore(internacao.getDataEntrada())) {
            throw new IllegalArgumentException("Data de saída não pode ser anterior à data de entrada.");
        }
        internacaoDAO.inserir(internacao);
    }

    public Internacao buscarInternacaoPorId(int id) {
        return internacaoDAO.buscarPorId(id);
    }

    public void atualizarInternacao(Internacao internacao) {
        if (internacao.getIdInternacao() == 0) {
            throw new IllegalArgumentException("ID da internação não pode ser zero para atualização.");
        }
        if (internacao.getDataEntrada() == null) {
            throw new IllegalArgumentException("Data de entrada da internação não pode ser vazia.");
        }
        if (internacao.getDataSaida() != null && internacao.getDataSaida().isBefore(internacao.getDataEntrada())) {
            throw new IllegalArgumentException("Data de saída não pode ser anterior à data de entrada.");
        }
        internacaoDAO.atualizar(internacao);
    }

    public void deletarInternacao(int id) {
        internacaoDAO.deletar(id);
    }

    public List<Internacao> listarTodasInternacoes() {
        return internacaoDAO.listarTodos();
    }

    public List<Internacao> listarInternacoesPorPaciente(int idPaciente) {
        return internacaoDAO.listarTodos().stream()
                .filter(i -> i.getIdPaciente() == idPaciente)
                .collect(java.util.stream.Collectors.toList());
    }
}
