import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VeterinarioDAO extends BaseDAOImpl<Veterinario> {

    @Override
    public void inserir(Veterinario veterinario) {
        String sql = "INSERT INTO Veterinario (nome, especialidade, crmvet) VALUES (?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForInsert(stmt, veterinario);
            stmt.executeUpdate();
            System.out.println("Veterinário inserido com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao inserir veterinário: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void atualizar(Veterinario veterinario) {
        String sql = "UPDATE Veterinario SET nome = ?, especialidade = ?, crmvet = ? WHERE idVeterinario = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForUpdate(stmt, veterinario);
            stmt.executeUpdate();
            System.out.println("Veterinário atualizado com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar veterinário: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void deletar(int id) {
        String sql = "DELETE FROM Veterinario WHERE idVeterinario = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Veterinário deletado com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao deletar veterinário: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Veterinario buscarPorId(int id) {
        String sql = "SELECT * FROM Veterinario WHERE idVeterinario = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Veterinario veterinario = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                veterinario = buildEntity(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar veterinário por ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return veterinario;
    }

    @Override
    public List<Veterinario> listarTodos() {
        String sql = "SELECT * FROM Veterinario";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Veterinario> veterinarios = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                veterinarios.add(buildEntity(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar todos os veterinários: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return veterinarios;
    }

    @Override
    protected Veterinario buildEntity(ResultSet rs) throws SQLException {
        Veterinario veterinario = new Veterinario();
        veterinario.setIdVeterinario(rs.getInt("idVeterinario"));
        veterinario.setNome(rs.getString("nome"));
        veterinario.setEspecialidade(rs.getString("especialidade"));
        veterinario.setCrmvet(rs.getString("crmvet"));
        return veterinario;
    }

    @Override
    protected void prepareStatementForInsert(PreparedStatement stmt, Veterinario veterinario) throws SQLException {
        stmt.setString(1, veterinario.getNome());
        stmt.setString(2, veterinario.getEspecialidade());
        stmt.setString(3, veterinario.getCrmvet());
    }

    @Override
    protected void prepareStatementForUpdate(PreparedStatement stmt, Veterinario veterinario) throws SQLException {
        prepareStatementForInsert(stmt, veterinario); // Reutiliza os mesmos parâmetros para update
        stmt.setInt(4, veterinario.getIdVeterinario());
    }
}
