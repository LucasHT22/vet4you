import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UsuarioDialog extends JDialog {
    private Usuario usuario;
    private JTextField nomeField;
    private JTextField telefoneField;
    private JTextField emailField;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JCheckBox isAdminCheckBox;
    private JTextField cpfField;
    private JCheckBox isActiveCheckBox;
    private boolean confirmed = false;

    public UsuarioDialog(JFrame parent, Usuario usuario) {
        super(parent, usuario == null ? "Adicionar Usuário" : "Editar Usuário", true);
        this.usuario = usuario;
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(DesignUtils.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Nome
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Nome:"), gbc);
        gbc.gridx = 1;
        nomeField = new JTextField(20);
        panel.add(nomeField, gbc);

        // Telefone
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Telefone:"), gbc);
        gbc.gridx = 1;
        telefoneField = new JTextField(20);
        panel.add(telefoneField, gbc);

        // Email
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        emailField = new JTextField(20);
        panel.add(emailField, gbc);

        // Username
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1;
        usernameField = new JTextField(20);
        panel.add(usernameField, gbc);

        // Password
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("Senha:"), gbc);
        gbc.gridx = 1;
        passwordField = new JPasswordField(20);
        panel.add(passwordField, gbc);

        // isAdmin
        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(new JLabel("Administrador:"), gbc);
        gbc.gridx = 1;
        isAdminCheckBox = new JCheckBox();
        panel.add(isAdminCheckBox, gbc);

        // CPF
        gbc.gridx = 0;
        gbc.gridy = 6;
        panel.add(new JLabel("CPF:"), gbc);
        gbc.gridx = 1;
        cpfField = new JTextField(20);
        panel.add(cpfField, gbc);

        // isActive
        gbc.gridx = 0;
        gbc.gridy = 7;
        panel.add(new JLabel("Ativo:"), gbc);
        gbc.gridx = 1;
        isActiveCheckBox = new JCheckBox();
        panel.add(isActiveCheckBox, gbc);

        // Botões de Ação
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        JButton saveButton = createStyledButton("Salvar");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    saveUsuario();
                    confirmed = true;
                    dispose();
                }
            }
        });
        buttonPanel.add(saveButton);

        JButton cancelButton = createStyledButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        buttonPanel.add(cancelButton);

        if (usuario != null) {
            loadUsuarioData();
        } else {
            // Valores padrão para novo usuário
            isActiveCheckBox.setSelected(true);
        }

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(parent);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void loadUsuarioData() {
        nomeField.setText(usuario.getNome());
        telefoneField.setText(usuario.getTelefone());
        emailField.setText(usuario.getEmail());
        usernameField.setText(usuario.getUsername());
        isAdminCheckBox.setSelected(usuario.getIsAdmin());
        cpfField.setText(usuario.getCpf());
        isActiveCheckBox.setSelected(usuario.getIsActive());
    }

    private void saveUsuario() {
        if (usuario == null) {
            usuario = new Usuario();
        }
        usuario.setNome(nomeField.getText());
        usuario.setTelefone(telefoneField.getText());
        usuario.setEmail(emailField.getText());
        usuario.setUsername(usernameField.getText());
        usuario.setIsAdmin(isAdminCheckBox.isSelected());
        usuario.setCpf(cpfField.getText());
        usuario.setIsActive(isActiveCheckBox.isSelected());

        String password = new String(passwordField.getPassword());
        if (!password.isEmpty()) {
            usuario.setPassword(password);
        }
    }

    private boolean validateFields() {
        if (nomeField.getText().trim().isEmpty() ||
            telefoneField.getText().trim().isEmpty() ||
            emailField.getText().trim().isEmpty() ||
            usernameField.getText().trim().isEmpty() ||
            cpfField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos os campos (exceto Senha em edição) são obrigatórios.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (usuario == null && new String(passwordField.getPassword()).isEmpty()) {
            JOptionPane.showMessageDialog(this, "A senha é obrigatória para um novo usuário.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
