import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class InternacaoDialog extends JDialog {
    private Internacao internacao;
    private JSpinner dataEntradaSpinner;
    private JSpinner dataSaidaSpinner;
    private JTextArea observacoesArea;
    private JTextField idVeterinarioField;
    private JTextField idPacienteField;
    private boolean confirmed = false;

    public InternacaoDialog(JFrame parent, Internacao internacao) {
        super(parent, internacao == null ? "Adicionar Internação" : "Editar Internação", true);
        this.internacao = internacao;
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(DesignUtils.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Data Entrada
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Data Entrada:"), gbc);
        gbc.gridx = 1;
        SpinnerDateModel entradaModel = new SpinnerDateModel();
        dataEntradaSpinner = new JSpinner(entradaModel);
        JSpinner.DateEditor entradaEditor = new JSpinner.DateEditor(dataEntradaSpinner, "dd/MM/yyyy HH:mm");
        dataEntradaSpinner.setEditor(entradaEditor);
        panel.add(dataEntradaSpinner, gbc);

        // Data Saída (Opcional)
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Data Saída (Opcional):"), gbc);
        gbc.gridx = 1;
        SpinnerDateModel saidaModel = new SpinnerDateModel();
        dataSaidaSpinner = new JSpinner(saidaModel);
        JSpinner.DateEditor saidaEditor = new JSpinner.DateEditor(dataSaidaSpinner, "dd/MM/yyyy HH:mm");
        dataSaidaSpinner.setEditor(saidaEditor);
        dataSaidaSpinner.setValue(new Date()); // Valor inicial para facilitar a edição
        panel.add(dataSaidaSpinner, gbc);

        // Observações
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Observações:"), gbc);
        gbc.gridx = 1;
        observacoesArea = new JTextArea(3, 20);
        JScrollPane observacoesScrollPane = new JScrollPane(observacoesArea);
        panel.add(observacoesScrollPane, gbc);

        // ID Veterinário
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("ID Veterinário:"), gbc);
        gbc.gridx = 1;
        idVeterinarioField = new JTextField(20);
        panel.add(idVeterinarioField, gbc);

        // ID Paciente
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("ID Paciente:"), gbc);
        gbc.gridx = 1;
        idPacienteField = new JTextField(20);
        panel.add(idPacienteField, gbc);

        // Botões de Ação
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        JButton saveButton = createStyledButton("Salvar");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    saveInternacao();
                    confirmed = true;
                    dispose();
                }
            }
        });
        buttonPanel.add(saveButton);

        JButton cancelButton = createStyledButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        buttonPanel.add(cancelButton);

        if (internacao != null) {
            loadInternacaoData();
        }

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(parent);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void loadInternacaoData() {
        Date entradaDate = Date.from(internacao.getDataEntrada().atZone(ZoneId.systemDefault()).toInstant());
        dataEntradaSpinner.setValue(entradaDate);
        
        if (internacao.getDataSaida() != null) {
            Date saidaDate = Date.from(internacao.getDataSaida().atZone(ZoneId.systemDefault()).toInstant());
            dataSaidaSpinner.setValue(saidaDate);
        } else {
            // Se não houver data de saída, limpa o campo ou usa um valor padrão
            dataSaidaSpinner.setValue(new Date()); 
        }
        
        observacoesArea.setText(internacao.getObservacoes());
        idVeterinarioField.setText(String.valueOf(internacao.getIdVeterinario()));
        idPacienteField.setText(String.valueOf(internacao.getIdPaciente()));
    }

    private void saveInternacao() {
        if (internacao == null) {
            internacao = new Internacao();
        }
        
        Date entradaDate = (Date) dataEntradaSpinner.getValue();
        LocalDateTime ldtEntrada = entradaDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        internacao.setDataEntrada(ldtEntrada);
        
        Date saidaDate = (Date) dataSaidaSpinner.getValue();
        LocalDateTime ldtSaida = saidaDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        
        // Se a data de saída for igual à data de entrada (ou muito próxima), consideramos que não foi definida
        if (ldtSaida.isEqual(ldtEntrada) || ldtSaida.isBefore(ldtEntrada)) {
            internacao.setDataSaida(null);
        } else {
            internacao.setDataSaida(ldtSaida);
        }
        
        internacao.setObservacoes(observacoesArea.getText());
        
        try {
            internacao.setIdVeterinario(Integer.parseInt(idVeterinarioField.getText()));
        } catch (NumberFormatException e) {
            internacao.setIdVeterinario(0);
        }
        
        try {
            internacao.setIdPaciente(Integer.parseInt(idPacienteField.getText()));
        } catch (NumberFormatException e) {
            internacao.setIdPaciente(0);
        }
    }

    private boolean validateFields() {
        if (idVeterinarioField.getText().trim().isEmpty() ||
            idPacienteField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Os campos Data Entrada, ID Veterinário e ID Paciente são obrigatórios.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            Integer.parseInt(idVeterinarioField.getText());
            Integer.parseInt(idPacienteField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID Veterinário e ID Paciente devem ser números inteiros válidos.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Validação de Data de Saída (se preenchida)
        Date entradaDate = (Date) dataEntradaSpinner.getValue();
        Date saidaDate = (Date) dataSaidaSpinner.getValue();
        
        if (saidaDate != null && saidaDate.before(entradaDate)) {
            JOptionPane.showMessageDialog(this, "Data de Saída não pode ser anterior à Data de Entrada.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }

    public Internacao getInternacao() {
        return internacao;
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
