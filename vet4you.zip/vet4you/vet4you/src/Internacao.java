import java.time.LocalDateTime;
import java.util.Objects;

public class Internacao {
    private int idInternacao;
    private LocalDateTime dataEntrada;
    private LocalDateTime dataSaida;
    private String observacoes;
    private int idVeterinario;
    private int idPaciente;

    public Internacao() {
    }

    public Internacao(int idInternacao, LocalDateTime dataEntrada, LocalDateTime dataSaida, String observacoes, int idVeterinario, int idPaciente) {
        this.idInternacao = idInternacao;
        this.dataEntrada = dataEntrada;
        this.dataSaida = dataSaida;
        this.observacoes = observacoes;
        this.idVeterinario = idVeterinario;
        this.idPaciente = idPaciente;
    }

    // Getters e Setters
    public int getIdInternacao() {
        return this.idInternacao;
    }

    public void setIdInternacao(int idInternacao) {
        this.idInternacao = idInternacao;
    }

    public LocalDateTime getDataEntrada() {
        return this.dataEntrada;
    }

    public void setDataEntrada(LocalDateTime dataEntrada) {
        this.dataEntrada = dataEntrada;
    }

    public LocalDateTime getDataSaida() {
        return this.dataSaida;
    }

    public void setDataSaida(LocalDateTime dataSaida) {
        this.dataSaida = dataSaida;
    }

    public String getObservacoes() {
        return this.observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public int getIdVeterinario() {
        return this.idVeterinario;
    }

    public void setIdVeterinario(int idVeterinario) {
        this.idVeterinario = idVeterinario;
    }

    public int getIdPaciente() {
        return this.idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Internacao))
            return false;
        Internacao internacao = (Internacao) o;
        return idInternacao == internacao.idInternacao && Objects.equals(dataEntrada, internacao.dataEntrada) && Objects.equals(dataSaida, internacao.dataSaida) && Objects.equals(observacoes, internacao.observacoes) && idVeterinario == internacao.idVeterinario && idPaciente == internacao.idPaciente;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idInternacao, dataEntrada, dataSaida, observacoes, idVeterinario, idPaciente);
    }

    @Override
    public String toString() {
        return "{" +
            " idInternacao=\'" + getIdInternacao() + "\'" +
            ", dataEntrada=\'" + getDataEntrada() + "\'" +
            ", dataSaida=\'" + getDataSaida() + "\'" +
            ", observacoes=\'" + getObservacoes() + "\'" +
            ", idVeterinario=\'" + getIdVeterinario() + "\'" +
            ", idPaciente=\'" + getIdPaciente() + "\'" +
            "}";
    }
}
