import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class PrescricaoManagementFrame extends JFrame {
    private Usuario usuarioLogado;
    private PrescricaoService prescricaoService;
    private JTable prescricoesTable;
    private DefaultTableModel tableModel;

    public PrescricaoManagementFrame(Usuario usuario) {
        this.usuarioLogado = usuario;
        this.prescricaoService = new PrescricaoService();

        DesignUtils.setupFrame(this, "Gerenciar Prescrições");

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(DesignUtils.BACKGROUND_COLOR);

        // Painel de botões
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        buttonPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton addButton = createStyledButton("Adicionar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PrescricaoDialog dialog = new PrescricaoDialog(PrescricaoManagementFrame.this, null);
                dialog.setVisible(true);
                if (dialog.isConfirmed()) {
                    try {
                        prescricaoService.cadastrarPrescricao(dialog.getPrescricao());
                        carregarPrescricoes();
                        JOptionPane.showMessageDialog(PrescricaoManagementFrame.this, "Prescrição adicionada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(PrescricaoManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        buttonPanel.add(addButton);

        JButton editButton = createStyledButton("Editar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = prescricoesTable.getSelectedRow();
                if (selectedRow != -1) {
                    int idPrescricao = (int) tableModel.getValueAt(selectedRow, 0);
                    Prescricao prescricaoToEdit = prescricaoService.buscarPrescricaoPorId(idPrescricao);
                    
                    PrescricaoDialog dialog = new PrescricaoDialog(PrescricaoManagementFrame.this, prescricaoToEdit);
                    dialog.setVisible(true);
                    
                    if (dialog.isConfirmed()) {
                        try {
                            prescricaoService.atualizarPrescricao(dialog.getPrescricao());
                            carregarPrescricoes();
                            JOptionPane.showMessageDialog(PrescricaoManagementFrame.this, "Prescrição atualizada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                        } catch (IllegalArgumentException ex) {
                            JOptionPane.showMessageDialog(PrescricaoManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(PrescricaoManagementFrame.this, "Selecione uma prescrição para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(editButton);

        JButton deleteButton = createStyledButton("Deletar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = prescricoesTable.getSelectedRow();
                if (selectedRow != -1) {
                    int confirm = JOptionPane.showConfirmDialog(PrescricaoManagementFrame.this, 
                        "Tem certeza que deseja deletar a prescrição selecionada?", "Confirmar Deleção", 
                        JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        int idPrescricao = (int) tableModel.getValueAt(selectedRow, 0);
                        prescricaoService.deletarPrescricao(idPrescricao);
                        carregarPrescricoes();
                        JOptionPane.showMessageDialog(PrescricaoManagementFrame.this, "Prescrição deletada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(PrescricaoManagementFrame.this, "Selecione uma prescrição para deletar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(deleteButton);

        JButton refreshButton = createStyledButton("Atualizar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carregarPrescricoes();
            }
        });
        buttonPanel.add(refreshButton);

        mainPanel.add(buttonPanel, BorderLayout.NORTH);

        // Tabela de prescrições
        String[] columnNames = {"ID", "Quantidade", "Instruções", "ID Consulta", "ID Veterinário", "ID Produto"};
        tableModel = new DefaultTableModel(columnNames, 0);
        prescricoesTable = new JTable(tableModel);
        prescricoesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        prescricoesTable.setRowHeight(25);
        prescricoesTable.getTableHeader().setBackground(DesignUtils.HEADER_COLOR);
        prescricoesTable.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(prescricoesTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
        carregarPrescricoes();
        setVisible(true);
    }

    private JButton createStyledButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.addActionListener(listener);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void carregarPrescricoes() {
        tableModel.setRowCount(0);
        List<Prescricao> prescricoes = prescricaoService.listarTodasPrescricoes();
        for (Prescricao prescricao : prescricoes) {
            Object[] row = {
                prescricao.getIdPrescricao(),
                prescricao.getQuantidade(),
                prescricao.getInstrucoes(),
                prescricao.getIdConsulta(),
                prescricao.getIdVeterinario(),
                prescricao.getIdProduto()
            };
            tableModel.addRow(row);
        }
    }
}
