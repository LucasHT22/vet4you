import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CirurgiaDAO extends BaseDAOImpl<Cirurgia> {

    @Override
    public void inserir(Cirurgia cirurgia) {
        String sql = "INSERT INTO Cirurgia (tipo, data, observacoes, idPaciente, idVeterinario) VALUES (?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForInsert(stmt, cirurgia);
            stmt.executeUpdate();
            System.out.println("Cirurgia inserida com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao inserir cirurgia: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void atualizar(Cirurgia cirurgia) {
        String sql = "UPDATE Cirurgia SET tipo = ?, data = ?, observacoes = ?, idPaciente = ?, idVeterinario = ? WHERE idCirurgia = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForUpdate(stmt, cirurgia);
            stmt.executeUpdate();
            System.out.println("Cirurgia atualizada com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar cirurgia: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void deletar(int id) {
        String sql = "DELETE FROM Cirurgia WHERE idCirurgia = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Cirurgia deletada com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao deletar cirurgia: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Cirurgia buscarPorId(int id) {
        String sql = "SELECT * FROM Cirurgia WHERE idCirurgia = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Cirurgia cirurgia = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                cirurgia = buildEntity(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar cirurgia por ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return cirurgia;
    }

    @Override
    public List<Cirurgia> listarTodos() {
        String sql = "SELECT * FROM Cirurgia";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Cirurgia> cirurgias = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                cirurgias.add(buildEntity(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar todas as cirurgias: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return cirurgias;
    }

    @Override
    protected Cirurgia buildEntity(ResultSet rs) throws SQLException {
        Cirurgia cirurgia = new Cirurgia();
        cirurgia.setIdCirurgia(rs.getInt("idCirurgia"));
        cirurgia.setTipo(rs.getString("tipo"));
        cirurgia.setData(rs.getTimestamp("data").toLocalDateTime());
        cirurgia.setObservacoes(rs.getString("observacoes"));
        cirurgia.setIdPaciente(rs.getInt("idPaciente"));
        cirurgia.setIdVeterinario(rs.getInt("idVeterinario"));
        return cirurgia;
    }

    @Override
    protected void prepareStatementForInsert(PreparedStatement stmt, Cirurgia cirurgia) throws SQLException {
        stmt.setString(1, cirurgia.getTipo());
        stmt.setTimestamp(2, Timestamp.valueOf(cirurgia.getData()));
        stmt.setString(3, cirurgia.getObservacoes());
        stmt.setInt(4, cirurgia.getIdPaciente());
        stmt.setInt(5, cirurgia.getIdVeterinario());
    }

    @Override
    protected void prepareStatementForUpdate(PreparedStatement stmt, Cirurgia cirurgia) throws SQLException {
        prepareStatementForInsert(stmt, cirurgia); // Reutiliza os mesmos parâmetros para update
        stmt.setInt(6, cirurgia.getIdCirurgia());
    }
}
