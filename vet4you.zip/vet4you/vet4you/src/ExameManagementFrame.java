import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ExameManagementFrame extends JFrame {
    private Usuario usuarioLogado;
    private ExameService exameService;
    private JTable examesTable;
    private DefaultTableModel tableModel;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public ExameManagementFrame(Usuario usuario) {
        this.usuarioLogado = usuario;
        this.exameService = new ExameService();

        DesignUtils.setupFrame(this, "Gerenciar Exames");

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(DesignUtils.BACKGROUND_COLOR);

        // Painel de botões
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        buttonPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton addButton = createStyledButton("Adicionar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ExameDialog dialog = new ExameDialog(ExameManagementFrame.this, null);
                dialog.setVisible(true);
                if (dialog.isConfirmed()) {
                    try {
                        exameService.cadastrarExame(dialog.getExame());
                        carregarExames();
                        JOptionPane.showMessageDialog(ExameManagementFrame.this, "Exame adicionado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(ExameManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        buttonPanel.add(addButton);

        JButton editButton = createStyledButton("Editar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = examesTable.getSelectedRow();
                if (selectedRow != -1) {
                    int idExame = (int) tableModel.getValueAt(selectedRow, 0);
                    Exame exameToEdit = exameService.buscarExamePorId(idExame);
                    
                    ExameDialog dialog = new ExameDialog(ExameManagementFrame.this, exameToEdit);
                    dialog.setVisible(true);
                    
                    if (dialog.isConfirmed()) {
                        try {
                            exameService.atualizarExame(dialog.getExame());
                            carregarExames();
                            JOptionPane.showMessageDialog(ExameManagementFrame.this, "Exame atualizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                        } catch (IllegalArgumentException ex) {
                            JOptionPane.showMessageDialog(ExameManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(ExameManagementFrame.this, "Selecione um exame para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(editButton);

        JButton deleteButton = createStyledButton("Deletar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = examesTable.getSelectedRow();
                if (selectedRow != -1) {
                    int confirm = JOptionPane.showConfirmDialog(ExameManagementFrame.this, 
                        "Tem certeza que deseja deletar o exame selecionado?", "Confirmar Deleção", 
                        JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        int idExame = (int) tableModel.getValueAt(selectedRow, 0);
                        exameService.deletarExame(idExame);
                        carregarExames();
                        JOptionPane.showMessageDialog(ExameManagementFrame.this, "Exame deletado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(ExameManagementFrame.this, "Selecione um exame para deletar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(deleteButton);

        JButton refreshButton = createStyledButton("Atualizar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carregarExames();
            }
        });
        buttonPanel.add(refreshButton);

        mainPanel.add(buttonPanel, BorderLayout.NORTH);

        // Tabela de exames
        String[] columnNames = {"ID", "Tipo", "Resultado", "Data", "ID Consulta"};
        tableModel = new DefaultTableModel(columnNames, 0);
        examesTable = new JTable(tableModel);
        examesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        examesTable.setRowHeight(25);
        examesTable.getTableHeader().setBackground(DesignUtils.HEADER_COLOR);
        examesTable.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(examesTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
        carregarExames();
        setVisible(true);
    }

    private JButton createStyledButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.addActionListener(listener);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void carregarExames() {
        tableModel.setRowCount(0);
        List<Exame> exames = exameService.listarTodosExames();
        for (Exame exame : exames) {
            Object[] row = {
                exame.getIdExame(),
                exame.getTipo(),
                exame.getResultado(),
                exame.getData() != null ? exame.getData().format(DATE_FORMATTER) : "N/A",
                exame.getIdConsulta()
            };
            tableModel.addRow(row);
        }
    }
}
