import java.util.Objects;

public class Veterinario {
    private int idVeterinario;
    private String nome;
    private String especialidade;
    private String crmvet;

    public Veterinario() {
    }

    public Veterinario(int idVeterinario, String nome, String especialidade, String crmvet) {
        this.idVeterinario = idVeterinario;
        this.nome = nome;
        this.especialidade = especialidade;
        this.crmvet = crmvet;
    }

    // Getters e Setters
    public int getIdVeterinario() {
        return this.idVeterinario;
    }

    public void setIdVeterinario(int idVeterinario) {
        this.idVeterinario = idVeterinario;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEspecialidade() {
        return this.especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public String getCrmvet() {
        return this.crmvet;
    }

    public void setCrmvet(String crmvet) {
        this.crmvet = crmvet;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Veterinario))
            return false;
        Veterinario veterinario = (Veterinario) o;
        return idVeterinario == veterinario.idVeterinario && Objects.equals(nome, veterinario.nome) && Objects.equals(especialidade, veterinario.especialidade) && Objects.equals(crmvet, veterinario.crmvet);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idVeterinario, nome, especialidade, crmvet);
    }

    @Override
    public String toString() {
        return "{" +
            " idVeterinario=\'" + getIdVeterinario() + "\'" +
            ", nome=\'" + getNome() + "\'" +
            ", especialidade=\'" + getEspecialidade() + "\'" +
            ", crmvet=\'" + getCrmvet() + "\'" +
            "}";
    }
}
