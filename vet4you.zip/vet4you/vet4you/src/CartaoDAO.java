import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class CartaoDAO extends BaseDAOImpl<Cartao> {

    @Override
    public void inserir(Cartao cartao) {
        String sql = "INSERT INTO Cartao (plano, validade, titular) VALUES (?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForInsert(stmt, cartao);
            stmt.executeUpdate();
            System.out.println("Cartão inserido com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao inserir cartão: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void atualizar(Cartao cartao) {
        String sql = "UPDATE Cartao SET plano = ?, validade = ?, titular = ? WHERE idCartao = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForUpdate(stmt, cartao);
            stmt.executeUpdate();
            System.out.println("Cartão atualizado com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar cartão: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void deletar(int id) {
        String sql = "DELETE FROM Cartao WHERE idCartao = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Cartão deletado com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao deletar cartão: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Cartao buscarPorId(int id) {
        String sql = "SELECT * FROM Cartao WHERE idCartao = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Cartao cartao = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                cartao = buildEntity(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar cartão por ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return cartao;
    }

    @Override
    public List<Cartao> listarTodos() {
        String sql = "SELECT * FROM Cartao";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Cartao> cartoes = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                cartoes.add(buildEntity(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar todos os cartões: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return cartoes;
    }

    @Override
    protected Cartao buildEntity(ResultSet rs) throws SQLException {
        Cartao cartao = new Cartao();
        cartao.setIdCartao(rs.getInt("idCartao"));
        cartao.setPlano(rs.getString("plano"));
        Date sqlDate = rs.getDate("validade");
        if (sqlDate != null) {
            cartao.setValidade(sqlDate.toLocalDate());
        }
        cartao.setTitular(rs.getString("titular"));
        return cartao;
    }

    @Override
    protected void prepareStatementForInsert(PreparedStatement stmt, Cartao cartao) throws SQLException {
        stmt.setString(1, cartao.getPlano());
        stmt.setDate(2, cartao.getValidade() != null ? Date.valueOf(cartao.getValidade()) : null);
        stmt.setString(3, cartao.getTitular());
    }

    @Override
    protected void prepareStatementForUpdate(PreparedStatement stmt, Cartao cartao) throws SQLException {
        prepareStatementForInsert(stmt, cartao); // Reutiliza os mesmos parâmetros para update
        stmt.setInt(4, cartao.getIdCartao());
    }
}
