import java.time.LocalDateTime;
import java.util.List;

public class CirurgiaService {
    private CirurgiaDAO cirurgiaDAO;

    public CirurgiaService() {
        this.cirurgiaDAO = new CirurgiaDAO();
    }

    public void agendarCirurgia(Cirurgia cirurgia) {
        if (cirurgia.getTipo() == null || cirurgia.getTipo().isEmpty()) {
            throw new IllegalArgumentException("Tipo de cirurgia não pode ser vazio.");
        }
        if (cirurgia.getData() == null) {
            throw new IllegalArgumentException("Data da cirurgia não pode ser vazia.");
        }
        if (cirurgia.getIdPaciente() == 0) {
            throw new IllegalArgumentException("Cirurgia deve estar associada a um paciente.");
        }
        if (cirurgia.getIdVeterinario() == 0) {
            throw new IllegalArgumentException("Cirurgia deve estar associada a um veterinário.");
        }
        // Adicionar validações de agendamento (ex: verificar disponibilidade da sala, equipe)
        cirurgiaDAO.inserir(cirurgia);
    }

    public Cirurgia buscarCirurgiaPorId(int id) {
        return cirurgiaDAO.buscarPorId(id);
    }

    public void atualizarCirurgia(Cirurgia cirurgia) {
        if (cirurgia.getIdCirurgia() == 0) {
            throw new IllegalArgumentException("ID da cirurgia não pode ser zero para atualização.");
        }
        if (cirurgia.getTipo() == null || cirurgia.getTipo().isEmpty()) {
            throw new IllegalArgumentException("Tipo de cirurgia não pode ser vazio.");
        }
        if (cirurgia.getData() == null) {
            throw new IllegalArgumentException("Data da cirurgia não pode ser vazia.");
        }
        cirurgiaDAO.atualizar(cirurgia);
    }

    public void deletarCirurgia(int id) {
        cirurgiaDAO.deletar(id);
    }

    public List<Cirurgia> listarTodasCirurgias() {
        return cirurgiaDAO.listarTodos();
    }

    public List<Cirurgia> listarCirurgiasPorPaciente(int idPaciente) {
        return cirurgiaDAO.listarTodos().stream()
                .filter(c -> c.getIdPaciente() == idPaciente)
                .collect(java.util.stream.Collectors.toList());
    }
}
