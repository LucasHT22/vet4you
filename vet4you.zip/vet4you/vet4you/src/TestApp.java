import java.util.List;

public class TestApp {
    public static void main(String[] args) {
        UsuarioService usuarioService = new UsuarioService();

        // Teste de Cadastro de Usuário
        System.out.println("\n--- Testando Cadastro de Usuário ---");
        Usuario novoUsuario = new Usuario();
        novoUsuario.setNome("Teste User");
        novoUsuario.setEmail("teste@example.com");
        novoUsuario.setUsername("testuser");
        novoUsuario.setPassword("password123");
        novoUsuario.setTelefone("11987654321");
        novoUsuario.setCpf("123.456.789-00");
        novoUsuario.setIsAdmin(false);
        novoUsuario.setIsActive(true);

        try {
            usuarioService.cadastrarUsuario(novoUsuario);
            System.out.println("Usuário 'testuser' cadastrado com sucesso.");
        } catch (IllegalArgumentException e) {
            System.err.println("Erro ao cadastrar usuário: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Erro inesperado ao cadastrar usuário: " + e.getMessage());
        }

        // Teste de Login de Usuário
        System.out.println("\n--- Testando Login de Usuário ---");
        String usernameLogin = "testuser";
        String passwordLogin = "password123";

        if (usuarioService.validarLogin(usernameLogin, passwordLogin)) {
            System.out.println("Login de '" + usernameLogin + "' bem-sucedido.");
        } else {
            System.err.println("Login de '" + usernameLogin + "' falhou.");
        }

        // Teste de Login com credenciais inválidas
        System.out.println("\n--- Testando Login com Credenciais Inválidas ---");
        String usernameInvalid = "invaliduser";
        String passwordInvalid = "wrongpassword";

        if (usuarioService.validarLogin(usernameInvalid, passwordInvalid)) {
            System.err.println("Login de '" + usernameInvalid + "' bem-sucedido (INCORRETO).");
        } else {
            System.out.println("Login de '" + usernameInvalid + "' falhou (CORRETO).");
        }

        // Teste de listagem de usuários
        System.out.println("\n--- Listando todos os usuários ---");
        List<Usuario> usuarios = usuarioService.listarTodosUsuarios();
        if (usuarios.isEmpty()) {
            System.out.println("Nenhum usuário cadastrado.");
        } else {
            for (Usuario u : usuarios) {
                System.out.println(u);
            }
        }
    }
}
