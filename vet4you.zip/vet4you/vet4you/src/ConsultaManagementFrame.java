import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ConsultaManagementFrame extends JFrame {
    private Usuario usuarioLogado;
    private ConsultaService consultaService;
    private JTable consultasTable;
    private DefaultTableModel tableModel;
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public ConsultaManagementFrame(Usuario usuario) {
        this.usuarioLogado = usuario;
        this.consultaService = new ConsultaService();

        DesignUtils.setupFrame(this, "Gerenciar Consultas");

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(DesignUtils.BACKGROUND_COLOR);

        // Painel de botões
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        buttonPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton addButton = createStyledButton("Agendar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ConsultaDialog dialog = new ConsultaDialog(ConsultaManagementFrame.this, null);
                dialog.setVisible(true);
                if (dialog.isConfirmed()) {
                    try {
                        consultaService.agendarConsulta(dialog.getConsulta());
                        carregarConsultas();
                        JOptionPane.showMessageDialog(ConsultaManagementFrame.this, "Consulta agendada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(ConsultaManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        buttonPanel.add(addButton);

        JButton editButton = createStyledButton("Editar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = consultasTable.getSelectedRow();
                if (selectedRow != -1) {
                    int idConsulta = (int) tableModel.getValueAt(selectedRow, 0);
                    Consulta consultaToEdit = consultaService.buscarConsultaPorId(idConsulta);
                    
                    ConsultaDialog dialog = new ConsultaDialog(ConsultaManagementFrame.this, consultaToEdit);
                    dialog.setVisible(true);
                    
                    if (dialog.isConfirmed()) {
                        try {
                            consultaService.atualizarConsulta(dialog.getConsulta());
                            carregarConsultas();
                            JOptionPane.showMessageDialog(ConsultaManagementFrame.this, "Consulta atualizada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                        } catch (IllegalArgumentException ex) {
                            JOptionPane.showMessageDialog(ConsultaManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(ConsultaManagementFrame.this, "Selecione uma consulta para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(editButton);

        JButton deleteButton = createStyledButton("Cancelar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = consultasTable.getSelectedRow();
                if (selectedRow != -1) {
                    int confirm = JOptionPane.showConfirmDialog(ConsultaManagementFrame.this, 
                        "Tem certeza que deseja cancelar a consulta selecionada?", "Confirmar Cancelamento", 
                        JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        int idConsulta = (int) tableModel.getValueAt(selectedRow, 0);
                        consultaService.cancelarConsulta(idConsulta);
                        carregarConsultas();
                        JOptionPane.showMessageDialog(ConsultaManagementFrame.this, "Consulta cancelada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(ConsultaManagementFrame.this, "Selecione uma consulta para cancelar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(deleteButton);

        JButton refreshButton = createStyledButton("Atualizar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carregarConsultas();
            }
        });
        buttonPanel.add(refreshButton);

        mainPanel.add(buttonPanel, BorderLayout.NORTH);

        // Tabela de consultas
        String[] columnNames = {"ID", "Data/Hora", "Motivo", "Diagnóstico", "ID Paciente", "ID Veterinário"};
        tableModel = new DefaultTableModel(columnNames, 0);
        consultasTable = new JTable(tableModel);
        consultasTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        consultasTable.setRowHeight(25);
        consultasTable.getTableHeader().setBackground(DesignUtils.HEADER_COLOR);
        consultasTable.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(consultasTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
        carregarConsultas();
        setVisible(true);
    }

    private JButton createStyledButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.addActionListener(listener);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void carregarConsultas() {
        tableModel.setRowCount(0);
        List<Consulta> consultas = consultaService.listarTodasConsultas();
        for (Consulta consulta : consultas) {
            Object[] row = {
                consulta.getIdConsulta(),
                consulta.getTimestamp().format(DATE_TIME_FORMATTER),
                consulta.getMotivo(),
                consulta.getDiagnostico(),
                consulta.getIdPaciente(),
                consulta.getIdVeterinario()
            };
            tableModel.addRow(row);
        }
    }
}
