import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class CirurgiaManagementFrame extends JFrame {
    private Usuario usuarioLogado;
    private CirurgiaService cirurgiaService;
    private JTable cirurgiasTable;
    private DefaultTableModel tableModel;
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public CirurgiaManagementFrame(Usuario usuario) {
        this.usuarioLogado = usuario;
        this.cirurgiaService = new CirurgiaService();

        DesignUtils.setupFrame(this, "Gerenciar Cirurgias");

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(DesignUtils.BACKGROUND_COLOR);

        // Painel de botões
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        buttonPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton addButton = createStyledButton("Agendar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CirurgiaDialog dialog = new CirurgiaDialog(CirurgiaManagementFrame.this, null);
                dialog.setVisible(true);
                if (dialog.isConfirmed()) {
                    try {
                        cirurgiaService.agendarCirurgia(dialog.getCirurgia());
                        carregarCirurgias();
                        JOptionPane.showMessageDialog(CirurgiaManagementFrame.this, "Cirurgia agendada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(CirurgiaManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        buttonPanel.add(addButton);

        JButton editButton = createStyledButton("Editar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = cirurgiasTable.getSelectedRow();
                if (selectedRow != -1) {
                    int idCirurgia = (int) tableModel.getValueAt(selectedRow, 0);
                    Cirurgia cirurgiaToEdit = cirurgiaService.buscarCirurgiaPorId(idCirurgia);
                    
                    CirurgiaDialog dialog = new CirurgiaDialog(CirurgiaManagementFrame.this, cirurgiaToEdit);
                    dialog.setVisible(true);
                    
                    if (dialog.isConfirmed()) {
                        try {
                            cirurgiaService.atualizarCirurgia(dialog.getCirurgia());
                            carregarCirurgias();
                            JOptionPane.showMessageDialog(CirurgiaManagementFrame.this, "Cirurgia atualizada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                        } catch (IllegalArgumentException ex) {
                            JOptionPane.showMessageDialog(CirurgiaManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(CirurgiaManagementFrame.this, "Selecione uma cirurgia para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(editButton);

        JButton deleteButton = createStyledButton("Deletar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = cirurgiasTable.getSelectedRow();
                if (selectedRow != -1) {
                    int confirm = JOptionPane.showConfirmDialog(CirurgiaManagementFrame.this, 
                        "Tem certeza que deseja deletar a cirurgia selecionada?", "Confirmar Deleção", 
                        JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        int idCirurgia = (int) tableModel.getValueAt(selectedRow, 0);
                        cirurgiaService.deletarCirurgia(idCirurgia);
                        carregarCirurgias();
                        JOptionPane.showMessageDialog(CirurgiaManagementFrame.this, "Cirurgia deletada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(CirurgiaManagementFrame.this, "Selecione uma cirurgia para deletar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(deleteButton);

        JButton refreshButton = createStyledButton("Atualizar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carregarCirurgias();
            }
        });
        buttonPanel.add(refreshButton);

        mainPanel.add(buttonPanel, BorderLayout.NORTH);

        // Tabela de cirurgias
        String[] columnNames = {"ID", "Tipo", "Data/Hora", "Observações", "ID Paciente", "ID Veterinário"};
        tableModel = new DefaultTableModel(columnNames, 0);
        cirurgiasTable = new JTable(tableModel);
        cirurgiasTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        cirurgiasTable.setRowHeight(25);
        cirurgiasTable.getTableHeader().setBackground(DesignUtils.HEADER_COLOR);
        cirurgiasTable.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(cirurgiasTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
        carregarCirurgias();
        setVisible(true);
    }

    private JButton createStyledButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.addActionListener(listener);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void carregarCirurgias() {
        tableModel.setRowCount(0);
        List<Cirurgia> cirurgias = cirurgiaService.listarTodasCirurgias();
        for (Cirurgia cirurgia : cirurgias) {
            Object[] row = {
                cirurgia.getIdCirurgia(),
                cirurgia.getTipo(),
                cirurgia.getData().format(DATE_TIME_FORMATTER),
                cirurgia.getObservacoes(),
                cirurgia.getIdPaciente(),
                cirurgia.getIdVeterinario()
            };
            tableModel.addRow(row);
        }
    }
}
