import java.util.Objects;

public class Endereco {
    private int idEndereco;
    private String logradouro;
    private String numero;
    private String complemento;
    private String bairro;
    private String cidade;
    private String estado;
    private String cep;
    private int idUsuario;

    public Endereco() {
    }

    public Endereco(int idEndereco, String logradouro, String numero, String complemento, String bairro, String cidade, String estado, String cep, int idUsuario) {
        this.idEndereco = idEndereco;
        this.logradouro = logradouro;
        this.numero = numero;
        this.complemento = complemento;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
        this.cep = cep;
        this.idUsuario = idUsuario;
    }

    // Getters e Setters
    public int getIdEndereco() {
        return this.idEndereco;
    }

    public void setIdEndereco(int idEndereco) {
        this.idEndereco = idEndereco;
    }

    public String getLogradouro() {
        return this.logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getNumero() {
        return this.numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getComplemento() {
        return this.complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getBairro() {
        return this.bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return this.cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return this.estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCep() {
        return this.cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public int getIdUsuario() {
        return this.idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Endereco))
            return false;
        Endereco endereco = (Endereco) o;
        return idEndereco == endereco.idEndereco && Objects.equals(logradouro, endereco.logradouro) && Objects.equals(numero, endereco.numero) && Objects.equals(complemento, endereco.complemento) && Objects.equals(bairro, endereco.bairro) && Objects.equals(cidade, endereco.cidade) && Objects.equals(estado, endereco.estado) && Objects.equals(cep, endereco.cep) && idUsuario == endereco.idUsuario;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idEndereco, logradouro, numero, complemento, bairro, cidade, estado, cep, idUsuario);
    }

    @Override
    public String toString() {
        return "{" +
            " idEndereco=\'" + getIdEndereco() + "\'" +
            ", logradouro=\'" + getLogradouro() + "\'" +
            ", numero=\'" + getNumero() + "\'" +
            ", complemento=\'" + getComplemento() + "\'" +
            ", bairro=\'" + getBairro() + "\'" +
            ", cidade=\'" + getCidade() + "\'" +
            ", estado=\'" + getEstado() + "\'" +
            ", cep=\'" + getCep() + "\'" +
            ", idUsuario=\'" + getIdUsuario() + "\'" +
            "}";
    }
}
