import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EnderecoDAO extends BaseDAOImpl<Endereco> {

    @Override
    public void inserir(Endereco endereco) {
        String sql = "INSERT INTO Endereco (logradouro, numero, complemento, bairro, cidade, estado, cep, idUsuario) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForInsert(stmt, endereco);
            stmt.executeUpdate();
            System.out.println("Endereço inserido com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao inserir endereço: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void atualizar(Endereco endereco) {
        String sql = "UPDATE Endereco SET logradouro = ?, numero = ?, complemento = ?, bairro = ?, cidade = ?, estado = ?, cep = ?, idUsuario = ? WHERE idEndereco = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            prepareStatementForUpdate(stmt, endereco);
            stmt.executeUpdate();
            System.out.println("Endereço atualizado com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar endereço: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void deletar(int id) {
        String sql = "DELETE FROM Endereco WHERE idEndereco = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Endereço deletado com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao deletar endereço: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Endereco buscarPorId(int id) {
        String sql = "SELECT * FROM Endereco WHERE idEndereco = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Endereco endereco = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                endereco = buildEntity(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar endereço por ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return endereco;
    }

    @Override
    public List<Endereco> listarTodos() {
        String sql = "SELECT * FROM Endereco";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Endereco> enderecos = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                enderecos.add(buildEntity(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar todos os endereços: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return enderecos;
    }

    @Override
    protected Endereco buildEntity(ResultSet rs) throws SQLException {
        Endereco endereco = new Endereco();
        endereco.setIdEndereco(rs.getInt("idEndereco"));
        endereco.setLogradouro(rs.getString("logradouro"));
        endereco.setNumero(rs.getString("numero"));
        endereco.setComplemento(rs.getString("complemento"));
        endereco.setBairro(rs.getString("bairro"));
        endereco.setCidade(rs.getString("cidade"));
        endereco.setEstado(rs.getString("estado"));
        endereco.setCep(rs.getString("cep"));
        endereco.setIdUsuario(rs.getInt("idUsuario"));
        return endereco;
    }

    @Override
    protected void prepareStatementForInsert(PreparedStatement stmt, Endereco endereco) throws SQLException {
        stmt.setString(1, endereco.getLogradouro());
        stmt.setString(2, endereco.getNumero());
        stmt.setString(3, endereco.getComplemento());
        stmt.setString(4, endereco.getBairro());
        stmt.setString(5, endereco.getCidade());
        stmt.setString(6, endereco.getEstado());
        stmt.setString(7, endereco.getCep());
        stmt.setInt(8, endereco.getIdUsuario());
    }

    @Override
    protected void prepareStatementForUpdate(PreparedStatement stmt, Endereco endereco) throws SQLException {
        prepareStatementForInsert(stmt, endereco); // Reutiliza os mesmos parâmetros para update
        stmt.setInt(9, endereco.getIdEndereco());
    }
}
