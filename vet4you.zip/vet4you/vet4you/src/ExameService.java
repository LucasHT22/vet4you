import java.time.LocalDate;
import java.util.List;

public class ExameService {
    private ExameDAO exameDAO;

    public ExameService() {
        this.exameDAO = new ExameDAO();
    }

    public void cadastrarExame(Exame exame) {
        if (exame.getTipo() == null || exame.getTipo().isEmpty()) {
            throw new IllegalArgumentException("Tipo de exame não pode ser vazio.");
        }
        if (exame.getData() == null) {
            throw new IllegalArgumentException("Data do exame não pode ser vazia.");
        }
        if (exame.getIdConsulta() == 0) {
            throw new IllegalArgumentException("Exame deve estar associado a uma consulta.");
        }
        exameDAO.inserir(exame);
    }

    public Exame buscarExamePorId(int id) {
        return exameDAO.buscarPorId(id);
    }

    public void atualizarExame(Exame exame) {
        if (exame.getIdExame() == 0) {
            throw new IllegalArgumentException("ID do exame não pode ser zero para atualização.");
        }
        exameDAO.atualizar(exame);
    }

    public void deletarExame(int id) {
        exameDAO.deletar(id);
    }

    public List<Exame> listarTodosExames() {
        return exameDAO.listarTodos();
    }

    public List<Exame> listarExamesPorConsulta(int idConsulta) {
        return exameDAO.listarTodos().stream()
                .filter(e -> e.getIdConsulta() == idConsulta)
                .collect(java.util.stream.Collectors.toList());
    }
}
