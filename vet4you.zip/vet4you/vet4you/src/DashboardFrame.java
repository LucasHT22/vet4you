import javax.swing.*;
import java.awt.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DashboardFrame extends JFrame {
    private Usuario usuarioLogado;

    public DashboardFrame(Usuario usuario) {
        DesignUtils.setupFrame(this, "Dashboard");
        this.usuarioLogado = usuario;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Painel principal
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(DesignUtils.BACKGROUND_COLOR);

        // Painel de cabeçalho
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(DesignUtils.HEADER_COLOR);
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel welcomeLabel = new JLabel("Bem-vindo, " + usuarioLogado.getNome() + "!");
        welcomeLabel.setFont(DesignUtils.HEADER_FONT);
        welcomeLabel.setForeground(Color.WHITE);
        headerPanel.add(welcomeLabel, BorderLayout.WEST);

        JButton logoutButton = new JButton("Sair");
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new LoginFrame();
                dispose();
            }
        });
        headerPanel.add(logoutButton, BorderLayout.EAST);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Painel de menu
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new GridLayout(4, 3, 20, 20)); // Aumentar o espaçamento
        menuPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        menuPanel.setBackground(DesignUtils.BACKGROUND_COLOR);

        // Botões de menu
        boolean isAdmin = usuarioLogado.getIsAdmin();
        if (isAdmin) {
            addMenuButton(menuPanel, "Gerenciar Usuários", new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    new UsuarioManagementFrame(usuarioLogado);
                }
            });
        }

        addMenuButton(menuPanel, "Gerenciar Pacientes", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new PacienteManagementFrame(usuarioLogado);
            }
        });

        if (isAdmin) {
            addMenuButton(menuPanel, "Gerenciar Veterinários", new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    new VeterinarioManagementFrame(usuarioLogado);
                }
            });
        }

        addMenuButton(menuPanel, "Agendar Consulta", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ConsultaManagementFrame(usuarioLogado);
            }
        });

        addMenuButton(menuPanel, "Gerenciar Exames", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ExameManagementFrame(usuarioLogado);
            }
        });

        if (isAdmin) {
            addMenuButton(menuPanel, "Gerenciar Produtos", new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    new ProdutoManagementFrame(usuarioLogado);
                }
            });
        }

        addMenuButton(menuPanel, "Gerenciar Prescrições", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new PrescricaoManagementFrame(usuarioLogado);
            }
        });

        addMenuButton(menuPanel, "Gerenciar Internações", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new InternacaoManagementFrame(usuarioLogado);
            }
        });

        addMenuButton(menuPanel, "Gerenciar Cirurgias", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new CirurgiaManagementFrame(usuarioLogado);
            }
        });

        addMenuButton(menuPanel, "Gerenciar Pagamentos", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new PagamentoManagementFrame(usuarioLogado);
            }
        });

        if (isAdmin) {
            addMenuButton(menuPanel, "Gerenciar Cartões", new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    new CartaoManagementFrame(usuarioLogado);
                }
            });
        }

        if (isAdmin) {
            addMenuButton(menuPanel, "Gerenciar Endereços", new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    new EnderecoManagementFrame(usuarioLogado);
                }
            });
        }

        mainPanel.add(menuPanel, BorderLayout.CENTER);

        add(mainPanel);
        setVisible(true);
    }

    private void addMenuButton(JPanel panel, String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.setFont(DesignUtils.BUTTON_FONT);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15)); // Aumentar o padding do botão
        button.addActionListener(listener);
        panel.add(button);
    }
}
