import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class CirurgiaDialog extends JDialog {
    private Cirurgia cirurgia;
    private JTextField tipoField;
    private JSpinner dataSpinner;
    private JTextArea observacoesArea;
    private JTextField idPacienteField;
    private JTextField idVeterinarioField;
    private boolean confirmed = false;

    public CirurgiaDialog(JFrame parent, Cirurgia cirurgia) {
        super(parent, cirurgia == null ? "Agendar Cirurgia" : "Editar Cirurgia", true);
        this.cirurgia = cirurgia;
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(DesignUtils.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Tipo
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Tipo:"), gbc);
        gbc.gridx = 1;
        tipoField = new JTextField(20);
        panel.add(tipoField, gbc);

        // Data
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Data/Hora:"), gbc);
        gbc.gridx = 1;
        SpinnerDateModel dateModel = new SpinnerDateModel();
        dataSpinner = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dataSpinner, "dd/MM/yyyy HH:mm");
        dataSpinner.setEditor(dateEditor);
        panel.add(dataSpinner, gbc);

        // Observações
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Observações:"), gbc);
        gbc.gridx = 1;
        observacoesArea = new JTextArea(3, 20);
        JScrollPane observacoesScrollPane = new JScrollPane(observacoesArea);
        panel.add(observacoesScrollPane, gbc);

        // ID Paciente
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("ID Paciente:"), gbc);
        gbc.gridx = 1;
        idPacienteField = new JTextField(20);
        panel.add(idPacienteField, gbc);

        // ID Veterinário
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("ID Veterinário:"), gbc);
        gbc.gridx = 1;
        idVeterinarioField = new JTextField(20);
        panel.add(idVeterinarioField, gbc);

        // Botões de Ação
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        JButton saveButton = createStyledButton("Salvar");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    saveCirurgia();
                    confirmed = true;
                    dispose();
                }
            }
        });
        buttonPanel.add(saveButton);

        JButton cancelButton = createStyledButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        buttonPanel.add(cancelButton);

        if (cirurgia != null) {
            loadCirurgiaData();
        }

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(parent);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void loadCirurgiaData() {
        tipoField.setText(cirurgia.getTipo());
        Date date = Date.from(cirurgia.getData().atZone(ZoneId.systemDefault()).toInstant());
        dataSpinner.setValue(date);
        observacoesArea.setText(cirurgia.getObservacoes());
        idPacienteField.setText(String.valueOf(cirurgia.getIdPaciente()));
        idVeterinarioField.setText(String.valueOf(cirurgia.getIdVeterinario()));
    }

    private void saveCirurgia() {
        if (cirurgia == null) {
            cirurgia = new Cirurgia();
        }
        
        cirurgia.setTipo(tipoField.getText());
        
        Date date = (Date) dataSpinner.getValue();
        LocalDateTime ldt = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        cirurgia.setData(ldt);
        
        cirurgia.setObservacoes(observacoesArea.getText());
        
        try {
            cirurgia.setIdPaciente(Integer.parseInt(idPacienteField.getText()));
        } catch (NumberFormatException e) {
            cirurgia.setIdPaciente(0);
        }
        
        try {
            cirurgia.setIdVeterinario(Integer.parseInt(idVeterinarioField.getText()));
        } catch (NumberFormatException e) {
            cirurgia.setIdVeterinario(0);
        }
    }

    private boolean validateFields() {
        if (tipoField.getText().trim().isEmpty() ||
            idPacienteField.getText().trim().isEmpty() ||
            idVeterinarioField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Os campos Tipo, Data/Hora, ID Paciente e ID Veterinário são obrigatórios.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            Integer.parseInt(idPacienteField.getText());
            Integer.parseInt(idVeterinarioField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID Paciente e ID Veterinário devem ser números inteiros válidos.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }

    public Cirurgia getCirurgia() {
        return cirurgia;
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
