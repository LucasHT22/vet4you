import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class PacienteManagementFrame extends JFrame {
    private Usuario usuarioLogado;
    private PacienteService pacienteService;
    private JTable pacientesTable;
    private DefaultTableModel tableModel;

    public PacienteManagementFrame(Usuario usuario) {
        this.usuarioLogado = usuario;
        this.pacienteService = new PacienteService();

        DesignUtils.setupFrame(this, "Gerenciar Pacientes");

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(DesignUtils.BACKGROUND_COLOR);

        // Painel de botões
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(DesignUtils.BACKGROUND_COLOR);
        buttonPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton addButton = createStyledButton("Adicionar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PacienteDialog dialog = new PacienteDialog(PacienteManagementFrame.this, null);
                dialog.setVisible(true);
                if (dialog.isConfirmed()) {
                    try {
                        pacienteService.cadastrarPaciente(dialog.getPaciente());
                        carregarPacientes();
                        JOptionPane.showMessageDialog(PacienteManagementFrame.this, "Paciente adicionado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(PacienteManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        buttonPanel.add(addButton);

        JButton editButton = createStyledButton("Editar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = pacientesTable.getSelectedRow();
                if (selectedRow != -1) {
                    int idPaciente = (int) tableModel.getValueAt(selectedRow, 0);
                    Paciente pacienteToEdit = pacienteService.buscarPacientePorId(idPaciente);
                    
                    PacienteDialog dialog = new PacienteDialog(PacienteManagementFrame.this, pacienteToEdit);
                    dialog.setVisible(true);
                    
                    if (dialog.isConfirmed()) {
                        try {
                            pacienteService.atualizarPaciente(dialog.getPaciente());
                            carregarPacientes();
                            JOptionPane.showMessageDialog(PacienteManagementFrame.this, "Paciente atualizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                        } catch (IllegalArgumentException ex) {
                            JOptionPane.showMessageDialog(PacienteManagementFrame.this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(PacienteManagementFrame.this, "Selecione um paciente para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(editButton);

        JButton deleteButton = createStyledButton("Deletar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = pacientesTable.getSelectedRow();
                if (selectedRow != -1) {
                    int confirm = JOptionPane.showConfirmDialog(PacienteManagementFrame.this, 
                        "Tem certeza que deseja deletar o paciente selecionado?", "Confirmar Deleção", 
                        JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        int idPaciente = (int) tableModel.getValueAt(selectedRow, 0);
                        pacienteService.deletarPaciente(idPaciente);
                        carregarPacientes();
                        JOptionPane.showMessageDialog(PacienteManagementFrame.this, "Paciente deletado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(PacienteManagementFrame.this, "Selecione um paciente para deletar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(deleteButton);

        JButton refreshButton = createStyledButton("Atualizar", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carregarPacientes();
            }
        });
        buttonPanel.add(refreshButton);

        mainPanel.add(buttonPanel, BorderLayout.NORTH);

        // Tabela de pacientes
        String[] columnNames = {"ID", "Nome", "Raça", "Animal", "Idade", "Sexo", "ID Dono", "Plano"};
        tableModel = new DefaultTableModel(columnNames, 0);
        pacientesTable = new JTable(tableModel);
        pacientesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        pacientesTable.setRowHeight(25);
        pacientesTable.getTableHeader().setBackground(DesignUtils.HEADER_COLOR);
        pacientesTable.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(pacientesTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
        carregarPacientes();
        setVisible(true);
    }

    private JButton createStyledButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.addActionListener(listener);
        button.setBackground(DesignUtils.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void carregarPacientes() {
        tableModel.setRowCount(0);
        List<Paciente> pacientes = pacienteService.listarTodosPacientes();
        for (Paciente paciente : pacientes) {
            Object[] row = {
                paciente.getIdPaciente(),
                paciente.getNome(),
                paciente.getRaca(),
                paciente.getAnimal(),
                paciente.getIdade(),
                paciente.getSexo(),
                paciente.getIdUsuario(),
                paciente.getPlano()
            };
            tableModel.addRow(row);
        }
    }
}
