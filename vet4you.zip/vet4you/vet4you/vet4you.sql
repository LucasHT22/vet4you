-- Tabela Usuario
CREATE TABLE Usuario (
    idUsuario INTEGER PRIMARY KEY,
    nome TEXT NOT NULL,
    telefone TEXT,
    email TEXT UNIQUE NOT NULL,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    isAdmin BOOLEAN NOT NULL,
    cpf TEXT,
    isActive BOOLEAN NOT NULL
);

-- Tabela Endereco
CREATE TABLE Endereco (
    idEndereco INTEGER PRIMARY KEY,
    logradouro TEXT NOT NULL,
    numero TEXT,
    complemento TEXT,
    bairro TEXT,
    cidade TEXT NOT NULL,
    estado TEXT NOT NULL,
    cep TEXT NOT NULL,
    idUsuario INTEGER,
    FOREIGN KEY (idUsuario) REFERENCES Usuario(idUsuario)
);

-- Tabela Paciente
CREATE TABLE Paciente (
    idPaciente INTEGER PRIMARY KEY,
    nome TEXT NOT NULL,
    raca TEXT,
    animal TEXT NOT NULL,
    idade INTEGER,
    sexo TEXT,
    idUsuario INTEGER NOT NULL,
    plano TEXT,
    FOREIGN KEY (idUsuario) REFERENCES Usuario(idUsuario)
);

-- Tabela Veterinario
CREATE TABLE Veterinario (
    idVeterinario INTEGER PRIMARY KEY,
    nome TEXT NOT NULL,
    especialidade TEXT,
    crmvet TEXT UNIQUE NOT NULL
);

-- Tabela Consulta
CREATE TABLE Consulta (
    idConsulta INTEGER PRIMARY KEY,
    timestamp TEXT NOT NULL,
    motivo TEXT,
    diagnostico TEXT,
    idPaciente INTEGER NOT NULL,
    idVeterinario INTEGER NOT NULL,
    FOREIGN KEY (idPaciente) REFERENCES Paciente(idPaciente),
    FOREIGN KEY (idVeterinario) REFERENCES Veterinario(idVeterinario)
);

-- Tabela Exame
CREATE TABLE Exame (
    idExame INTEGER PRIMARY KEY,
    tipo TEXT NOT NULL,
    resultado TEXT,
    data TEXT NOT NULL,
    idConsulta INTEGER NOT NULL,
    FOREIGN KEY (idConsulta) REFERENCES Consulta(idConsulta)
);

-- Tabela Produto
CREATE TABLE Produto (
    idProduto INTEGER PRIMARY KEY,
    nome TEXT NOT NULL,
    tipo TEXT,
    preco REAL NOT NULL,
    estoque INTEGER NOT NULL,
    idConsulta INTEGER,
    FOREIGN KEY (idConsulta) REFERENCES Consulta(idConsulta)
);

-- Tabela Prescricao
CREATE TABLE Prescricao (
    idPrescricao INTEGER PRIMARY KEY,
    quantidade INTEGER NOT NULL,
    instrucoes TEXT,
    idConsulta INTEGER NOT NULL,
    idVeterinario INTEGER NOT NULL,
    idProduto INTEGER NOT NULL,
    FOREIGN KEY (idConsulta) REFERENCES Consulta(idConsulta),
    FOREIGN KEY (idVeterinario) REFERENCES Veterinario(idVeterinario),
    FOREIGN KEY (idProduto) REFERENCES Produto(idProduto)
);

-- Tabela Internacao
CREATE TABLE Internacao (
    idInternacao INTEGER PRIMARY KEY,
    dataEntrada TEXT NOT NULL,
    dataSaida TEXT,
    observacoes TEXT,
    idVeterinario INTEGER NOT NULL,
    idPaciente INTEGER NOT NULL,
    FOREIGN KEY (idVeterinario) REFERENCES Veterinario(idVeterinario),
    FOREIGN KEY (idPaciente) REFERENCES Paciente(idPaciente)
);

-- Tabela Cirurgia
CREATE TABLE Cirurgia (
    idCirurgia INTEGER PRIMARY KEY,
    tipo TEXT NOT NULL,
    data TEXT NOT NULL,
    observacoes TEXT,
    idPaciente INTEGER NOT NULL,
    idVeterinario INTEGER NOT NULL,
    FOREIGN KEY (idPaciente) REFERENCES Paciente(idPaciente),
    FOREIGN KEY (idVeterinario) REFERENCES Veterinario(idVeterinario)
);

-- Tabela Pagamento
CREATE TABLE Pagamento (
    idPagamento INTEGER PRIMARY KEY,
    servico TEXT NOT NULL,
    formaPagamento TEXT,
    valor REAL NOT NULL,
    status TEXT,
    dataPagamento TEXT NOT NULL,
    idPaciente INTEGER NOT NULL,
    FOREIGN KEY (idPaciente) REFERENCES Paciente(idPaciente)
);

-- Tabela Cartao
CREATE TABLE Cartao (
    idCartao INTEGER PRIMARY KEY,
    plano TEXT NOT NULL,
    validade TEXT NOT NULL,
    titular TEXT NOT NULL
);
