/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.model;

import java.sql.Date;

public class Pagamento {
    private int idPagamento;
    private String servico;
    private String formaPagamento;
    private double valor;
    private char status; // 's' para pago, 'n' para devedor
    private Date dataPagamento;
    private int idPaciente;

    public Pagamento(int idPagamento, String servico, String formaPagamento, double valor, char status, Date dataPagamento, int idPaciente) {
        this.idPagamento = idPagamento;
        this.servico = servico;
        this.formaPagamento = formaPagamento;
        this.valor = valor;
        this.status = status;
        this.dataPagamento = dataPagamento;
        this.idPaciente = idPaciente;
    }

    // Getters e Setters
    public int getIdPagamento() {
        return idPagamento;
    }

    public void setIdPagamento(int idPagamento) {
        this.idPagamento = idPagamento;
    }

    public String getServico() {
        return servico;
    }

    public void setServico(String servico) {
        this.servico = servico;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public char getStatus() {
        return status;
    }

    public void setStatus(char status) {
        this.status = status;
    }

    public Date getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(Date dataPagamento) {
        this.dataPagamento = dataPagamento;
    }

    public int getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    @Override
    public String toString() {
        return "Pagamento{" +
                "idPagamento=" + idPagamento +
                ", servico='" + servico + '\'' +
                ", formaPagamento='" + formaPagamento + '\'' +
                ", valor=" + valor +
                ", status=" + status +
                ", dataPagamento=" + dataPagamento +
                ", idPaciente=" + idPaciente +
                '}';
    }
}
