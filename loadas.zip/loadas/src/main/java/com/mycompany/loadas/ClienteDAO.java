package com.mycompany.loadas;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {

    // Retorna todos os clientes
    public List<Usuario> getClientes() {
        List<Usuario> clientes = new ArrayList<>();

        String sql = "SELECT DISTINCT u.id_usuario, u.nome, u.email, u.telefone, u.cpf, pg.status " +
                     "FROM Usuario u " +
                     "JOIN Paciente p ON u.id_usuario = p.id_usuario " +
                     "LEFT JOIN Pagamento pg ON p.id_paciente = pg.id_paciente";

        try (Connection conn = Conexao_DB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id_usuario");
                String nome = rs.getString("nome");
                String email = rs.getString("email");
                String telefone = rs.getString("telefone");
                String cpf = rs.getString("cpf");
                
                // Se não houver pagamento registrado, considera 's' (pago)
                char status = 's';
                String statusStr = rs.getString("status");
                if (statusStr != null && !statusStr.isEmpty()) {
                    status = statusStr.charAt(0);
                }

                clientes.add(new Usuario(id, nome, email, telefone, cpf, status));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return clientes;
    }

    // Retorna apenas clientes devedores
    public List<Usuario> getClientesDevedores() {
        List<Usuario> devedores = new ArrayList<>();
        for (Usuario u : getClientes()) {
            if (u.getStatus() == 'n') {
                devedores.add(u);
            }
        }
        return devedores;
    }
}
