/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loadas;

/**
 *
 * @author user
 */
public class Loadas {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
