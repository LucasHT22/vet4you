package com.mycompany.loadas;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAO {

    public List<Usuario> getUsuariosDevedores() {
        List<Usuario> devedores = new ArrayList<>();

        String sql = "SELECT DISTINCT u.id_usuario, u.nome, u.email, u.telefone, u.cpf, pg.status " +
                     "FROM Usuario u " +
                     "JOIN Paciente p ON u.id_usuario = p.id_usuario " +
                     "JOIN Pagamento pg ON p.id_paciente = pg.id_paciente " +
                     "WHERE pg.status = 'n'";

        try (Connection conn = Conexao_DB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id_usuario");
                String nome = rs.getString("nome");
                String email = rs.getString("email");
                String telefone = rs.getString("telefone");
                String cpf = rs.getString("cpf");
                char status = rs.getString("status").charAt(0);

                devedores.add(new Usuario(id, nome, email, telefone, cpf, status));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return devedores;
    }
}
