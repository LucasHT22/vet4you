/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loadas;

import java.util.Date;

public class Cartao {
    private int idCartao;
    private int plano;
    private Date validade;
    private String titular;

    // Construtor
    public Cartao(int idCartao, int plano, Date validade, String titular) {
        this.idCartao = idCartao;
        this.plano = plano;
        this.validade = validade;
        this.titular = titular;
    }

    // Getters e Setters
    public int getIdCartao() {
        return idCartao;
    }

    public void setIdCartao(int idCartao) {
        this.idCartao = idCartao;
    }

    public int getPlano() {
        return plano;
    }

    public void setPlano(int plano) {
        this.plano = plano;
    }

    public Date getValidade() {
        return validade;
    }

    public void setValidade(Date validade) {
        this.validade = validade;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    @Override
    public String toString() {
        return "Cartao{" +
                "idCartao=" + idCartao +
                ", plano=" + plano +
                ", validade=" + validade +
                ", titular='" + titular + '\'' +
                '}';
    }
}
