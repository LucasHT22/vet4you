package com.mycompany.loadas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TelaRelatorios extends JFrame {

    private JComboBox<String> comboPeriodo;
    private JPanel painelConteudo;

    public TelaRelatorios() {
        setTitle("📅 Relatórios financeiros por período");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        // Layout principal
        this.setLayout(new BorderLayout());

        // Topo com JComboBox
        String[] periodos = {"Diário", "Semanal", "Mensal"};
        comboPeriodo = new JComboBox<>(periodos);

        comboPeriodo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                atualizarConteudo();
            }
        });

        JPanel painelTopo = new JPanel();
        painelTopo.add(new JLabel("Selecionar período:"));
        painelTopo.add(comboPeriodo);

        this.add(painelTopo, BorderLayout.NORTH);

        // Painel de conteúdo que muda
        painelConteudo = new JPanel();
        painelConteudo.setLayout(new BorderLayout());
        this.add(painelConteudo, BorderLayout.CENTER);

        atualizarConteudo(); // Mostrar o primeiro conteúdo ao abrir
    }

    private void atualizarConteudo() {
        painelConteudo.removeAll();

        String periodoSelecionado = (String) comboPeriodo.getSelectedItem();
        JLabel label = new JLabel();

        switch (periodoSelecionado) {
            case "Diário":
                label.setText("Faturamento diário: R$ 2.500,00");
                break;
            case "Semanal":
                label.setText("Faturamento semanal: R$ 17.500,00");
                break;
            case "Mensal":
                label.setText("Faturamento mensal: R$ 75.000,00");
                break;
        }

        label.setFont(new Font("Arial", Font.BOLD, 16));
        label.setHorizontalAlignment(SwingConstants.CENTER);
        painelConteudo.add(label, BorderLayout.CENTER);

        painelConteudo.revalidate();
        painelConteudo.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TelaRelatorios().setVisible(true));
    }
}
