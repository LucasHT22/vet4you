package com.mycompany.dao;

import com.mycompany.model.Cartao;
import com.mycompany.loadas.Conexao_DB;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartaoDao {

    // Retorna todos os cartões cadastrados
    public List<Cartao> getCartoes() {
        List<Cartao> cartoes = new ArrayList<>();

        String sql = "SELECT id_cartao, plano, validade, titular FROM Cartao";

        try (Connection conn = Conexao_DB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id_cartao");
                int plano = rs.getInt("plano");
                Date validade = rs.getDate("validade");
                String titular = rs.getString("titular");

                cartoes.add(new Cartao(id, plano, validade, titular));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return cartoes;
    }

    // Retorna um cartão específico pelo ID
    public Cartao getCartaoPorId(int idCartao) {
        String sql = "SELECT id_cartao, plano, validade, titular FROM Cartao WHERE id_cartao = ?";

        try (Connection conn = Conexao_DB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idCartao);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int plano = rs.getInt("plano");
                    Date validade = rs.getDate("validade");
                    String titular = rs.getString("titular");

                    return new Cartao(idCartao, plano, validade, titular);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
    
    
    public String getNomePlano(int plano) {
    switch(plano) {
        case 1: return "AnimaLover";
        case 2: return "AnimalHolic";
        default: return "Plano Desconhecido";
    }
}
    
}
