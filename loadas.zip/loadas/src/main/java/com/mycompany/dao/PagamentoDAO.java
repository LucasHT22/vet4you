package com.mycompany.dao;

import com.mycompany.loadas.Conexao_DB;
import com.mycompany.model.Pagamento;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PagamentoDAO {

    // Retorna todos os pagamentos
    public List<Pagamento> getPagamentos() {
        List<Pagamento> pagamentos = new ArrayList<>();

        String sql = "SELECT * FROM Pagamento";

        try (Connection conn = Conexao_DB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int idPagamento = rs.getInt("id_pagamento");
                String servico = rs.getString("servico");
                String formaPagamento = rs.getString("forma_pagamento");
                double valor = rs.getDouble("valor");
                char status = rs.getString("status").charAt(0);
                Date dataPagamento = rs.getDate("data_pagamento");
                int idPaciente = rs.getInt("id_paciente");

                Pagamento pagamento = new Pagamento(idPagamento, servico, formaPagamento, valor, status, dataPagamento, idPaciente);
                pagamentos.add(pagamento);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return pagamentos;
    }

    // Retorna apenas pagamentos em aberto (status = 'n')
    public List<Pagamento> getPagamentosPendentes() {
        List<Pagamento> pendentes = new ArrayList<>();

        for (Pagamento p : getPagamentos()) {
            if (p.getStatus() == 'n') {
                pendentes.add(p);
            }
        }

        return pendentes;
    }

    // Buscar pagamentos por paciente
    public List<Pagamento> getPagamentosPorPaciente(int idPaciente) {
        List<Pagamento> lista = new ArrayList<>();

        String sql = "SELECT * FROM Pagamento WHERE id_paciente = ?";

        try (Connection conn = Conexao_DB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPaciente);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int idPagamento = rs.getInt("id_pagamento");
                String servico = rs.getString("servico");
                String formaPagamento = rs.getString("forma_pagamento");
                double valor = rs.getDouble("valor");
                char status = rs.getString("status").charAt(0);
                Date dataPagamento = rs.getDate("data_pagamento");

                Pagamento pagamento = new Pagamento(idPagamento, servico, formaPagamento, valor, status, dataPagamento, idPaciente);
                lista.add(pagamento);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
    
    
    // Retorna o valor de um pagamento específico pelo ID
public double getValorPorId(int idPagamento) {
    String sql = "SELECT valor FROM Pagamento WHERE id_pagamento = ?";
    double valor = 0.0;

    try (Connection conn = Conexao_DB.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, idPagamento);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            valor = rs.getDouble("valor");
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return valor;
}

    
}
