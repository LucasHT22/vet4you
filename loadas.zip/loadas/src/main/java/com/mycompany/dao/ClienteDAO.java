package com.mycompany.dao;

import com.mycompany.loadas.Conexao_DB;
import com.mycompany.model.Usuario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ClienteDAO {

    // Retorna todos os clientes
    public List<Usuario> getClientes() {
        List<Usuario> clientes = new ArrayList<>();

        String sql = "SELECT DISTINCT u.id_usuario, u.nome, u.email, u.telefone, u.cpf, pg.status " +
                     "FROM Usuario u " +
                     "JOIN Paciente p ON u.id_usuario = p.id_usuario " +
                     "LEFT JOIN Pagamento pg ON p.id_paciente = pg.id_paciente";

        try (Connection conn = Conexao_DB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id_usuario");
                String nome = rs.getString("nome");
                String email = rs.getString("email");
                String telefone = rs.getString("telefone");
                String cpf = rs.getString("cpf");
                
                // Se não houver pagamento registrado, considera 's' (pago)
                char status = 's';
                String statusStr = rs.getString("status");
                if (statusStr != null && !statusStr.isEmpty()) {
                    status = statusStr.charAt(0);
                }

                clientes.add(new Usuario(id, nome, email, telefone, cpf, status));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return clientes;
    }

    // Retorna apenas clientes devedores
    public List<Usuario> getClientesDevedores() {
        List<Usuario> devedores = new ArrayList<>();
        for (Usuario u : getClientes()) {
            if (u.getStatus() == 'n') {
                devedores.add(u);
            }
        }
        return devedores;
    }
    
    public void AtualizarStatus(int id_paciente) {
    // SQL para VERIFICAR o status atual do pagamento.
    String sqlSelect = "SELECT status FROM Pagamento WHERE id_paciente = ?";
    
    // SQL para ATUALIZAR o status.
    String sqlUpdate = "UPDATE Pagamento SET status = ? WHERE id_paciente = ?";

    // Usamos try-with-resources para garantir que a conexão seja sempre fechada.
    try (Connection conn = Conexao_DB.conectar()) {
        
        String statusAtual = null; // Variável para armazenar o status vindo do banco.

        try (PreparedStatement stmtSelect = conn.prepareStatement(sqlSelect)) {
            stmtSelect.setInt(1, id_paciente);
            
            try (ResultSet rs = stmtSelect.executeQuery()) {
                // Verifica se encontramos um registro para esse paciente.
                if (rs.next()) {
                    statusAtual = rs.getString("status");
                } else {
                    JOptionPane.showMessageDialog(null, "Nenhum registro de pagamento encontrado para o paciente com ID: " + id_paciente);
                    return; // Sai do método pois não há o que atualizar.
                }
            }
        }

      
        // Usamos "s".equals() para evitar erro se statusAtual for nulo.
        if ("s".equals(statusAtual)) {
            // Se o status já é 's', apenas informa o usuário.
            JOptionPane.showMessageDialog(null, "O pagamento para este paciente já foi confirmado anteriormente.");
        } else {
            // Se o status for diferente de 's', executa a atualização.
            try (PreparedStatement stmtUpdate = conn.prepareStatement(sqlUpdate)) {
                stmtUpdate.setString(1, "s"); 
                stmtUpdate.setInt(2, id_paciente);
                
                int linhasAfetadas = stmtUpdate.executeUpdate();
                
                if (linhasAfetadas > 0) {
                    JOptionPane.showMessageDialog(null, "Pagamento confirmado e status atualizado com sucesso!");
                } else {
                    JOptionPane.showMessageDialog(null, "Não foi possível atualizar o status do pagamento.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Ocorreu um erro de banco de dados: " + e.getMessage(), "Erro Crítico", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}
    
    
    
    
    
}
